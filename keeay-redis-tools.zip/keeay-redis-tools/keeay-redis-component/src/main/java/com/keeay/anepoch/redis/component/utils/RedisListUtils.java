package com.keeay.anepoch.redis.component.utils;

import com.keeay.anepoch.base.commons.exception.BizException;
import com.keeay.anepoch.redis.component.helper.RedisComponentHelper;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Description:
 * really_redis_key : 环境变量 + '_' + biz_key
 *
 * @author -  pany
 * Time - 2024/4/9 - 15:21
 */
@Component
public class RedisListUtils {
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private RedisComponentHelper redisComponentHelper;

    /**
     * 添加set元素
     *
     * @param key      key
     * @param listUnit set xxx
     * @return success size > 0 true orElse false
     */
    public boolean rightPush(Object key, Object listUnit) {
        try {
            return redisTemplate.opsForList().rightPush(redisComponentHelper.getRedisKeyHeader() + key, listUnit) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取set元素
     *
     * @param key key
     * @return success size > 0 true orElse false
     */
    public Object getAndDelete(Object key) {
        try {
            return redisTemplate.opsForList().leftPop(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("获取list元素异常, redis key : " + key);
        }
    }


    /**
     * 是否set中是否包含item元素
     *
     * @param key key
     * @return contains true orElse false
     */
    public Long size(Object key) {
        try {
            return redisTemplate.opsForList().size(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("redis list size异常, redis key : " + key);
        }
    }

    /**
     * 删除整个list
     *
     * @param key key
     * @return contains true orElse false
     */
    public Boolean delete(Object key) {
        try {
            return redisTemplate.delete(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("redis list delete异常, redis key : " + key);
        }
    }
}
