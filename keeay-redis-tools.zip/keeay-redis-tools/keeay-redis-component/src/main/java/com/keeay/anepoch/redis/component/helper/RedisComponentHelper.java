package com.keeay.anepoch.redis.component.helper;

import com.keeay.anepoch.base.commons.utils.ConditionUtils;
import com.keeay.anepoch.redis.component.config.RedisConfig;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2024/4/17 - 14:31
 */
@Component
public class RedisComponentHelper {
    @Resource
    private RedisConfig redisConfig;

    /**
     * 获取redis key header
     *
     * @return header
     */

    public String getRedisKeyHeader() {
        ConditionUtils.checkArgument(StringUtils.isNotBlank(redisConfig.getApplicationName()), "spring.profiles.active config is blank");
        ConditionUtils.checkArgument(StringUtils.isNotBlank(redisConfig.getApplicationName()), "spring.application.name is blank");
        return redisConfig.getApplicationName() + "_" + redisConfig.getActive() + "_";
    }
}
