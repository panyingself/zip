package com.keeay.anepoch.redis.component.config;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2024/4/10 - 15:01
 */
@Data
@Component
public class RedisConfig {
    @Value("${spring.profiles.active}")
    private String active;

    @Value("${spring.application.name}")
    private String applicationName;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
