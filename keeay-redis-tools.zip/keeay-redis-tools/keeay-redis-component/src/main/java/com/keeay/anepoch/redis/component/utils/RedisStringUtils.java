package com.keeay.anepoch.redis.component.utils;

import com.keeay.anepoch.base.commons.exception.BizException;
import com.keeay.anepoch.redis.component.helper.RedisComponentHelper;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * Description:
 * really_redis_key : 环境变量 + '_' + biz_key
 *
 * @author -  pany
 * Time - 2024/4/9 - 15:21
 */
@Component
public class RedisStringUtils {
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private RedisComponentHelper redisComponentHelper;

    /**
     * 添加一个键值对
     *
     * @param key   key
     * @param value value
     */
    public void set(Object key, Object value) {
        try {
            redisTemplate.opsForValue().set(redisComponentHelper.getRedisKeyHeader() + key, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加一个键值对
     *
     * @param key   key
     * @param value value
     */
    public void setForExpire(Object key, Object value, Long expireTime) {
        try {
            redisTemplate.opsForValue().set(redisComponentHelper.getRedisKeyHeader() + key, value, expireTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 添加一个键值对
     *
     * @param key   key
     * @param value value
     */
    public void setForExpire(Object key, Object value, Long expireTime, TimeUnit timeUnit) {
        try {
            redisTemplate.opsForValue().set(redisComponentHelper.getRedisKeyHeader() + key, value, expireTime, timeUnit);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取key - v
     *
     * @param key key
     */
    public Object get(Object key) {
        try {
            return redisTemplate.opsForValue().get(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * increment
     *
     * @param key key
     */
    public Long increment(Object key) {
        try {
            return redisTemplate.opsForValue().increment(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * increment
     *
     * @param key key
     */
    public Long increment(Object key, Long value) {
        try {
            return redisTemplate.opsForValue().increment(redisComponentHelper.getRedisKeyHeader() + key, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * decrement
     *
     * @param key key
     */
    public Long decrement(Object key, Long value) {
        try {
            return redisTemplate.opsForValue().decrement(redisComponentHelper.getRedisKeyHeader() + key, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 删除key
     *
     * @param key key
     * @return contains true orElse false
     */
    public Boolean delete(Object key) {
        try {
            return redisTemplate.delete(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("redis string delete异常, redis key : " + key);
        }
    }
}
