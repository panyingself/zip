package com.keeay.anepoch.redis.component.utils;

import com.keeay.anepoch.base.commons.exception.BizException;
import com.keeay.anepoch.redis.component.helper.RedisComponentHelper;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;

/**
 * Description:
 * really_redis_key : 应用名称 + '_' 环境变量 + '_' + biz_key
 *
 * @author -  pany
 * Time - 2024/4/9 - 15:21
 */
@Component
public class RedisSetUtils {
    @Resource
    private RedisTemplate redisTemplate;
    @Resource
    private RedisComponentHelper redisComponentHelper;

    /**
     * 添加set元素
     *
     * @param key     key
     * @param setUnit set xxx
     * @return success size > 0 true orElse false
     */
    public boolean add(Object key, Object... setUnit) {
        try {
            return redisTemplate.opsForSet().add(redisComponentHelper.getRedisKeyHeader() + key, setUnit) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取set元素
     *
     * @param key key
     * @return success size > 0 true orElse false
     */
    public Set<Object> get(Object key) {
        try {
            return redisTemplate.opsForSet().members(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("获取set集合异常, redis key : " + key);
        }
    }

    /**
     * 随机获取zet中的一个元素
     *
     * @param key key
     * @return success size > 0 true orElse false
     */
    public Object getRandomAndDelete(Object key) {
        try {
            return redisTemplate.opsForSet().pop(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("获取set集合getRandomAndDelete异常, redis key : " + key);
        }
    }

    /**
     * 随机获取set中的指定数量元素
     *
     * @param key key
     * @return success size > 0 true orElse false
     */
    public List<Object> getRandomAndDelete(Object key, Long size) {
        try {
            return redisTemplate.opsForSet().pop(redisComponentHelper.getRedisKeyHeader() + key, size);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("获取set集合getRandomAndDelete异常, redis key : " + key);
        }
    }

    /**
     * 是否set中是否包含item元素
     *
     * @param key key
     * @return contains true orElse false
     */
    public boolean isContains(Object key, Object item) {
        try {
            return redisTemplate.opsForSet().isMember(redisComponentHelper.getRedisKeyHeader() + key, item);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("redis set isContains异常, redis key : " + key);
        }
    }

    /**
     * 是否set中是否包含item元素
     *
     * @param key key
     * @return contains true orElse false
     */
    public Long size(Object key) {
        try {
            return redisTemplate.opsForSet().size(redisComponentHelper.getRedisKeyHeader() + key);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BizException("redis set size异常, redis key : " + key);
        }
    }
}
