CREATE TABLE `magic_code`.`magic_code`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `db_url` varchar(255)  NULL DEFAULT NULL COMMENT '数据库url',
  `db_driver` varchar(255)  NULL DEFAULT NULL COMMENT '数据库driver',
  `db_user_name` varchar(255)  NULL DEFAULT NULL COMMENT '数据库用户名',
  `db_pass_word` varchar(255)  NULL DEFAULT NULL COMMENT '数据库密码',
  `db_schema` varchar(255)  NULL DEFAULT NULL COMMENT '数据库schema',
  `db_name` varchar(255)  NULL DEFAULT NULL COMMENT '数据库name',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 ROW_FORMAT = Dynamic;


INSERT INTO `magic_code`.`magic_info` (`id`, `db_url`, `db_driver`, `db_user_name`, `db_pass_word`, `db_schema`, `db_name`, `create_time`, `update_time`) VALUES (1, 'jdbc:mysql://rm-bp148zdgj80z6cflm7o.mysql.rds.aliyuncs.com:3306/digital-case?useUnicode=true&characterEncoding=utf8&allowMultiQueries=true', 'com.mysql.cj.jdbc.Driver', 'root', 'ZPB5cQUffT1vcCU0', 'digital-case', 'digital-case', '2024-02-23 14:42:45', '2024-02-23 14:42:45');
