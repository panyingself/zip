/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.service.mapper;

import com.gm.anepoch.code.commons.model.AutoDbInfo;
import com.gm.anepoch.code.service.mapper.base.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AutoDbInfoMapper extends BaseMapper<AutoDbInfo> {

}
