/*
 *
 *  * Copyright (c) 2019. tdc.shangri-la.com. All Rights Reserved.
 *
 */

package com.gm.anepoch.code.service.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author ying.pan
 * @date 2019/9/4 9:33 PM.
 */
@MapperScan("com.gm.anepoch.code.service.mapper")
@Configuration
public class MybatisConfig {
}
