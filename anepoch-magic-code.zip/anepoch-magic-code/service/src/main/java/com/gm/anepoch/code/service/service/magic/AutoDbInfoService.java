/*
 * Copyright (c) 2018. Toxic
 */

/*
 * Web Site: http://www.reapal.com
 * Since 2014 - 2018
 */

package com.gm.anepoch.code.service.service.magic;


import com.gm.anepoch.code.commons.model.*;
import com.gm.anepoch.code.service.service.base.BaseService;

import java.util.List;

public interface AutoDbInfoService extends BaseService<AutoDbInfo, Long> {
	List<AutoDbInfo> queryList(AutoDbInfo autoDbInfo);

//	Page<AutoDbInfo> queryListPage(AutoDbInfoQuery autoDbInfoQuery, Page<AutoDbInfo> page);
}
