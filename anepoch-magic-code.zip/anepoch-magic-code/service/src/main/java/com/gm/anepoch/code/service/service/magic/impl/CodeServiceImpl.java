/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.service.service.magic.impl;

import com.gm.anepoch.code.commons.model.*;
import com.gm.anepoch.code.service.dao.CodeDao;
import com.gm.anepoch.code.service.service.magic.CodeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 上午11:48.
 */
@Service
public class CodeServiceImpl implements CodeService {
    @Resource
    private CodeDao codeDao;

    @Override
    public List<TableInfo> getAllTables(DbconfigInfo dbconfigInfo) {
        return codeDao.getAllTables(dbconfigInfo);
    }

    @Override
    public TableInfo getAllColumns(String tableName, DbconfigInfo dbconfigInfo) {
        return codeDao.getAllColumns(tableName, dbconfigInfo);
    }

    @Override
    public void saveComment(TableInfo tableInfo, DbconfigInfo dbconfigInfo) {
        codeDao.saveComment(tableInfo, dbconfigInfo);
    }
}
