/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.service.service.magic.impl;

import java.util.List;

import com.gm.anepoch.code.commons.model.*;
import com.gm.anepoch.code.service.mapper.AutoDbInfoMapper;
import com.gm.anepoch.code.service.service.base.impl.BaseServiceImpl;
import com.gm.anepoch.code.service.service.magic.AutoDbInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AutoDbInfoServiceImpl extends BaseServiceImpl<AutoDbInfo, Long> implements AutoDbInfoService {
    @Resource
    private AutoDbInfoMapper autoDbInfoMapper;


    @Override
    public List<AutoDbInfo> queryList(AutoDbInfo autoDbInfo) {
        return autoDbInfoMapper.selectList(autoDbInfo);
    }


}
