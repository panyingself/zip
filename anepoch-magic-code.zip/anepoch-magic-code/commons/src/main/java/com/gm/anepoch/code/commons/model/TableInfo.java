/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.commons.model;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 上午10:02.
 */
@Data
public class TableInfo implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    /**
     * 表名
     */
    private String tableName;
    /**
     * 表注释
     */
    private String comments;
    /**
     * 表字段集合
     */
    private List<ColumnInfo> listColumn;

}
