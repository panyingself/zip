/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.commons.model;

import lombok.Data;

import java.io.Serializable;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 上午10:05.
 */
@Data
public class ColumnInfo implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    /**
     * 列名
     */
    private String colName;
    /**
     * 列类型
     */
    private String colType;
    /**
     * 列备注
     */
    private String comments;
}
