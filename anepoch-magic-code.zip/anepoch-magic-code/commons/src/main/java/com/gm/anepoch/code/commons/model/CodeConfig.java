/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.commons.model;

import lombok.Data;

import java.io.Serializable;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 下午3:56.
 */
@Data
public class CodeConfig implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;

    //配置属性
    /**
     * jsp namespace: web/${namespace}/${className}/list.jsp
     */
    private String namespace = "pages";
    /**
     * 需要移除的表名前缀,使用逗号进行分隔多个前缀,示例值: t_,v_
     */
    private String tableRemovePrefixes = "tb,sys,cm,pf,sa,tf,kf,be,su,mr,df,etc,ft,t_";
    private String basepackage;
    private String basepackage_meta;
    private String basepackage_controller;
    private String path_model;
    private String path_mybatis;
    private String path_admin;
    private String path_front;
    private String path_html5;

    /*表配置*/
    /**
     *
     */
    private String outRoot;
    private String templateName;
}
