/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.commons.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@Data
public class AutoDbInfo implements Serializable {
    private static final long serialVersionUID = 3148176768559230877L;
    /**
     * 主键
     */
    private Long id;
    /**
     * db_url路径
     */
    private String dbUrl;
    /**
     * db_driver驱动信息
     */
    private String dbDriver;
    /**
     * db用户名
     */
    private String dbUserName;
    /**
     * db密码
     */
    private String dbPassWord;
    /**
     * db_schema信息
     */
    private String dbSchema;
    /**
     * db数据库名称
     */
    private String dbName;
}

