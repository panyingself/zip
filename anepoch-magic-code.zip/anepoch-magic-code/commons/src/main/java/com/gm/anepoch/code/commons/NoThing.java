package com.gm.anepoch.code.commons;

public class NoThing {
}
