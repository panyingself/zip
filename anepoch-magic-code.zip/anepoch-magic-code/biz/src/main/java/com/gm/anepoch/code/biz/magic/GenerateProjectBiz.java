/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.biz.magic;

import cn.org.rapid_framework.generator.GeneratorFacade;
import cn.org.rapid_framework.generator.GeneratorProperties;
import com.gm.anepoch.code.biz.magic.bo.ProjectGenerateBo;
import com.gm.anepoch.code.commons.model.CodeConfig;
import com.gm.anepoch.code.commons.model.DbconfigInfo;
import com.gm.anepoch.code.commons.model.TableInfo;
import org.springframework.stereotype.Component;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 下午3:58.
 */
@Component
public class GenerateProjectBiz {
    /**
     * Method:
     * Description:初始化数据库信息
     * 1、设置数据库属性：数据库连接串、用户名、密码
     * 2、设置配置属性：
     */
    public void generator(ProjectGenerateBo projectGenerateBo, CodeConfig codeConfig){
        //init project properties
        this.initProjectProperties(projectGenerateBo);
        //init base properties
        this.initBaseProperties(codeConfig);

        GeneratorFacade g = new GeneratorFacade();
        try {
            g.generateByTable("magic_info",codeConfig.getTemplateName());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    private void initProjectProperties(ProjectGenerateBo projectGenerateBo){
        //将project所需信息映射
        GeneratorProperties.setProperty("project_name", projectGenerateBo.getProjectName());
        GeneratorProperties.setProperty("basepackage", "com.gm.anepoch." + projectGenerateBo.getBasePackage());
        GeneratorProperties.setProperty("basepackage_dr", projectGenerateBo.getBasePackage());
        GeneratorProperties.setProperty("CONTEXT_NAME", projectGenerateBo.getProjectName());
        GeneratorProperties.setProperty("LOG_PATH", "logs");
        GeneratorProperties.setProperty("MAX_FILE_SIZE", "2048MB");
        GeneratorProperties.setProperty("MAX_HISTORY", "30");
    }
    private void initBaseProperties(CodeConfig codeConfig){
        //数据库类型至java类型映射
        GeneratorProperties.setProperty("java_typemapping.java.sql.Timestamp", "java.util.Date");
        GeneratorProperties.setProperty("java_typemapping.java.sql.Date", "java.util.Date");
        GeneratorProperties.setProperty("java_typemapping.java.sql.Time", "java.util.Date");
        GeneratorProperties.setProperty("java_typemapping.java.lang.Byte", "Integer");
        GeneratorProperties.setProperty("java_typemapping.java.lang.Short", "Integer");
        GeneratorProperties.setProperty("java_typemapping.java.math.BigDecimal", "Long");
        GeneratorProperties.setProperty("java_typemapping.java.sql.Clob", "String");

        GeneratorProperties.setProperty("jdbc.url", "jdbc:mysql://121.40.182.4:3306");
        GeneratorProperties.setProperty("dbType", "mysql");
        GeneratorProperties.setProperty("jdbc.driver", "com.mysql.cj.jdbc.Driver");
        GeneratorProperties.setProperty("jdbc.username", "root");
        GeneratorProperties.setProperty("jdbc.password", "gmanalysis1123");
        GeneratorProperties.setProperty("jdbc.schema", "magic_code");

        if(null != (codeConfig.getOutRoot()) && !"".equals(codeConfig.getOutRoot())) {
            GeneratorProperties.setProperty("outRoot", codeConfig.getOutRoot());
        }
        GeneratorProperties.setProperty("tableRemovePrefixes", codeConfig.getTableRemovePrefixes());

        GeneratorProperties.setProperty("namespace", codeConfig.getNamespace());

        String model = "pytest";
        GeneratorProperties.setProperty("basepackage_controller", codeConfig.getBasepackage() + ".controller");
        GeneratorProperties.setProperty("path_model", codeConfig.getPath_model()+model);
        GeneratorProperties.setProperty("path_mybatis", codeConfig.getPath_mybatis()+model);
        GeneratorProperties.setProperty("path_admin", codeConfig.getPath_admin()+model);
        GeneratorProperties.setProperty("path_front", codeConfig.getPath_front()+model);
        GeneratorProperties.setProperty("path_html5", codeConfig.getPath_html5()+model);

    }
}
