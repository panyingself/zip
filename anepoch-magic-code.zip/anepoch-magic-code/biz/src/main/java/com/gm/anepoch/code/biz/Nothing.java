package com.gm.anepoch.code.biz;

import com.gm.anepoch.code.service.mapper.AutoDbInfoMapper;

public class Nothing {

}
