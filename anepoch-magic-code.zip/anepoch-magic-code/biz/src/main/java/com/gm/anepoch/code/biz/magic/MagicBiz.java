package com.gm.anepoch.code.biz.magic;

import java.util.List;

public interface MagicBiz {
    List getList();
}
