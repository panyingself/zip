package com.gm.anepoch.code.biz.magic;

import com.gm.anepoch.code.service.mapper.AutoDbInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class MagicBizImpl implements MagicBiz{
    @Resource
    private AutoDbInfoMapper autoDbInfoMapper;
    @Override
    public List getList() {
        return autoDbInfoMapper.selectList(null);
    }
}
