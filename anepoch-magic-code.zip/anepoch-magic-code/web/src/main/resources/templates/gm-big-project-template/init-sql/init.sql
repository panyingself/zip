-- ----------------------------
-- Table structure for auth_form
-- ----------------------------
DROP TABLE IF EXISTS `auth_form`;
CREATE TABLE `auth_form`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '动态表单标题管理主键id',
  `classification_field` varchar(36)  NOT NULL COMMENT '分类字段',
  `show_flag` tinyint NOT NULL DEFAULT 0 COMMENT '(0:显示；1：不显示）',
  `parent_id` bigint NOT NULL COMMENT '(0：顶级：其他)',
  `sort` int NOT NULL DEFAULT 100 COMMENT '排序字段（越小越靠后；默认0）',
  `type` tinyint NOT NULL DEFAULT 0 COMMENT '分类（0:系统)',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `grade` tinyint NOT NULL COMMENT '层级（0：默认等级；1：二级）',
  `classification_name` varchar(36)  NOT NULL COMMENT '分类名称',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_classification_field_idx`(`classification_field` ASC) USING BTREE,
  INDEX `parent_id_idx`(`parent_id` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_form
-- ----------------------------
INSERT INTO `auth_form` VALUES (1, 'sys_board_cfg', 0, 0, 0, 0, '2023-03-01 10:22:17', '2023-03-01 10:22:17', 0, '系统后台配置	');
INSERT INTO `auth_form` VALUES (2, 'sys_board_sysname', 0, 1, 0, 0, '2023-03-01 10:23:30', '2023-03-01 10:23:30', 1, '系统配置面板');

-- ----------------------------
-- Table structure for auth_form_field
-- ----------------------------
DROP TABLE IF EXISTS `auth_form_field`;
CREATE TABLE `auth_form_field`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '动态表单数据表id',
  `auth_form_id` bigint NOT NULL COMMENT '表单标题id',
  `field_variable` varchar(36)  NOT NULL COMMENT '字段变量',
  `field_type` tinyint NOT NULL DEFAULT 0 COMMENT '字段类型（0：文本框；1：多行文本框；2：单选；3：多选，4:文件上传；5:下拉框）',
  `field_variable_name` varchar(36)  NOT NULL COMMENT '配置名称',
  `field_variable_name_memo` varchar(255)  NULL DEFAULT NULL COMMENT '配置名称简介',
  `form_value` varchar(255)  NULL DEFAULT NULL COMMENT '表单值',
  `form_value_configure` varchar(2000)  NULL DEFAULT NULL COMMENT '表单配置',
  `show_flag` tinyint NOT NULL COMMENT '是否展示(0:展示；1：不展示）',
  `sort` int NOT NULL DEFAULT 100 COMMENT '排序值（越小越靠前，最小为0）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `auth_form_classification_field` varchar(36)  NOT NULL COMMENT '动态表单头字段变量',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_field_variable_idx`(`field_variable` ASC) USING BTREE,
  INDEX `auth_form_id_idx`(`auth_form_id` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_form_field
-- ----------------------------
INSERT INTO `auth_form_field` VALUES (1, 2, 'sys_board_cfg_sysname', 0, '管理系统展示名称', '', '[{\"formDataValue\":\"冠美大项目后台\"}]', '', 0, 0, '2023-03-01 10:24:53', '2023-03-03 09:57:13', 'sys_board_sysname');

-- ----------------------------
-- Table structure for data_group
-- ----------------------------
DROP TABLE IF EXISTS `data_group`;
CREATE TABLE `data_group`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '数据组配置表主键id',
  `data_field_key` varchar(36)  NOT NULL COMMENT '数据字段',
  `data_field_memo` varchar(255)  NULL DEFAULT NULL COMMENT '数据字段说明',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `data_json` text  NULL COMMENT '数据组配置json格式',
  `data_field_name` varchar(36)  NULL DEFAULT NULL COMMENT '数据组名称',
  `show_flag` tinyint NOT NULL DEFAULT 0 COMMENT '是否可用(0:可用;1：不可用)',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_data_field_key_idx`(`data_field_key` ASC) USING BTREE,
  UNIQUE INDEX `uniq_data_field_name_idx`(`data_field_name` ASC) USING BTREE,
  INDEX `data_field_name_idx`(`data_field_name` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of data_group
-- ----------------------------
INSERT INTO `data_group` (`id`, `data_field_key`, `data_field_memo`, `create_time`, `update_time`, `data_json`, `data_field_name`, `show_flag`) VALUES (1, 'c_banner', '首页banner信息(demo)', '2023-03-10 11:19:40', '2023-03-10 11:47:48', '[{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"imgUrl\",\"title\":\"图片地址\"},{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"sort\",\"title\":\"排序\"},{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"imgName\",\"title\":\"图片名称\"}]', '首页banner信息(demo)', 0);
INSERT INTO `data_group` (`id`, `data_field_key`, `data_field_memo`, `create_time`, `update_time`, `data_json`, `data_field_name`, `show_flag`) VALUES (2, 'c_gifts', '奖品信息(demo)', '2023-03-06 11:27:13', '2023-03-10 11:47:53', '[{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"imgUrl\",\"title\":\"图片地址\"},{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"prizeName\",\"title\":\"奖品名称\"},{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"rank\",\"title\":\"奖品排名\"},{\"headType\":0,\"headTypeConfigList\":[{\"headTypeConfigKey\":\"undefined\",\"headTypeConfigValue\":\"null\"}],\"headTypeName\":\"文本框\",\"key\":\"num\",\"title\":\"奖品数量\"}]', '奖品信息列表(demo)', 0);

-- ----------------------------
-- Table structure for data_group_field
-- ----------------------------
DROP TABLE IF EXISTS `data_group_field`;
CREATE TABLE `data_group_field`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '数据表主键id',
  `data_json_select` text  NOT NULL COMMENT '动态数据配置字段',
  `show_flag` tinyint NOT NULL DEFAULT 0 COMMENT '是否可用(0:可用;1：不可用)',
  `sort` int NOT NULL DEFAULT 100 COMMENT '排序字段（越小越靠后；默认0）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `data_compose_id` bigint NOT NULL COMMENT '数据组id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `data_compose_id_idx`(`data_compose_id` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of data_group_field
-- ----------------------------
INSERT INTO `data_group_field` (`id`, `data_json_select`, `show_flag`, `sort`, `create_time`, `update_time`, `data_compose_id`) VALUES (1, '{\"imgUrl\":\"http://testimg.com002(demo)\",\"sort\":\"1\",\"imgName\":\"图片1\"}', 0, 0, '2023-03-10 11:19:57', '2023-03-10 11:34:02', 1);
INSERT INTO `data_group_field` (`id`, `data_json_select`, `show_flag`, `sort`, `create_time`, `update_time`, `data_compose_id`) VALUES (2, '{\"imgUrl\":\"http://testimg.com001(demo)\",\"sort\":\"2\",\"imgName\":\"图片2\"}', 1, 0, '2023-03-10 11:20:03', '2023-03-10 11:39:52', 1);

-- ----------------------------
-- Table structure for img_group
-- ----------------------------
DROP TABLE IF EXISTS `img_group`;
CREATE TABLE `img_group`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '图片分组主键id',
  `image_classification_name` varchar(36)  NULL DEFAULT NULL COMMENT '图片分组名称',
  `del_flag` tinyint NOT NULL DEFAULT 0 COMMENT '(0：未删除；1：已删除）',
  `parent_id` bigint NOT NULL COMMENT '父级id(0:顶级)',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_image_classification_name_idx`(`image_classification_name` ASC) USING BTREE,
  INDEX `parent_id_idx`(`parent_id` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of img_group
-- ----------------------------

-- ----------------------------
-- Table structure for img_group_field
-- ----------------------------
DROP TABLE IF EXISTS `img_group_field`;
CREATE TABLE `img_group_field`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '图片存储表主键id',
  `img_address` varchar(255)  NOT NULL COMMENT '图片地址',
  `img_title_id` bigint NULL DEFAULT NULL COMMENT '图片分组id',
  `img_memo` varchar(255)  NULL DEFAULT NULL COMMENT '图片说明',
  `img_name` varchar(255)  NULL DEFAULT NULL COMMENT '图片名称',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `img_all_title_id` varchar(128)  NOT NULL COMMENT '图片分组全id',
  `img_type` tinyint NOT NULL DEFAULT 0 COMMENT '文件类型(0:图片）',
  `del_flag` tinyint NULL DEFAULT 0 COMMENT '删除标识(0:未删除;1:已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `img_title_id_idx`(`img_title_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of img_group_field
-- ----------------------------

-- ----------------------------
-- Table structure for sys_captcha_code
-- ----------------------------
DROP TABLE IF EXISTS `sys_captcha_code`;
CREATE TABLE `sys_captcha_code`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `code` varchar(20)  NULL DEFAULT NULL COMMENT '验证码',
  `uuid` varchar(64)  NULL DEFAULT NULL COMMENT 'uuid',
  `expire_time` datetime NULL DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_captcha_code
-- ----------------------------

-- ----------------------------
-- Table structure for sys_login_records
-- ----------------------------
DROP TABLE IF EXISTS `sys_login_records`;
CREATE TABLE `sys_login_records`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50)  NULL DEFAULT NULL COMMENT '登录用户',
  `retry_count` int NOT NULL DEFAULT 0 COMMENT '重试次数',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_login_records
-- ----------------------------

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '标识',
  `parent_id` bigint NULL DEFAULT NULL COMMENT '父级标识',
  `menu_name` varchar(50)  NULL DEFAULT NULL COMMENT '菜单名称',
  `code` varchar(50)  NULL DEFAULT NULL COMMENT '权限标识',
  `order_num` int NULL DEFAULT NULL COMMENT '显示顺序',
  `path` varchar(255)  NULL DEFAULT NULL COMMENT '路径',
  `route_name` varchar(255)  NULL DEFAULT NULL COMMENT '路由名称',
  `component` varchar(50)  NULL DEFAULT NULL COMMENT '组件',
  `is_link` int NULL DEFAULT NULL COMMENT '是否外链（0-否，1-是）',
  `menu_type` varchar(10)  NULL DEFAULT NULL COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `is_enable` int NOT NULL DEFAULT 1 COMMENT ' 是否启用（0-否，1-是）默认1',
  `icon` varchar(50)  NULL DEFAULT NULL COMMENT '图标',
  `remark` varchar(255)  NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `route_name`(`route_name` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 0, '系统管理', NULL, 1, 'system', 'system', 'layout', 0, 'M', 1, 'OptionsOutline', '', '2023-02-01 16:04:22', '2023-03-08 18:24:49');
INSERT INTO `sys_menu` VALUES (2, 1, '用户管理', 'system:user:list', 1, 'user', 'user', 'system/user/index', 0, 'C', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (3, 1, '角色管理', 'system:role:list', 2, 'role', 'role', 'system/role/index', 0, 'C', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (4, 1, '菜单管理', 'system:menu:list', 3, 'menu', 'menu', 'system/menu/index', 0, 'C', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (5, 1, '机构管理', 'system:org:list', 4, 'org', 'org', 'system/org/index', 0, 'C', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-14 14:39:24');
INSERT INTO `sys_menu` VALUES (6, 1, '日志管理', NULL, 5, 'log', 'log', NULL, 0, 'M', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (7, 6, '操作日志', 'system:log:list', 1, 'operLog', 'operLog', 'system/log/operLog/index', 0, 'C', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (8, 2, '用户查询', 'system:user:query', 1, NULL, 'sysUserQuery', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-14 14:42:41');
INSERT INTO `sys_menu` VALUES (9, 2, '用户新增', 'system:user:add', 2, NULL, 'sysUserAdd', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (10, 2, '用户修改', 'system:user:edit', 3, NULL, 'sysUserEdit', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (11, 2, '用户删除', 'system:user:remove', 4, NULL, 'sysUserRemove', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (12, 2, '重置密码', 'system:user:resetPwd', 5, NULL, 'sysUserResetPwd', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (13, 3, '角色查询', 'system:role:query', 1, NULL, 'sysRoleQuery', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-14 14:08:43');
INSERT INTO `sys_menu` VALUES (14, 3, '角色新增', 'system:role:add', 2, NULL, 'sysRoleAdd', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (15, 3, '角色修改', 'system:role:edit', 3, NULL, 'sysRoleEdit', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (16, 3, '角色删除', 'system:role:remove', 4, NULL, 'sysRoleRemove', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (17, 4, '菜单查询', 'system:menu:query', 1, NULL, 'sysMenuQuery', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (18, 4, '菜单新增', 'system:menu:add', 2, NULL, 'sysMenuAdd', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (19, 4, '菜单修改', 'system:menu:edit', 3, NULL, 'sysMenuEdit', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (20, 4, '菜单删除', 'system:menu:remove', 4, NULL, 'sysMenuRemove', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (21, 5, '机构查询', 'system:org:query', 1, NULL, 'sysOrgQuery', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (22, 5, '机构新增', 'system:org:add', 2, NULL, 'sysOrgAdd', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (23, 5, '机构修改', 'system:org:edit', 3, NULL, 'sysOrgEdit', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (24, 5, '机构删除', 'system:org:remove', 4, NULL, 'sysOrgRemove', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (25, 7, '日志查询', 'system:operLog:query', 1, NULL, 'sysOperLogQuery', NULL, 0, 'F', 1, NULL, NULL, '2023-02-01 16:04:22', '2023-02-01 16:04:22');
INSERT INTO `sys_menu` VALUES (30, 0, '维护', '', 1, 'maintenance', 'maintenance', 'layout', 0, 'M', 1, 'HammerOutline', '', '2023-02-07 10:47:28', '2023-03-08 18:25:10');
INSERT INTO `sys_menu` VALUES (31, 30, '开发配置', '', 0, 'config', 'config', '', 0, 'M', 1, '', '', '2023-02-07 10:49:04', '2023-02-07 10:50:48');
INSERT INTO `sys_menu` VALUES (32, 31, '配置数据', 'maintenance:confCategory:list', 0, 'configCategory', 'configCategory', 'maintenance/config/config-category/index', 0, 'C', 1, '', '', '2023-02-07 10:53:01', '2023-03-01 15:56:31');
INSERT INTO `sys_menu` VALUES (33, 31, '组合数据', 'maintenance:dataGroup:list', 1, 'dataGroup', 'dataGroup', 'maintenance/config/data-group/index', 0, 'C', 1, '', '', '2023-02-07 10:59:58', '2023-02-08 11:56:59');
INSERT INTO `sys_menu` VALUES (34, 31, '配置列表', 'maintenance:confCategoryList:list', 2, 'configCategory/list/:id', 'confCategoryList', 'maintenance/config/config-category-list/index', 0, 'C', 0, '', '', '2023-02-08 11:57:46', '2023-02-16 18:26:11');
INSERT INTO `sys_menu` VALUES (35, 0, '设置', '', 1, 'setting', 'setting', 'layout', 0, 'M', 1, 'FlowerSharp', '', '2023-02-10 08:57:15', '2023-03-08 18:24:54');
INSERT INTO `sys_menu` VALUES (36, 35, '系统设置', 'setting:systemsetting:list', 1, 'systemsetting', 'systemsetting', 'setting/systemsetting/index', 0, 'C', 1, '', '', '2023-02-10 09:00:34', '2023-03-08 18:25:05');
INSERT INTO `sys_menu` VALUES (37, 31, '组合数据列表', 'maintenance:dataGroupList:list', 2, 'dataGroup/list/:id', 'dataGroupList', 'maintenance/config/data-group-list/index', 0, 'C', 0, '', '', '2023-02-10 20:11:07', '2023-02-16 18:26:35');
INSERT INTO `sys_menu` VALUES (38, 32, '新增', 'system:authform:add', 0, '', 'authformAdd', '', 0, 'F', 1, '', '配置分类新增', '2023-02-13 11:01:45', '2023-02-13 11:01:45');
INSERT INTO `sys_menu` VALUES (39, 32, '修改', 'system:authform:edit', 0, '', 'authformEdit', '', 0, 'F', 1, '', '配置分类修改', '2023-02-13 11:03:18', '2023-02-13 11:10:21');
INSERT INTO `sys_menu` VALUES (40, 32, '查询根据id', 'system:authform:query', 0, '', 'authformFetchDetailById', '', 0, 'F', 1, '', '', '2023-02-13 11:04:39', '2023-02-13 11:10:27');
INSERT INTO `sys_menu` VALUES (41, 32, '查询集合', 'system:authform:list', 0, '', 'authFormPagerList', '', 0, 'F', 1, '', '', '2023-02-13 11:06:03', '2023-02-13 11:10:39');
INSERT INTO `sys_menu` VALUES (42, 32, '删除', 'system:authform:remove', 0, '', 'authformRemove', '', 0, 'F', 1, '', '', '2023-02-13 11:06:50', '2023-02-13 11:10:46');
INSERT INTO `sys_menu` VALUES (43, 32, '配置列表', 'system:authform:listChild', 0, '', 'authformListChild', '', 0, 'F', 1, '', '查询下级', '2023-02-13 11:21:24', '2023-02-13 11:21:24');
INSERT INTO `sys_menu` VALUES (44, 34, '新增按钮', 'system:authformfield:add', 0, '', 'authformfieldAdd', '', 0, 'F', 1, '', '新增按钮', '2023-02-13 11:23:05', '2023-02-13 11:23:05');
INSERT INTO `sys_menu` VALUES (45, 34, '修改', 'system:authformfield:edit', 0, '', 'authformfieldEdit', '', 0, 'F', 1, '', '修改', '2023-02-13 11:26:40', '2023-02-13 11:26:40');
INSERT INTO `sys_menu` VALUES (46, 34, '查询集合', 'system:authformfield:list', 0, '', 'authformfieldList', '', 0, 'F', 1, '', '查询集合', '2023-02-13 11:27:32', '2023-02-13 11:34:05');
INSERT INTO `sys_menu` VALUES (47, 34, '删除', 'system:authformfield:remove', 0, '', 'authformfieldRemove', '', 0, 'F', 1, '', '删除', '2023-02-13 11:28:13', '2023-02-13 11:34:09');
INSERT INTO `sys_menu` VALUES (48, 34, '查询详情', 'system:authformfield:query', 0, '', 'authformfieldQuery', '', 0, 'F', 1, '', '查询详情', '2023-02-13 11:28:42', '2023-02-13 11:34:14');
INSERT INTO `sys_menu` VALUES (49, 33, '新增', 'system:datagroup:add', 0, '', 'datagroupAdd', '', 0, 'F', 1, '', '', '2023-02-13 11:35:25', '2023-02-13 11:35:25');
INSERT INTO `sys_menu` VALUES (50, 33, '修改', 'system:datagroup:edit', 0, '', 'datagroupEdit', '', 0, 'F', 1, '', '', '2023-02-13 11:36:19', '2023-02-13 11:36:19');
INSERT INTO `sys_menu` VALUES (51, 33, '查询单条', 'system:datagroup:query', 0, '', 'datagroupQuery', '', 0, 'F', 1, '', '', '2023-02-13 11:41:48', '2023-02-13 11:42:29');
INSERT INTO `sys_menu` VALUES (52, 33, '删除', 'system:datagroup:remove', 0, '', 'datagroupRemove', '', 0, 'F', 1, '', '', '2023-02-13 11:42:15', '2023-03-08 18:25:49');
INSERT INTO `sys_menu` VALUES (53, 37, '组合数据新增', 'system:datagroupfield:add', 0, '', 'datagroupfieldAdd', '', 0, 'F', 1, '', '', '2023-02-13 11:43:07', '2023-02-13 11:43:07');
INSERT INTO `sys_menu` VALUES (54, 37, '组合数据列表编辑', 'system:datagroupfield:edit', 0, '', 'datagroupfieldEdit', '', 0, 'F', 1, '', '', '2023-02-13 11:43:46', '2023-02-13 11:43:46');
INSERT INTO `sys_menu` VALUES (55, 37, '组合列表数据查询', 'system:datagroupfield:list', 0, '', 'datagroupfieldList', '', 0, 'F', 1, '', '', '2023-02-13 11:44:18', '2023-02-13 11:45:09');
INSERT INTO `sys_menu` VALUES (56, 37, '组合列表数据查询单条', 'system:datagroupfield:query', 0, '', 'datagroupfieldQuery', '', 0, 'F', 1, '', '', '2023-02-13 11:44:56', '2023-02-13 11:44:56');
INSERT INTO `sys_menu` VALUES (57, 37, '组合数据列表删除', 'system:datagroupfield:remove', 0, '', 'datagroupfieldRemove', '', 0, 'F', 1, '', '', '2023-02-13 11:46:01', '2023-02-13 11:46:01');
INSERT INTO `sys_menu` VALUES (58, 33, 'datagroupToList', 'system:datagroup:list', 0, '', 'datagroupToList', '', 0, 'F', 1, '', '', '2023-02-13 11:49:49', '2023-02-13 11:58:23');
INSERT INTO `sys_menu` VALUES (59, 33, '查询下级集合', 'system:datagroup:listChild', 0, '', 'datagroupListChild', '', 0, 'F', 1, '', '', '2023-02-13 12:12:01', '2023-02-13 12:12:01');
INSERT INTO `sys_menu` VALUES (60, 1, '图片空间', 'system:picture:list', 0, 'picture', 'picture', 'system/picture/index', 0, 'C', 1, '', '', '2023-03-01 16:00:38', '2023-03-01 16:00:38');

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50)  NULL DEFAULT '' COMMENT '模块标题',
  `business_type` int NULL DEFAULT 0 COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100)  NULL DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10)  NULL DEFAULT '' COMMENT '请求方式',
  `operator_type` int NULL DEFAULT 0 COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50)  NULL DEFAULT '' COMMENT '操作人员',
  `oper_url` varchar(255)  NULL DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128)  NULL DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255)  NULL DEFAULT '' COMMENT '操作地点',
  `oper_param` varchar(2000)  NULL DEFAULT '' COMMENT '请求参数',
  `json_result` varchar(2000)  NULL DEFAULT '' COMMENT '返回参数',
  `status` int NULL DEFAULT 0 COMMENT '操作状态（0正常 1异常）',
  `error_msg` varchar(2000)  NULL DEFAULT '' COMMENT '错误消息',
  `oper_time` datetime NULL DEFAULT NULL COMMENT '操作时间',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_org
-- ----------------------------
DROP TABLE IF EXISTS `sys_org`;
CREATE TABLE `sys_org`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '标识',
  `parent_id` bigint NULL DEFAULT NULL COMMENT '父级标识',
  `org_name` varchar(50)  NULL DEFAULT NULL COMMENT '组织机构名称',
  `leader` varchar(50)  NULL DEFAULT NULL COMMENT '负责人',
  `phone` varchar(20)  NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(50)  NULL DEFAULT NULL COMMENT '邮箱',
  `remark` varchar(255)  NULL DEFAULT NULL COMMENT '备注',
  `status` int NULL DEFAULT NULL COMMENT 'status:状态(0-正常，1-禁用)',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_org
-- ----------------------------
INSERT INTO `sys_org` VALUES (1, 0, '测试机构', 'admin', '15123370111', 'guanmei@test.com', NULL, 0, '2023-02-01 15:24:47', '2023-03-08 18:26:32');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '标识',
  `role_name` varchar(50)  NULL DEFAULT NULL COMMENT '角色名称',
  `role_code` varchar(50)  NULL DEFAULT NULL COMMENT '角色编码',
  `remark` varchar(255)  NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `role_code`(`role_code` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', 'SUPER', '备注', NULL, '2023-03-08 18:18:49');

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `role_id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  PRIMARY KEY (`role_id`, `menu_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (1, 1);
INSERT INTO `sys_role_menu` VALUES (1, 2);
INSERT INTO `sys_role_menu` VALUES (1, 3);
INSERT INTO `sys_role_menu` VALUES (1, 4);
INSERT INTO `sys_role_menu` VALUES (1, 5);
INSERT INTO `sys_role_menu` VALUES (1, 6);
INSERT INTO `sys_role_menu` VALUES (1, 7);
INSERT INTO `sys_role_menu` VALUES (1, 8);
INSERT INTO `sys_role_menu` VALUES (1, 9);
INSERT INTO `sys_role_menu` VALUES (1, 10);
INSERT INTO `sys_role_menu` VALUES (1, 11);
INSERT INTO `sys_role_menu` VALUES (1, 12);
INSERT INTO `sys_role_menu` VALUES (1, 13);
INSERT INTO `sys_role_menu` VALUES (1, 14);
INSERT INTO `sys_role_menu` VALUES (1, 15);
INSERT INTO `sys_role_menu` VALUES (1, 16);
INSERT INTO `sys_role_menu` VALUES (1, 17);
INSERT INTO `sys_role_menu` VALUES (1, 18);
INSERT INTO `sys_role_menu` VALUES (1, 19);
INSERT INTO `sys_role_menu` VALUES (1, 20);
INSERT INTO `sys_role_menu` VALUES (1, 21);
INSERT INTO `sys_role_menu` VALUES (1, 22);
INSERT INTO `sys_role_menu` VALUES (1, 23);
INSERT INTO `sys_role_menu` VALUES (1, 24);
INSERT INTO `sys_role_menu` VALUES (1, 25);
INSERT INTO `sys_role_menu` VALUES (1, 30);
INSERT INTO `sys_role_menu` VALUES (1, 31);
INSERT INTO `sys_role_menu` VALUES (1, 32);
INSERT INTO `sys_role_menu` VALUES (1, 33);
INSERT INTO `sys_role_menu` VALUES (1, 34);
INSERT INTO `sys_role_menu` VALUES (1, 35);
INSERT INTO `sys_role_menu` VALUES (1, 36);
INSERT INTO `sys_role_menu` VALUES (1, 37);
INSERT INTO `sys_role_menu` VALUES (1, 38);
INSERT INTO `sys_role_menu` VALUES (1, 39);
INSERT INTO `sys_role_menu` VALUES (1, 40);
INSERT INTO `sys_role_menu` VALUES (1, 41);
INSERT INTO `sys_role_menu` VALUES (1, 42);
INSERT INTO `sys_role_menu` VALUES (1, 43);
INSERT INTO `sys_role_menu` VALUES (1, 44);
INSERT INTO `sys_role_menu` VALUES (1, 45);
INSERT INTO `sys_role_menu` VALUES (1, 46);
INSERT INTO `sys_role_menu` VALUES (1, 47);
INSERT INTO `sys_role_menu` VALUES (1, 48);
INSERT INTO `sys_role_menu` VALUES (1, 49);
INSERT INTO `sys_role_menu` VALUES (1, 50);
INSERT INTO `sys_role_menu` VALUES (1, 51);
INSERT INTO `sys_role_menu` VALUES (1, 52);
INSERT INTO `sys_role_menu` VALUES (1, 53);
INSERT INTO `sys_role_menu` VALUES (1, 54);
INSERT INTO `sys_role_menu` VALUES (1, 55);
INSERT INTO `sys_role_menu` VALUES (1, 56);
INSERT INTO `sys_role_menu` VALUES (1, 57);
INSERT INTO `sys_role_menu` VALUES (1, 58);
INSERT INTO `sys_role_menu` VALUES (1, 59);
INSERT INTO `sys_role_menu` VALUES (1, 60);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '标识',
  `org_id` bigint NULL DEFAULT NULL COMMENT '机构标识',
  `user_name` varchar(50)  NOT NULL COMMENT '用户号',
  `password` varchar(255)  NULL DEFAULT NULL COMMENT '密码',
  `nick_name` varchar(50)  NULL DEFAULT NULL COMMENT '昵称',
  `email` varchar(50)  NULL DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20)  NULL DEFAULT NULL COMMENT '电话',
  `gender` int NULL DEFAULT NULL COMMENT '性别（0男，1女）',
  `remark` varchar(255)  NULL DEFAULT NULL COMMENT '备注',
  `status` int NULL DEFAULT NULL COMMENT '用户状态(0-正常，1-禁用)',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `user_name`(`user_name` ASC) USING BTREE
) ENGINE = InnoDB  CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 1, 'admin', '$2a$10$uvzHLUAF54SWzbVOPhx7e.91VooE6tSBQAXjTzQL0ury2UC.bK2AC', '超级管理员', '2544964244@qq.com', '15484851552', 0, '无', 0, '2023-01-30 16:44:19', '2023-02-14 11:07:40');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1);

-- ----------------------------
-- Table structure for upload_temporary
-- ----------------------------
DROP TABLE IF EXISTS `upload_temporary`;
CREATE TABLE `upload_temporary`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '上传图片临时表主键id',
  `file_name` varchar(255)  NULL DEFAULT NULL COMMENT '图片名称',
  `user_id` bigint NOT NULL DEFAULT 0 COMMENT '用户id',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '上传文件临时表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of upload_temporary
-- ----------------------------
