

package ${basepackage}.web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

/**
 * @author py
 */
@SpringBootApplication
@EnableConfigurationProperties
@MapperScan({"com.gm.anepoch.*.service.dao","com.gm.anepoch.${basepackage}.**.mapper"})
@ComponentScans(value = {@ComponentScan("com.gm.anepoch.base.commons"), @ComponentScan("com.gm.anepoch.*")})
public class Application extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    /**
     * //为了打包spring-boot项目
     *
     * @param builder builder
     */
    @Override
    protected SpringApplicationBuilder configure(
            SpringApplicationBuilder builder) {
        return builder.sources(this.getClass());
    }

}
