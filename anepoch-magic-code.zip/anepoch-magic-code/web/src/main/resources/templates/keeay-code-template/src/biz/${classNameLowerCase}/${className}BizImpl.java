<#include "/custom.include">
<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>   
<#assign classNameLowerCase = className?lower_case>   
<#assign pkJavaType = table.idColumn.javaType>   

package ${basepackage}.bize;

import ${basepackage_meta}.base.commons.utils.ConditionUtils;
import ${basepackage}.service.model.*;
import ${basepackage}.biz.${classNameLowerCase}.bo.*;
import ${basepackage}.service.service.${classNameLowerCase}.${className}Service;
import ${basepackage}.biz.${classNameLowerCase}.converter.${className}BoConverter;
import ${basepackage_meta}.base.commons.monitor.BaseBizTemplate;
import ${basepackage_meta}.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author AI Admin
 */
@Service
@Slf4j
public class ${className}BizImpl implements ${className}Biz {
	@Resource
	private ${className}Service ${classNameFirstLower}Service;

	/**
	 * 新增 record
	 *
	 * @param add${className}Bo add${className}Bo
	 * @return success true orElse false
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean add(${className}Bo add${className}Bo) {
		return new BaseBizTemplate<Boolean>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(add${className}Bo), "add${className}Bo is null");
		}
			@Override
			protected Boolean process() {
				//新增角色信息
				${className} new${className} = ${className}BoConverter.convertTo${className}(add${className}Bo);
				${classNameFirstLower}Service.insert(new${className});
				return true;
			}
		}.execute();
		}

	/**
	 * 修改 record
	 *
	 * @param edit${className}Bo edit${className}Bo
	 * @return success true orElse false
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean editById(${className}Bo edit${className}Bo) {
		return new BaseBizTemplate<Boolean>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(edit${className}Bo), "edit${className}Bo is null");
				ConditionUtils.checkArgument(Objects.nonNull(edit${className}Bo.getId()), "edit${className}Bo id is null");
			}
			@Override
			protected Boolean process() {
				${className} old${className} = ${classNameFirstLower}Service.getDetailById(edit${className}Bo.getId());
				ConditionUtils.checkArgument(Objects.nonNull(old${className}), "old${className} is null");
				//修改记录
				${className} waitToUpdate = ${className}BoConverter.convertTo${className}(edit${className}Bo);
				${classNameFirstLower}Service.update(waitToUpdate);
				return true;
			}
		}.execute();
	}

	/**
	 * 查询record集合
	 *
	 * @param query${className}Bo query${className}Bo
	 * @return record list
	 */
	@Override
	public List<${className}Bo> list(${className}Bo query${className}Bo) {
		return new BaseBizTemplate<List<${className}Bo>>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(query${className}Bo), "query${className}Bo is null");
			}

			@Override
			protected List<${className}Bo> process() {
				${className} ${classNameFirstLower}Query = ${className}BoConverter.convertTo${className}(query${className}Bo);
				List<${className}> fromDbList = ${classNameFirstLower}Service.list(${classNameFirstLower}Query);
				if(CollectionUtils.isEmpty(fromDbList)){
					return Lists.newArrayList();
				}
				return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList),${className}Bo.class);
			}}.execute();
	}

	/**
	 * 查询record
	 *
	 * @param recordId recordId
	 * @return record orElse null
	 */
	@Override
	public ${className}Bo fetchDetailById(Long recordId){
		return new BaseBizTemplate<${className}Bo>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
			}

			@Override
			protected ${className}Bo process() {
				${className} fromDb = ${classNameFirstLower}Service.getDetailById(recordId);
				if(Objects.isNull(fromDb)){
					return null;
				}
				return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb),${className}Bo.class);
			}}.execute();
		}
}

