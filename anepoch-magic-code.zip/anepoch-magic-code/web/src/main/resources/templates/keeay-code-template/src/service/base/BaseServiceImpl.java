
package ${basepackage}.service.impl;

import ${basepackage}.service.dao.BaseMapper;
import ${basepackage}.service.service.base.BaseService;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.Serializable;
import java.util.List;

/**
 * @author AI Admin
 */
public abstract class BaseServiceImpl<T, PK extends Serializable> implements BaseService<T, PK> {
    @Autowired
    private BaseMapper<T> baseMapper;

    public BaseServiceImpl() {
    }

    @Override
    public Boolean insert(T record) {
        return this.baseMapper.insert(record) > 0;
    }

    @Override
    public Boolean delete(T record) {
        return this.baseMapper.delete(record) > 0;
    }

    @Override
    public Boolean update(T record) {
        return this.baseMapper.update(record) > 0;
    }

    @Override
    public List<T> selectList(T condition) {
        return this.baseMapper.list(condition);
    }

    @Override
    public T selectDetailById(Long id) {
        return this.baseMapper.getDetailById(id);
    }


}