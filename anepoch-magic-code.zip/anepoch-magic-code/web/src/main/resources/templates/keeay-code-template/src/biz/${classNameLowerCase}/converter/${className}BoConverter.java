<#include "/macro.include"/>
<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
import ${basepackage}.service.model.*;
import ${basepackage}.biz.${classNameLowerCase}.bo.*;
import ${basepackage_meta}.base.commons.utils.JsonMoreUtils;
import java.util.Objects;
import lombok.Data;
/**
 * @author AI Admin
 */
@Data
public class ${className}BoConverter {
	public static ${className} convertTo${className}(${className}Bo targetBo) {
		if (Objects.isNull(targetBo)) {
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(targetBo),${className}.class);
		//或者构建你的实际逻辑
//		return ${className}.builder()
////				//fit your code
////				.build();
	}
}


