<#include "/custom.include">
<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>   
<#assign classNameLowerCase = className?lower_case>   
<#assign pkJavaType = table.idColumn.javaType>   

package ${basepackage}.biz;

import ${basepackage}.biz.${classNameLowerCase}.bo.*;
import java.util.List;


/**
 * @author AI Admin
 */
public interface ${className}Biz {
	/**
	 * 新增 record
	 *
	 * @param add${className}Bo add${className}Bo
	 * @return success true orElse false
	 */
	boolean add(${className}Bo add${className}Bo);

	/**
	 * 修改 record
	 *
	 * @param edit${className}Bo edit${className}Bo
	 * @return success true orElse false
	 */
	boolean editById(${className}Bo edit${className}Bo);
	/**
	 * 查询record集合
	 * @param query${className}Bo query${className}Bo
	 * @return record list
	 */
	List<${className}Bo> list(${className}Bo query${className}Bo);

	/**
	 * 查询record detail
	 * @param recordId recordId
	 * @return record detail
	 */
	${className}Bo fetchDetailById(Long recordId);
}

