<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
package ${basepackage}.service.impl;

import org.springframework.stereotype.Service;
import ${basepackage}.service.service.BaseServiceImpl;
import ${basepackage}.service.model.*;

/**
 * @author AI Admin
 */
@Service
public class ${className}ServiceImpl extends BaseServiceImpl<${className},Long> implements ${className}Service {
}
