<#include "/custom.include">
<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>   
<#assign classNameLowerCase = className?lower_case>   
<#assign pkJavaType = table.idColumn.javaType>   

package ${basepackage_controller};

import ${basepackage}.biz.${classNameLowerCase}.${className}Biz;
import ${basepackage}.biz.${classNameLowerCase}.bo.${className}Bo;
import ${basepackage}.web.controller.${classNameLowerCase}.request.*;
import ${basepackage}.web.controller.${classNameLowerCase}.response.*;
import ${basepackage_meta}.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author AI Admin
 */
@RestController
@RequestMapping("api/${classNameLowerCase}")
public class ${className}Controller{
	@Resource
	private ${className}Biz ${classNameFirstLower}Biz;
	
	<#assign isFK = 0 />
	<#assign columnName = "" />
	<#assign javaType = "" />
	<#list table.columns as column>
	<#if (column.remarks)?index_of("#LFK") &gt; 0 >
		<#assign isFK = 1 />
		<#assign javaType = column.javaType />
		<#assign columnName = column.columnName />
	</#if>
	</#list>

	/**
	 * 新增记录
	 *
	 * @param add${className}Request add${className}Request
	 * @return success true orElse false
	 */
	@PostMapping("add")
	public boolean add(@RequestBody ${className}AddRequest add${className}Request) {
		${className}Bo add${className}Bo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(add${className}Request), ${className}Bo.class);
		return ${classNameFirstLower}Biz.add(add${className}Bo);
	}

	/**
	 * 修改记录
	 *
	 * @param edit${className}Request edit${className}Request
	 * @return success true orElse false
	 */
	@PostMapping("editById")
	public boolean edit(@RequestBody ${className}EditRequest edit${className}Request) {
		${className}Bo edit${className}Bo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(edit${className}Request), ${className}Bo.class);
		return ${classNameFirstLower}Biz.editById(edit${className}Bo);
	}

	/**
	 * 记录列表
	 *
	 * @param query${className}Request query${className}Request
	 * @return list
	 */
	@PostMapping("list")
	public List<${className}ListResponse> list(@RequestBody ${className}QueryRequest query${className}Request) {
		${className}Bo query${className}Bo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(query${className}Request), ${className}Bo.class);
		List<${className}Bo> resultList = ${classNameFirstLower}Biz.list(query${className}Bo);
		if(CollectionUtils.isEmpty(resultList)){
			return Lists.newArrayListWithCapacity(0);
		}
		return JsonMoreUtils.ofList(JsonMoreUtils.toJson(resultList),${className}ListResponse.class);
	}

	/**
	 * 通过id获取数据详情
	 *
	 * @param recordId recordId
	 * @return 数据详情
	 */
	@GetMapping("fetchDetailById")
	public ${className}DetailResponse fetchDetailById(Long recordId) {
		${className}Bo result = ${classNameFirstLower}Biz.fetchDetailById(recordId);
		if(Objects.isNull(result)){
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(result),${className}DetailResponse.class);
	}
}

