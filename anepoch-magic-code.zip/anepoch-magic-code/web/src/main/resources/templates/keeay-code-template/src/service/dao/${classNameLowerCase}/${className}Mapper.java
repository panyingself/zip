<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
package ${basepackage}.mapper;

import ${basepackage}.service.model.*;
import ${basepackage}.service.dao.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * @author AI Admin
 */
@Repository
public interface ${className}Mapper extends BaseMapper<${className}>{
}
