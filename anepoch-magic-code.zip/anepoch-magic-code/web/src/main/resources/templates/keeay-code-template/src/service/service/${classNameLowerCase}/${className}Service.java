<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
package ${basepackage}.repository;

import ${basepackage}.service.model.*;
import ${basepackage}.service.service.BaseService;

/**
 * @author AI Admin
 */
public interface ${className}Service extends BaseService<${className}, Long>{
}
