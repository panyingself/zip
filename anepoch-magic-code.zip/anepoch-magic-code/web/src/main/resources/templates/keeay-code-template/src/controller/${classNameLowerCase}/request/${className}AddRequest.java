<#include "/macro.include"/>
        <#assign className = table.className>
        <#assign classNameFirstLower = className?uncap_first>
        <#assign classNameLowerCase = className?lower_case>
package ${basepackage}.service.model;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author AI Admin
 */
@Data
public class ${className}AddRequest {
<@generateFields/>

        @Override
        public String toString () {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}
<#macro generateFields>
<#list table.columns as column>
    /** ${column.columnAlias} */
    private ${column.javaType} ${column.columnNameLower};

<#if (column.remarks)?index_of("#LFK") &gt; 0 >
private ${column.javaType} foreignKey;
</#if>
</#list>
</#macro>


