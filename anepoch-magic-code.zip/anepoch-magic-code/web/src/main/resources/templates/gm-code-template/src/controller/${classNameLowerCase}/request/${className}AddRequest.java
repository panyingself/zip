<#include "/macro.include"/>
        <#assign className = table.className>
        <#assign classNameFirstLower = className?uncap_first>
        <#assign classNameLowerCase = className?lower_case>
        package ${basepackage}.commons.model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "${className}AddRequest")
@Data
public class ${className}AddRequest {
<@generateFields/>

        @Override
        public String toString () {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}
<#macro generateFields>
<#list table.columns as column>
        @ApiModelProperty(value = "${column.columnNameLower}", name = "${column.columnNameLower}")
        private ${column.javaType} ${column.columnNameLower};

<#if (column.remarks)?index_of("#LFK") &gt; 0 >
private ${column.javaType} foreignKey;
</#if>
</#list>
</#macro>


