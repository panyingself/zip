<#include "/macro.include"/>
        <#assign className = table.className>
        <#assign classNameFirstLower = className?uncap_first>
        <#assign classNameLowerCase = className?lower_case>
package ${basepackage}.web.request;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import lombok.Data;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "${className}EditRequest")
@Data
public class ${className}EditRequest extends ${className}AddRequest{
        @ApiModelProperty(value = "id", name = "id")
        private Long id;

        @Override
        public String toString() {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}



