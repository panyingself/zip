<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
package ${basepackage}.repository;

import ${basepackage}.commons.model.*;
import ${basepackage}.service.service.BaseService;
public interface ${className}Service extends BaseService<${className}, Long>{
}
