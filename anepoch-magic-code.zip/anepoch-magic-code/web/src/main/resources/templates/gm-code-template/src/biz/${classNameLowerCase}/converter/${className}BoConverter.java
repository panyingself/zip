<#include "/macro.include"/>
<#assign className = table.className>
<#assign classNameFirstLower = className?uncap_first>
<#assign classNameLowerCase = className?lower_case>
import ${basepackage}.commons.model.*;
import ${basepackage}.biz.${classNameLowerCase}.bo.*;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import java.util.Objects;
import lombok.Data;
/**
 * @author py
 * @date 2019/4
 */
@Data
public class ${className}BoConverter {
	public static ${className} convertTo${className}(${className}Bo targetBo) {
		if (Objects.isNull(targetBo)) {
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(targetBo),${className}.class);
		//或者构建你的实际逻辑
//		return ${className}.builder()
////				//fit your code
////				.build();
	}
}


