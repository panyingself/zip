
function toGenerate(url){
    //执行Db-form表达提交
    $('#project_generate_form').submit();

}

function reset() {
    $("#project_generate_form").reset();
}