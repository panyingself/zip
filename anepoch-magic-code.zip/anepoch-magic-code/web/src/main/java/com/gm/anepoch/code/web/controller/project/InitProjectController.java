/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.web.controller.project;

import com.gm.anepoch.code.biz.magic.DbConfigBusiness;
import com.gm.anepoch.code.commons.model.ColumnInfo;
import com.gm.anepoch.code.commons.model.DbconfigInfo;
import com.gm.anepoch.code.commons.model.TableInfo;
import com.gm.anepoch.code.web.controller.base.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/6 下午3:30.
 */
@Controller
@RequestMapping("/initproject")
public class InitProjectController extends BaseController {
    @Resource
    private DbConfigBusiness dbConfigBusiness;

    /**
     * Method:
     * Description: 初始化数据库配置信息
     *
     * @param model
     * @return java.lang.String
     * @Author panying
     * @Data 2018/7/6 下午3:30
     */
    @RequestMapping(value = "/toIndex", method = RequestMethod.GET)
    public String init(Model model) {
        return "frontend/project/project_generate";
    }

    /**
     * Method:
     * Description: 初始化数据库配置信息
     *
     * @param model
     * @return java.lang.String
     * @Author panying
     * @Data 2018/7/6 下午3:30
     */
    @RequestMapping(value = "/toProjectTemplateChoose", method = RequestMethod.GET)
    public String toProjectTemplateChoose(Model model) {
        return "frontend/project/project_generate_template_choose";
    }
}
