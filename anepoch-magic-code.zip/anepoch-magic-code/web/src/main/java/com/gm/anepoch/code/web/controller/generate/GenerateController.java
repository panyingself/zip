/*
 * Copyright (c) 2018. Toxic
 */

package com.gm.anepoch.code.web.controller.generate;

import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.code.biz.magic.GenerateBusiness;
import com.gm.anepoch.code.biz.magic.GenerateProjectBiz;
import com.gm.anepoch.code.biz.magic.bo.ProjectGenerateBo;
import com.gm.anepoch.code.commons.model.*;
import com.gm.anepoch.code.commons.utils.FileUtils;
import com.gm.anepoch.code.commons.utils.ZipFileUtils;
import com.gm.anepoch.code.web.controller.base.BaseController;
import com.gm.anepoch.code.web.controller.generate.request.ProjectGenerateRequest;
import org.apache.tools.zip.ZipOutputStream;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Objects;

/**
 * Title:
 * Description:
 *
 * @author py
 * @date 2018/7/9 下午3:54.
 */
@Controller
@RequestMapping("/generate")
public class GenerateController extends BaseController {
    //    private static final String CODE_TEMPLATE_NAME = "gm-code-template";
    private static final String CODE_TEMPLATE_NAME = "keeay-code-template";

    @Resource
    private GenerateBusiness generateBusiness;
    @Resource
    private GenerateProjectBiz generateProjectBiz;

    /**
     * 生成代码
     */
    @RequestMapping(value = "/code", method = RequestMethod.POST)
    public String generateCode(DbconfigInfo dbconfigInfo, TableInfo tableInfo, CodeConfig codeConfig, HttpServletResponse response) {
        String model = tableInfo.getComments().substring(tableInfo.getComments().indexOf("#") + 1);
        codeConfig.setBasepackage_meta("com.keeay.anepoch");
        codeConfig.setBasepackage("com.keeay.anepoch." + model);
        codeConfig.setPath_model("" + model.replaceAll("\\.", "/"));
        codeConfig.setPath_mybatis("mybatis." + model);
        codeConfig.setPath_admin("admin." + model);
        codeConfig.setPath_front("front." + model);
        codeConfig.setPath_html5("html5." + model);

        try {
            codeConfig.setOutRoot(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId());
            codeConfig.setTemplateName(ResourceUtils.getURL("classpath:templates/" + CODE_TEMPLATE_NAME).getPath());
//            codeConfig.setTemplateName(ResourceUtils.getURL("classpath:templates/base").getPath());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //生成数据
        generateBusiness.generator(dbconfigInfo, tableInfo, codeConfig);

        //打包下载
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.setHeader("Content-Disposition", "attachment; filename=src.zip");
        System.out.println("in BatchDownload................");
        try {
            ZipFileUtils zip = new ZipFileUtils();
            ZipOutputStream zos = new ZipOutputStream(response.getOutputStream());
            zip.zip(new File(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId() + "/src"), zos, "");
            zos.flush();
            zos.close();

            //删除目录
            FileUtils.DeleteFolder(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 生成代码
     */
    @GetMapping(value = "/project")
    public String generateProject(ProjectGenerateRequest projectGenerateRequest, HttpServletResponse response) {
        String model = "pytest";
        CodeConfig codeConfig = new CodeConfig();
        codeConfig.setBasepackage("com.gm.anepoch." + model);
        codeConfig.setPath_model("" + model.replaceAll("\\.", "/"));
        codeConfig.setPath_mybatis("mybatis." + model);
        codeConfig.setPath_admin("admin." + model);
        codeConfig.setPath_front("front." + model);
        codeConfig.setPath_html5("html5." + model);
        try {
            codeConfig.setOutRoot(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId());
            //验证框架类型
            if (Objects.equals(0, projectGenerateRequest.getProjectType())) {
                codeConfig.setTemplateName(ResourceUtils.getURL("classpath:templates/gm-project-template").getPath());
            } else if (Objects.equals(1, projectGenerateRequest.getProjectType())) {
                codeConfig.setTemplateName(ResourceUtils.getURL("classpath:templates/gm-big-project-template").getPath());
            } else {
                throw new UnsupportedOperationException("不支持当前类型的框架");
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //生成数据
        generateProjectBiz.generator(JsonMoreUtils.toBean(JsonMoreUtils.toJson(projectGenerateRequest), ProjectGenerateBo.class), codeConfig);
        //打包下载
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.setHeader("Content-Disposition", "attachment; filename=" + projectGenerateRequest.getProjectName() + ".zip");
        System.out.println("in BatchDownload................");
        try {
            ZipFileUtils zip = new ZipFileUtils();
            ZipOutputStream zos = new ZipOutputStream(response.getOutputStream());
            zip.zip(new File(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId()), zos, "");
            zos.flush();
            zos.close();

            //删除目录
            FileUtils.DeleteFolder(ResourceUtils.getURL("classpath:templates/upload").getPath() + request.getSession().getId());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
