package com.gm.anepoch.code.web.controller;

import lombok.Data;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/7/24 - 22:04
 */
@Data
public class DataFrom {
    private Long id;
    private String projectNo;
    private String projectName;
    private String category;
    private String businessLine;
    private String period;
    private String status;
    private String remark;
}
