package com.gm.anepoch.code.web.controller;

import com.google.common.collect.Lists;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/7/24 - 22:03
 */
@RestController
@RequestMapping("/testForData")
public class TestForDataController {

    @RequestMapping("/testForData1")
    public List<DataFrom> getData() {
        List<DataFrom> list = Lists.newArrayList();
        DataFrom dataFrom1 = new DataFrom();
        dataFrom1.setCategory("产品");
        DataFrom dataFrom2 = new DataFrom();
        dataFrom2.setCategory("定制");
        list.add(dataFrom1);
        list.add(dataFrom2);
        return list;
    }
}
