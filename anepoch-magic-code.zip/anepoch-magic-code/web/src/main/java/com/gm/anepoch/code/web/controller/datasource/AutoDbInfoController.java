/*
 * Web Site: http://www.toxic.com py
 * Since 2014 - 2018
 */


package com.gm.anepoch.code.web.controller.datasource;

import com.gm.anepoch.code.biz.magic.AutoDbInfoBusiness;
import com.gm.anepoch.code.commons.model.AutoDbInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/admin/autodbinfo")
public class AutoDbInfoController {
    @Autowired
    private AutoDbInfoBusiness autoDbInfoBusiness;

    /**
     * 跳转至添加页面
     *
     * @param
     * @return java.lang.String
     * @throws
     * @author py
     * @date 9:23 PM
     */
    @RequestMapping(value = "/add")
    public String toAdd(Model model) {
        return "frontend/datasource/datasource_add";
    }

    /**
     * 添加操作
     *
     * @param
     * @return com.toxic.generate.tool.vo.ResultVo
     * @throws
     * @author py
     * @date 9:24 PM
     */
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public void addJob(AutoDbInfo autoDbInfo) {
        autoDbInfoBusiness.insertAutoDbInfo(autoDbInfo);
    }

    /**
     * 跳转至db_edit页面
     *
     * @param
     * @return java.lang.String
     * @throws
     * @author py
     * @date 9:18 PM
     */
    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public String toEdit(Model model, Long id) {
        model.addAttribute("db", autoDbInfoBusiness.getAutoDbInfoById(id));
        return "frontend/datasource/datasource_edit";
    }

    /**
     * 编辑
     *
     * @param
     * @return com.toxic.generate.tool.vo.ResultVo
     * @throws
     * @author py
     * @date 9:22 PM
     */
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    @ResponseBody
    public void realEdit(AutoDbInfo autoDbInfo) {
        int row = autoDbInfoBusiness.updateAutoDbInfo(autoDbInfo);
    }

    /**
     * 删除
     *
     * @param
     * @return com.toxic.generate.tool.vo.ResultVo
     * @throws
     * @author py
     * @date 9:23 PM
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String realDelete(Model model, Long id) {
        autoDbInfoBusiness.deleteAutoDbInfo(id);
        return "frontend/datasource/datasource_list";
    }
}

