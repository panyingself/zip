package com.gm.anepoch.digitalbird.service.service.smstemplateinfo;

import com.gm.anepoch.digitalbird.service.dao.smstemplateinfo.SmsTemplateInfoMapper;
import org.springframework.stereotype.Service;
import com.gm.anepoch.digitalbird.service.service.BaseServiceImpl;
import com.gm.anepoch.digitalbird.commons.model.*;

import javax.annotation.Resource;

/**
 * @author pany
 */
@Service
public class SmsTemplateInfoServiceImpl extends BaseServiceImpl<SmsTemplateInfo, Long> implements SmsTemplateInfoService {
    @Resource
    private SmsTemplateInfoMapper smsTemplateInfoMapper;

    /**
     * 查询record detail
     *
     * @param templateCode templateCode
     * @return record detail
     */
    @Override
    public SmsTemplateInfo getDetailByCode(String templateCode) {
        return smsTemplateInfoMapper.getDetailByCode(templateCode);
    }
}
