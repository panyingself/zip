package com.gm.anepoch.digitalbird.service.service.smssendrecord;

import com.gm.anepoch.digitalbird.service.dao.smssendrecord.SmsSendRecordMapper;
import org.springframework.stereotype.Service;
import com.gm.anepoch.digitalbird.service.service.BaseServiceImpl;
import com.gm.anepoch.digitalbird.commons.model.*;

import javax.annotation.Resource;
/**
 *
 * @author py
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Service
public class SmsSendRecordServiceImpl extends BaseServiceImpl<SmsSendRecord, Long> implements SmsSendRecordService {
    @Resource
    private SmsSendRecordMapper smsSendRecordMapper;

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appName
     * @param biz          biz
     * @param templateCode templateCode
     * @param phone        phone
     * @return record
     */
    @Override
    public SmsSendRecord getNewestRecord(String appName, String biz, String templateCode, String phone) {
        return smsSendRecordMapper.getNewestRecord(appName, biz, templateCode, phone);
    }
}
