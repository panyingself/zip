package com.gm.anepoch.digitalbird.service.service;

import com.gm.anepoch.digitalbird.service.dao.BaseMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;
import java.util.List;

/**
 * @author py
 * @date 2018/11/26 3:52 PM.
 */
public abstract class BaseServiceImpl<T, PK extends Serializable> implements BaseService<T, PK> {
    @Autowired
    private BaseMapper<T> baseMapper;

    public BaseServiceImpl() {
    }

    @Override
    public Boolean insert(T record) {
        return this.baseMapper.insert(record) > 0;
    }

    @Override
    public Boolean delete(T record) {
        return this.baseMapper.delete(record) > 0;
    }

    @Override
    public Boolean update(T record) {
        return this.baseMapper.update(record) > 0;
    }

    @Override
    public List<T> list(T condition) {
        return this.baseMapper.list(condition);
    }

    @Override
    public T getDetailById(Long id) {
        return this.baseMapper.getDetailById(id);
    }


}