package com.gm.anepoch.digitalbird.service.service.emailsendrecord;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.service.dao.emailsendrecord.EmailSendRecordMapper;
import org.springframework.stereotype.Service;
import com.gm.anepoch.digitalbird.service.service.BaseServiceImpl;
import com.gm.anepoch.digitalbird.commons.model.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author pany
 */
@Service
public class EmailSendRecordServiceImpl extends BaseServiceImpl<EmailSendRecord, Long> implements EmailSendRecordService {
    @Resource
    private EmailSendRecordMapper emailSendRecordMapper;

    /**
     * 查询需要发送的数据集
     *
     * @param recordSize recordSize
     * @return list
     */
    @Override
    public List<EmailSendRecord> listForSendEmailJob(Long recordSize) {
        if (Objects.isNull(recordSize)) {
            recordSize = 10L;
        }
        return emailSendRecordMapper.listForSendEmailJob(recordSize);
    }

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appId
     * @param biz          biz
     * @param templateCode templateCode
     * @param email        email
     * @return record
     */
    @Override
    public EmailSendRecord getNewestRecord(String appName, String biz, String templateCode, String email) {
        return emailSendRecordMapper.getNewestRecord(appName, biz, templateCode, email);
    }
}
