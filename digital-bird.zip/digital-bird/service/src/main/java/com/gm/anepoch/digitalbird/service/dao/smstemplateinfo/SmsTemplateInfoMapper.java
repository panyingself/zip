package com.gm.anepoch.digitalbird.service.dao.smstemplateinfo;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.dao.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author py
 * @date 2019/4
 */
@Repository
public interface SmsTemplateInfoMapper extends BaseMapper<SmsTemplateInfo> {
    /**
     * 查询record detail
     *
     * @param templateCode templateCode
     * @return record detail
     */
    SmsTemplateInfo getDetailByCode(@Param("templateCode") String templateCode);
}
