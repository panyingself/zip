package com.gm.anepoch.digitalbird.service.dao.ossroutconfig;

import com.gm.anepoch.digitalbird.commons.model.OssRouteConfig;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author py
 * @date 2019/4
 */
@Repository
public interface OssRouteConfigMapper {
    /**
     * 获取所有列表数据
     *
     * @return data list all
     */
    List<OssRouteConfig> getAllList();
    /**
     * 获取业务类型数据
     * @param bizType 业务类型
     * @return data list all
     */
    OssRouteConfig getInfoByBizType(@Param("bizType") String bizType);
}
