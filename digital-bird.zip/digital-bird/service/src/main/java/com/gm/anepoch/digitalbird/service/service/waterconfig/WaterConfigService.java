package com.gm.anepoch.digitalbird.service.service.waterconfig;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.BaseService;
/**
 * @author pany
 */
public interface WaterConfigService extends BaseService<WaterConfig, Long>{
}
