package com.gm.anepoch.digitalbird.service.service.smstemplateinfo;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.BaseService;
/**
 *
 * @author py
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
public interface SmsTemplateInfoService extends BaseService<SmsTemplateInfo, Long>{
    /**
     * 查询record detail
     *
     * @param templateCode templateCode
     * @return record detail
     */
    SmsTemplateInfo getDetailByCode(String templateCode);
}
