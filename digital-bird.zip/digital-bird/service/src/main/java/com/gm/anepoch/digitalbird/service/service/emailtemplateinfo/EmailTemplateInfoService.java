package com.gm.anepoch.digitalbird.service.service.emailtemplateinfo;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.BaseService;

/**
 * @author pany
 */
public interface EmailTemplateInfoService extends BaseService<EmailTemplateInfo, Long> {
    /**
     * 查询record
     *
     * @param code code
     * @return record orElse null
     */
    EmailTemplateInfo getDetailByCode(String code);
}
