package com.gm.anepoch.digitalbird.service.service.emailsendrecord;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.BaseService;

import java.util.List;

/**
 * @author pany
 */
public interface EmailSendRecordService extends BaseService<EmailSendRecord, Long> {
    /**
     * 查询需要发送的数据集
     *
     * @param recordSize recordSize
     * @return list
     */
    List<EmailSendRecord> listForSendEmailJob(Long recordSize);

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appName
     * @param biz          biz
     * @param templateCode templateCode
     * @param email        email
     * @return record
     */
    EmailSendRecord getNewestRecord(String appName, String biz, String templateCode, String email);
}
