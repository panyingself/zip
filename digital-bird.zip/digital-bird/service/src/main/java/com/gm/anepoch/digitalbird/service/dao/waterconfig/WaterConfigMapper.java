package com.gm.anepoch.digitalbird.service.dao.waterconfig;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.dao.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * @author py
 * @date 2019/4
 */
@Repository
public interface WaterConfigMapper extends BaseMapper<WaterConfig>{
}
