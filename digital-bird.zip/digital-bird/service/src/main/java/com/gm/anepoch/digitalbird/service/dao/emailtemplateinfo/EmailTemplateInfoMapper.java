package com.gm.anepoch.digitalbird.service.dao.emailtemplateinfo;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.dao.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author py
 * @date 2019/4
 */
@Repository
public interface EmailTemplateInfoMapper extends BaseMapper<EmailTemplateInfo> {
    /**
     * 通过模板code查询record
     *
     * @param code code
     * @return record orElse null
     */
    EmailTemplateInfo getDetailByCode(@Param("code") String code);
}
