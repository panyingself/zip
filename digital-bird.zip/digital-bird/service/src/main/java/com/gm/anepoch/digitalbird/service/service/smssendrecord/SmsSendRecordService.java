package com.gm.anepoch.digitalbird.service.service.smssendrecord;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.BaseService;
/**
 *
 * @author py
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
public interface SmsSendRecordService extends BaseService<SmsSendRecord, Long> {

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appId        appId
     * @param biz          biz
     * @param templateCode templateCode
     * @param phone        phone
     * @return record
     */
    SmsSendRecord getNewestRecord(String appId, String biz, String templateCode, String phone);
}
