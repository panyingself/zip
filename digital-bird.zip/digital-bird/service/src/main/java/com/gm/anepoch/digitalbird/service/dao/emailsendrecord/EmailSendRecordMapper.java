package com.gm.anepoch.digitalbird.service.dao.emailsendrecord;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.dao.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author py
 * @date 2019/4
 */
@Repository
public interface EmailSendRecordMapper extends BaseMapper<EmailSendRecord> {
    /**
     * 查询待发送数据集
     *
     * @param recordSize recordSize
     * @return list
     */
    List<EmailSendRecord> listForSendEmailJob(@Param("recordSize") Long recordSize);
    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appName
     * @param biz          biz
     * @param templateCode templateCode
     * @param email        phone
     * @return record
     */
    EmailSendRecord getNewestRecord(@Param("appName") String appName, @Param("biz") String biz, @Param("templateCode") String templateCode, @Param("email") String email);
}
