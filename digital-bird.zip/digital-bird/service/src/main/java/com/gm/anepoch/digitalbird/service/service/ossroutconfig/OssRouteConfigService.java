package com.gm.anepoch.digitalbird.service.service.ossroutconfig;

import com.gm.anepoch.digitalbird.commons.model.OssRouteConfig;

import java.util.List;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 16:13
 */
public interface OssRouteConfigService {
    /**
     * 获取所有列表数据
     *
     * @return data list all
     */
    List<OssRouteConfig> getAllList();
    /**
     * 获取业务类型
     * @param bizType 业务类型
     * @return data list all
     */
    OssRouteConfig getInfoByBizType(String bizType);

}
