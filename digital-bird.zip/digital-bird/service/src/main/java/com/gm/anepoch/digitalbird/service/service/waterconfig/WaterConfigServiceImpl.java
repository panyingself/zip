package com.gm.anepoch.digitalbird.service.service.waterconfig;

import org.springframework.stereotype.Service;
import com.gm.anepoch.digitalbird.service.service.BaseServiceImpl;
import com.gm.anepoch.digitalbird.commons.model.*;

/**
 * @author pany
 */
@Service
public class WaterConfigServiceImpl extends BaseServiceImpl<WaterConfig,Long> implements WaterConfigService {
}
