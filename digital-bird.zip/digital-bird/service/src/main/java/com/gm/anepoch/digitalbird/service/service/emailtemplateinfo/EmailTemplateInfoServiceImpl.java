package com.gm.anepoch.digitalbird.service.service.emailtemplateinfo;

import com.gm.anepoch.digitalbird.service.dao.emailtemplateinfo.EmailTemplateInfoMapper;
import org.springframework.stereotype.Service;
import com.gm.anepoch.digitalbird.service.service.BaseServiceImpl;
import com.gm.anepoch.digitalbird.commons.model.*;

import javax.annotation.Resource;

/**
 * @author pany
 */
@Service
public class EmailTemplateInfoServiceImpl extends BaseServiceImpl<EmailTemplateInfo,Long> implements EmailTemplateInfoService {
    @Resource
    private EmailTemplateInfoMapper emailTemplateInfoMapper;
    @Override
    public EmailTemplateInfo getDetailByCode(String code) {
        return emailTemplateInfoMapper.getDetailByCode(code);
    }
}
