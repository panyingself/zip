package com.gm.anepoch.digitalbird.service.service.ossroutconfig;

import com.gm.anepoch.digitalbird.commons.model.OssRouteConfig;
import com.gm.anepoch.digitalbird.service.dao.ossroutconfig.OssRouteConfigMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 16:18
 */
@Service
public class OssRouteConfigServiceImpl implements OssRouteConfigService{
    @Resource
    private OssRouteConfigMapper ossRouteConfigMapper;
    /**
     * 获取所有列表数据
     *
     * @return data list all
     */
    @Override
    public List<OssRouteConfig> getAllList() {
        return ossRouteConfigMapper.getAllList();
    }

    @Override
    public OssRouteConfig getInfoByBizType(String bizType) {
        return ossRouteConfigMapper.getInfoByBizType(bizType);
    }
}
