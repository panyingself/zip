DROP TABLE IF EXISTS `email_send_record`;
CREATE TABLE `email_send_record`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `app_name` varchar(255) NOT NULL DEFAULT '' COMMENT '应用名',
  `biz` varchar(255) NOT NULL DEFAULT '' COMMENT '业务',
  `template_code` varchar(255) NULL DEFAULT NULL COMMENT '邮件模板code',
  `message_id` varchar(255) NOT NULL DEFAULT '' COMMENT '消息id',
  `address_from` varchar(255) NOT NULL COMMENT '发件人',
  `address_to` varchar(255) NOT NULL COMMENT '收件人',
  `address_cc` varchar(255) NULL DEFAULT '' COMMENT '抄送人',
  `address_bcc` varchar(255) NULL DEFAULT '' COMMENT '密送人',
  `subject` varchar(255) NOT NULL DEFAULT '' COMMENT '主题',
  `content` mediumtext NULL COMMENT '内容',
  `validate_code` varchar(255) NULL DEFAULT NULL COMMENT '验证码',
  `attachments` varchar(255)  NULL DEFAULT NULL COMMENT '附件信息: oss存储地址',
  `status` varchar(255)  NULL DEFAULT NULL COMMENT '状态: 待发送 - waited，发送成功 - success，发送失败 - failure',
  `retry_count` int(0) NULL DEFAULT 0 COMMENT '重试次数',
  `expire_time_count` bigint(0) NOT NULL COMMENT '过期时间计数(秒 - 模板快照)',
  `expire_time` datetime(0) NULL DEFAULT NULL COMMENT '过期时间',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_message_id`(`message_id`) USING BTREE COMMENT 'messageId唯一索引',
  INDEX `idx_query_normal`(`app_name`, `biz`, `status`) USING BTREE COMMENT '普通最左原则索引'
) ENGINE = InnoDB AUTO_INCREMENT = 1 COMMENT = '邮件发送记录';

DROP TABLE IF EXISTS `email_template_info`;
CREATE TABLE `email_template_info`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `code` varchar(255) NOT NULL COMMENT '模板code',
  `subject` varchar(255) NOT NULL DEFAULT '' COMMENT '邮件主题',
  `content` mediumtext NOT NULL COMMENT '邮件内容',
  `expire_time_count` bigint(0) NOT NULL COMMENT '过期时间计数(秒)',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `create_user` varchar(255) NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  `update_user` datetime(0) NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 COMMENT = '邮件模板信息';

INSERT INTO `digital-bird`.`email_template_info`(`id`, `code`, `subject`, `content`, `expire_time_count`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (1, 'digital-001', '数字化营销平台安全验证', '<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\">\r\n<style>\r\n    * {\r\n      margin: 0;\r\n      padding: 0;\r\n      box-sizing: border-box;\r\n    }\r\n    body {\r\n      display: flex;\r\n      justify-content: center;\r\n      padding-top: 40px;\r\n    }\r\n    .box {\r\n      width: 800px;\r\n      height: 468px;\r\n      background: #F6F9FF url(\"https://img.alicdn.com/imgextra/i3/1080040467/O1CN01o54On01FJvqzU4JNN_!!1080040467.png\") no-repeat center;\r\n      background-size: 100% 100%;\r\n      border-radius: 8px;\r\n	  margin: auto;\r\n    }\r\n    .box .tempBox {\r\n      padding: 40px 0 40px 40px;\r\n      height: 408px;\r\n    }\r\n    .box .logoBox {\r\n      font-size: 20px;\r\n      color: #18172B;\r\n      line-height: 38px;\r\n      font-weight: bold;\r\n      margin-bottom: 24px;\r\n    }\r\n    .box .logoBox .logo {\r\n      width: 36px;\r\n      height: 36px;\r\n      display: inline-block;\r\n      vertical-align: top;\r\n      margin-right: 8px;\r\n      background: url(\"https://img.alicdn.com/imgextra/i2/1734086020/O1CN01rcyNQj1uLDCrKwx2F_!!1734086020.png\") no-repeat center;\r\n	  background-size: 36px 36px;\r\n      border-radius: 4px;\r\n    }\r\n    .box .txt1 {\r\n      font-size: 16px;\r\n      color: #000;\r\n      line-height: 22px;\r\n    }\r\n    .box .yzmBox {\r\n      width: 200px;\r\n      height: 60px;\r\n      border: 8px;\r\n      margin-top: 24px;\r\n      margin-bottom: 24px;\r\n      background: #fff;\r\n	  text-align: center;\r\n	  font-size: 40px;\r\n      line-height: 60px;\r\n    }\r\n    .box .txt2 {\r\n      font-size: 14px;\r\n      color: rgba(0, 0, 0, 0.45);\r\n      line-height: 22px;\r\n    }\r\n    .box .wel {\r\n      margin-top: 24px;\r\n      color: rgba(0, 0, 0, 0.45);\r\n      font-size: 12px;\r\n    }\r\n    .box .wel a {\r\n      color: #5577FF;\r\n    }\r\n    .box .footer {\r\n      height: 60px;\r\n      line-height: 60px;\r\n      font-size: 24px;\r\n      color: #000;\r\n      text-align: center;\r\n      font-weight: bold;\r\n    }\r\n  </style>\r\n  <div class=\"box\">\r\n    <div class=\"tempBox\">\r\n      <div class=\"logoBox\"><span class=\"logo\"></span>冠美数字平台</div>\r\n      <div class=\"txt1\">您正在访问冠美数字营销平台</div>\r\n      <div class=\"txt1\">验证码 5 分钟有效，请及时使用。如非本人操作，请忽略该邮件。​</div>\r\n      <div class=\"yzmBox\">${code}</div>\r\n      <div class=\"txt2\">如超时未进入，可点击重新发送再次获取验证码；</div>\r\n      <div class=\"txt2\">若帐号已被锁定，请及时联系管理员或咨询在线客服；</div>\r\n      <div class=\"txt2\">为了确保您的帐户安全，帐号每14天需验证一次，验证通过主账号绑定的电子邮箱进行验证。</div>\r\n      <div class=\"wel\">欢迎访问:<a href=\"https://www.guanmeikj.com/\">https://www.guanmeikj.com/</a></div>\r\n    </div>\r\n    <div class=\"footer\">AI营销决策 . 全域数字运营服务平台</div>\r\n  </div>', 300, '2023-09-19 09:59:37', 'py', '2023-11-02 17:53:30', '2023-11-02 17:53:27');


DROP TABLE IF EXISTS `sms_send_record`;
CREATE TABLE `sms_send_record`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `app_name` varchar(255) NULL DEFAULT NULL COMMENT '应用名',
  `biz` varchar(255) NULL DEFAULT NULL COMMENT '业务',
  `receive_phone` varchar(20) NULL DEFAULT NULL COMMENT '收信人手机号',
  `sign_name` varchar(255) NULL DEFAULT NULL COMMENT '签名',
  `template_code` varchar(255) NULL DEFAULT NULL COMMENT '模板code',
  `template_params` varchar(255) NULL DEFAULT NULL COMMENT '模板参数',
  `validate_code` varchar(6) NULL DEFAULT NULL COMMENT '验证码',
  `expire_time` datetime(0) NULL DEFAULT NULL COMMENT '过期时间',
  `status` varchar(255) NULL DEFAULT NULL COMMENT '发送状态：待发送，已发送，发送成功，发送失败',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_biz_phone_code`(`app_name`, `biz`, `receive_phone`) USING BTREE COMMENT '普通索引'
) ENGINE = InnoDB AUTO_INCREMENT = 1 COMMENT = '短信发送记录';

DROP TABLE IF EXISTS `sms_template_info`;
CREATE TABLE `sms_template_info`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `code` varchar(255) NOT NULL COMMENT '模板code',
  `aliyun_sign_name` varchar(255) NULL DEFAULT NULL COMMENT '阿里云短信签名',
  `aliyun_template_code` varchar(255) NULL DEFAULT NULL COMMENT '阿里云模板code',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 COMMENT = '短信模板配置信息表';
INSERT INTO `sms_template_info` VALUES (1, 'digital-002', '冠美', 'SMS_463680822', '2023-10-12 14:25:34', '2023-10-12 14:25:53');
INSERT INTO `sms_template_info` VALUES (2, 'digital-003', '冠美', 'SMS_463635858', '2023-10-12 14:27:03', '2023-10-12 14:27:13');
INSERT INTO `sms_template_info` VALUES (3, 'digital-004', '冠美', 'SMS_463685854', '2023-10-12 14:27:17', '2023-10-12 14:28:03');
INSERT INTO `sms_template_info` VALUES (4, 'digital-005', '冠美', 'SMS_463585919', '2023-10-12 14:27:24', '2023-10-12 14:28:03');
INSERT INTO `sms_template_info` VALUES (5, 'digital-006', '冠美', 'SMS_463680834', '2023-10-12 14:27:39', '2023-10-12 14:28:03');

DROP TABLE IF EXISTS `water_config`;
CREATE TABLE `water_config`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `biz_type` varchar(255) NULL DEFAULT NULL COMMENT '业务类型',
  `biz_no` varchar(2) NOT NULL DEFAULT '' COMMENT '业务编号',
  `range_left` int(0) NOT NULL DEFAULT 0 COMMENT '当前使用号段区间left',
  `range_right` int(0) NULL DEFAULT 0 COMMENT '当前号段区间right',
  `range_index` int(0) NULL DEFAULT NULL COMMENT '当前使用下标',
  `online_time` date NOT NULL COMMENT '上线时间',
  `remark` varchar(255) NULL DEFAULT '' COMMENT '备注',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uni_idx_biz_no`(`biz_no`) USING BTREE COMMENT '业务编号唯一索引'
) ENGINE = InnoDB AUTO_INCREMENT = 7 COMMENT = '全局ID生成配置表';
INSERT INTO `water_config` VALUES (1, 'collection_record', '10', 0, 0, 0, '2023-09-19', '采集记录', '2023-09-19 16:57:42', '2023-09-19 19:25:05');
INSERT INTO `water_config` VALUES (2, 'audit_record', '11', 0, 0, 0, '2023-09-18', '审核记录', '2023-09-19 16:57:58', '2023-09-19 19:25:06');
INSERT INTO `water_config` VALUES (3, 'case_info', '12', 0, 0, 0, '2023-09-19', '竞品信息', '2023-09-19 16:58:20', '2023-09-19 19:25:07');
INSERT INTO `water_config` VALUES (4, 'case_region', '13', 0, 0, 0, '2023-09-18', '竞品热区信息', '2023-09-19 16:58:35', '2023-09-19 19:25:09');
INSERT INTO `water_config` VALUES (5, 'merchant_info', '14', 0, 0, 0, '2023-09-20', '商家信息', '2023-09-20 19:52:02', '2023-09-22 18:13:16');
INSERT INTO `water_config` VALUES (6, 'shop_info', '15', 0, 0, 0, '2023-09-22', '店铺信息', '2023-09-22 17:45:19', '2023-09-25 11:03:29');

CREATE TABLE `digital-bird`.`oss_route_config`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `biz_type` varchar(255)  NOT NULL DEFAULT '' COMMENT '业务类型(全局唯一)',
  `bucket_name` varchar(255)  NOT NULL DEFAULT '' COMMENT 'oss bucketName',
  `resource_path` varchar(255)  NOT NULL COMMENT '资源路径(全局唯一)',
  `limit_rule` varchar(255)  NULL DEFAULT '' COMMENT '限制规则',
  `remark` varchar(255)  NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_user` varchar(255)  NULL DEFAULT NULL COMMENT '创建人',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `update_user` varchar(255)  NULL DEFAULT NULL COMMENT '修改人',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uniq_idx_biz`(`biz_type` ASC) USING BTREE COMMENT '业务类型唯一索引',
  UNIQUE INDEX `uniq_idx_path`(`bucket_name` ASC, `resource_path` ASC) USING BTREE COMMENT 'path唯一索引'
) ENGINE = InnoDB  COMMENT = 'oss路由信息表' ROW_FORMAT = Dynamic;

INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (1, 'case_auto_collection', 'gm-cod', 'case/caseinfo/auto/${date}/', '', '竞品案例自动采集业务', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:51', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (2, 'case_manual_collection', 'gm-cod', 'case/caseinfo/manual/${date}/', '', '竞品案例手动采集业务', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:52', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (3, 'case_industry_config', 'gm-cod', 'case/industry/config/', '', '竞品案例行业配置', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:53', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (4, 'case_calender_config', 'gm-cod', 'case/calender/config/', '', '竞品案例日历配置', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:54', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (5, 'case_contact', 'gm-cod', 'case/contact/', '', '竞品案例联系方式', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:56', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (6, 'user_permission_menu', 'gm-cod', 'user/permission/', '', '用户中台权限菜单', '2023-10-14 16:08:02', 'py', '2023-10-14 17:15:56', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (7, 'solution_applet', 'gm-cod', 'solution/applet/', '', '解决方案小程序', '2023-10-14 16:08:02', 'py', '2023-10-14 17:19:10', NULL);
INSERT INTO `digital-bird`.`oss_route_config` (`id`, `biz_type`, `bucket_name`, `resource_path`, `limit_rule`, `remark`, `create_time`, `create_user`, `update_time`, `update_user`) VALUES (8, 'customer_user_info', 'gm-cod', 'customer/userinfo/', '', '服务平台用户信息', '2023-10-14 16:08:02', 'py', '2023-10-14 17:20:55', NULL);

