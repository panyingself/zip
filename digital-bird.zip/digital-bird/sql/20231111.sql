alter table sms_template_info add column expire_time_count int COMMENT '过期时间计数(秒)' after aliyun_template_code;
update sms_template_info set expire_time_count=300;