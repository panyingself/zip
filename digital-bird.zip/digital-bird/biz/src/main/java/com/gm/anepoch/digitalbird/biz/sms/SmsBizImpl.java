package com.gm.anepoch.digitalbird.biz.sms;

import com.aliyun.dysmsapi20170525.models.SendSmsResponse;
import com.aliyun.tea.TeaException;
import com.aliyun.teautil.models.RuntimeOptions;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsSendBo;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsValidateCheckBo;
import com.gm.anepoch.digitalbird.biz.smssendrecord.SmsSendRecordBiz;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.SmsSendRecordBo;
import com.gm.anepoch.digitalbird.biz.smstemplateinfo.SmsTemplateInfoBiz;
import com.gm.anepoch.digitalbird.biz.smstemplateinfo.bo.SmsTemplateInfoBo;
import com.gm.anepoch.digitalbird.commons.enums.SmsSendStatusEnums;
import com.gm.anepoch.digitalbird.commons.utils.LocalDateUtils;
import com.gm.anepoch.digitalbird.commons.utils.SmsUtils;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/7 - 21:36
 */
@Component
@Slf4j
public class SmsBizImpl implements SmsBiz {
    @Resource
    private SmsTemplateInfoBiz smsTemplateInfoBiz;
    @Resource
    private SmsSendRecordBiz smsSendRecordBiz;

    /**
     * 发送短信
     *
     * @param smsSendBo smsSendBo
     * @return success true orElse false
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean send(SmsSendBo smsSendBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected Boolean process() {
                //查询短信模板信息
                SmsTemplateInfoBo smsTemplateInfoBo = smsTemplateInfoBiz.fetchDetailByCode(smsSendBo.getTemplateCode());
                ConditionUtils.checkArgument(Objects.nonNull(smsTemplateInfoBo), "非法短信模板信息");
                //构建短信发送记录信息
                SmsSendRecordBo smsSendRecordBo = buildSmsSendRecord(smsSendBo, smsTemplateInfoBo);
                Boolean sendResult = sendSms(smsSendBo, smsTemplateInfoBo, smsSendRecordBo);
                //保存短息发送记录
                smsSendRecordBiz.add(smsSendRecordBo);
                return sendResult;
            }
        }.execute();
    }

    /**
     * 校验短信验证码
     *
     * @param smsValidateCheckBo smsValidateCheckBo
     * @return success true orElse false
     */
    @Override
    public Boolean checkValidateCode(SmsValidateCheckBo smsValidateCheckBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected Boolean process() {
                //查询已发送的短信验证码
                SmsSendRecordBo smsSendRecordBo = smsSendRecordBiz.fetchNewestRecord(smsValidateCheckBo.getAppName(), smsValidateCheckBo.getBiz(), smsValidateCheckBo.getTemplateCode(), smsValidateCheckBo.getReceivePhone());
                ConditionUtils.checkArgument(Objects.nonNull(smsSendRecordBo), "验证码信息不存在");
                //校验验证码是否相同
                ConditionUtils.checkArgument(Objects.equals(smsSendRecordBo.getValidateCode(), smsValidateCheckBo.getValidateCode()), "验证码错误");
                //校验验证码是否过期
                ConditionUtils.checkArgument(smsSendRecordBo.getExpireTime().after(new Date()), "验证码已过期");
                return Boolean.TRUE;
            }
        }.execute();
    }

    private SmsSendRecordBo buildSmsSendRecord(SmsSendBo smsSendBo, SmsTemplateInfoBo smsTemplateInfoBo) {
        SmsSendRecordBo smsSendRecordBo = new SmsSendRecordBo();
        Optional.ofNullable(smsSendBo).ifPresent(data -> {
            smsSendRecordBo.setAppName(data.getAppName());
            smsSendRecordBo.setBiz(data.getBiz());
            smsSendRecordBo.setReceivePhone(data.getReceivePhone());
        });
        Optional.ofNullable(smsTemplateInfoBo).ifPresent(data -> {
            smsSendRecordBo.setTemplateCode(data.getCode());
            smsSendRecordBo.setSignName(data.getAliyunSignName());
        });
        return smsSendRecordBo;
    }

    private Boolean sendSms(SmsSendBo smsSendBo, SmsTemplateInfoBo smsTemplateInfoBo, SmsSendRecordBo smsSendRecordBo) {
        try {
            Map<String, String> paramMap = Maps.newHashMap();
            String validateCode = SmsUtils.genCode();
            paramMap.put("code", validateCode);
            // 请确保代码运行环境设置了环境变量 ALIBABA_CLOUD_ACCESS_KEY_ID 和 ALIBABA_CLOUD_ACCESS_KEY_SECRET。
            // 工程代码泄露可能会导致 AccessKey 泄露，并威胁账号下所有资源的安全性。以下代码示例使用环境变量获取 AccessKey 的方式进行调用，仅供参考，建议使用更安全的 STS 方式，更多鉴权访问方式请参见：https://help.aliyun.com/document_detail/378657.html
            com.aliyun.dysmsapi20170525.Client client = SmsUtils.createClient();
            com.aliyun.dysmsapi20170525.models.SendSmsRequest sendSmsRequest = new com.aliyun.dysmsapi20170525.models.SendSmsRequest()
                    .setPhoneNumbers(smsSendBo.getReceivePhone())
                    .setTemplateCode(smsTemplateInfoBo.getAliyunTemplateCode())
                    .setTemplateParam(JsonMoreUtils.toJson(paramMap))
                    .setSignName(smsTemplateInfoBo.getAliyunSignName());

            // 复制代码运行请自行打印 API 的返回值
            log.info("短信发送invoke aliyun start, request: {}", JsonMoreUtils.toJson(sendSmsRequest));
            SendSmsResponse sendSmsResponse = client.sendSmsWithOptions(sendSmsRequest, new RuntimeOptions());
            log.info("短信发送invoke aliyun end, response: {}", JsonMoreUtils.toJson(sendSmsRequest));
            //构建发送记录相关信息
            smsSendRecordBo.setTemplateParams(JsonMoreUtils.toJson(paramMap));
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime expireTime = now.plusSeconds(smsTemplateInfoBo.getExpireTimeCount());
            smsSendRecordBo.setExpireTime(LocalDateUtils.localDateTimeToDate(expireTime));
            smsSendRecordBo.setValidateCode(validateCode);
            smsSendRecordBo.setStatus(SmsSendStatusEnums.SUCCESS.code());
            return true;
        } catch (Exception e) {
            log.info("发送短息异常: " + e.getMessage());
        }
        smsSendRecordBo.setStatus(SmsSendStatusEnums.FAILUERE.code());
        return false;
    }
}
