
package com.gm.anepoch.digitalbird.biz.smssendrecord;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.*;
import com.gm.anepoch.digitalbird.service.service.smssendrecord.SmsSendRecordService;
import com.gm.anepoch.digitalbird.biz.smssendrecord.converter.SmsSendRecordBoConverter;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class SmsSendRecordBizImpl implements SmsSendRecordBiz {
    @Resource
    private SmsSendRecordService smsSendRecordService;

    /**
     * 新增 record
     *
     * @param addSmsSendRecordBo addSmsSendRecordBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean add(SmsSendRecordBo addSmsSendRecordBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(addSmsSendRecordBo), "addSmsSendRecordBo is null");
            }

            @Override
            protected Boolean process() {
                //新增角色信息
                SmsSendRecord newSmsSendRecord = SmsSendRecordBoConverter.convertToSmsSendRecord(addSmsSendRecordBo);
                smsSendRecordService.insert(newSmsSendRecord);
                return true;
            }
        }.execute();
    }

    /**
     * 修改 record
     *
     * @param editSmsSendRecordBo editSmsSendRecordBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean editById(SmsSendRecordBo editSmsSendRecordBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(editSmsSendRecordBo), "editSmsSendRecordBo is null");
                ConditionUtils.checkArgument(Objects.nonNull(editSmsSendRecordBo.getId()), "editSmsSendRecordBo id is null");
            }

            @Override
            protected Boolean process() {
                SmsSendRecord oldSmsSendRecord = smsSendRecordService.getDetailById(editSmsSendRecordBo.getId());
                ConditionUtils.checkArgument(Objects.nonNull(oldSmsSendRecord), "oldSmsSendRecord is null");
                //修改记录
                SmsSendRecord waitToUpdate = SmsSendRecordBoConverter.convertToSmsSendRecord(editSmsSendRecordBo);
                smsSendRecordService.update(waitToUpdate);
                return true;
            }
        }.execute();
    }

    /**
     * 查询record集合
     *
     * @param querySmsSendRecordBo querySmsSendRecordBo
     * @return record list
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<SmsSendRecordBo> list(SmsSendRecordBo querySmsSendRecordBo) {
        return new BaseBizTemplate<List<SmsSendRecordBo>>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(querySmsSendRecordBo), "querySmsSendRecordBo is null");
            }

            @Override
            protected List<SmsSendRecordBo> process() {
                SmsSendRecord smsSendRecordQuery = SmsSendRecordBoConverter.convertToSmsSendRecord(querySmsSendRecordBo);
                List<SmsSendRecord> fromDbList = smsSendRecordService.list(smsSendRecordQuery);
                if (CollectionUtils.isEmpty(fromDbList)) {
                    return Lists.newArrayList();
                }
                return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList), SmsSendRecordBo.class);
            }
        }.execute();
    }

    /**
     * 查询record
     *
     * @param recordId recordId
     * @return record orElse null
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public SmsSendRecordBo fetchDetailById(Long recordId) {
        return new BaseBizTemplate<SmsSendRecordBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
            }

            @Override
            protected SmsSendRecordBo process() {
                SmsSendRecord fromDb = smsSendRecordService.getDetailById(recordId);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), SmsSendRecordBo.class);
            }
        }.execute();
    }

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appName
     * @param biz          biz
     * @param templateCode templateCode
     * @param phone        phone
     * @return record
     */
    @Override
    public SmsSendRecordBo fetchNewestRecord(String appName, String biz, String templateCode, String phone) {
        log.info("sms fetchNewestRecord biz start, appName - {} , biz - {} ,templateCode - {} , phone - {}", appName, biz, templateCode, phone);
        return new BaseBizTemplate<SmsSendRecordBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(StringUtils.isNotBlank(appName), "appName is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(biz), "biz is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(templateCode), "templateCode is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(phone), "phone is null");

            }

            @Override
            protected SmsSendRecordBo process() {
                SmsSendRecord fromDb = smsSendRecordService.getNewestRecord(appName, biz, templateCode, phone);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), SmsSendRecordBo.class);
            }
        }.execute();
    }
}

