package com.gm.anepoch.digitalbird.biz.email;

import com.gm.anepoch.digitalbird.biz.email.bo.EmailSendBo;
import com.gm.anepoch.digitalbird.biz.email.bo.EmailValidateCheckBo;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsValidateCheckBo;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 14:58
 */
public interface EmailSendBiz {
    /**
     * 发送邮件
     *
     * @param emailSendBo emailSendBo
     * @return 是否成功
     */
    Boolean send(EmailSendBo emailSendBo);
    /**
     * 校验email验证码
     *
     * @param emailValidateCheckBo smsSendBo
     * @return success true orElse false
     */
    Boolean checkValidateCode(EmailValidateCheckBo emailValidateCheckBo);
}
