
package com.gm.anepoch.digitalbird.biz.emailsendrecord;

import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.*;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.SmsSendRecordBo;

import java.util.List;


/**
 * @author py
 * @date 2019/4
 */
public interface EmailSendRecordBiz {
    /**
     * 新增 record
     *
     * @param addEmailSendRecordBo addEmailSendRecordBo
     * @return success true orElse false
     */
    boolean add(EmailSendRecordBo addEmailSendRecordBo);

    /**
     * 修改 record
     *
     * @param editEmailSendRecordBo editEmailSendRecordBo
     * @return success true orElse false
     */
    boolean editById(EmailSendRecordBo editEmailSendRecordBo);

    /**
     * 查询record集合
     *
     * @param queryEmailSendRecordBo queryEmailSendRecordBo
     * @return record list
     */
    List<EmailSendRecordBo> list(EmailSendRecordBo queryEmailSendRecordBo);

    /**
     * 查询record集合(仅为发送邮件job任务提供)
     * 默认查询状态为waited且状态为sending、retryCount小于3的数据
     *
     * @param recordSize recordSize
     * @return record list
     */
    List<EmailSendRecordBo> listForSendEmailJob(Long recordSize);

    /**
     * 查询record detail
     *
     * @param recordId recordId
     * @return record detail
     */
    EmailSendRecordBo fetchDetailById(Long recordId);
    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appName
     * @param biz          biz
     * @param templateCode templateCode
     * @param email        email
     * @return record
     */
    EmailSendRecordBo fetchNewestRecord(String appName, String biz, String templateCode, String email);

}

