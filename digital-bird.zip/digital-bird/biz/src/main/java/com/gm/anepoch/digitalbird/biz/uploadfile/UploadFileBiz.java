
package com.gm.anepoch.digitalbird.biz.uploadfile;

import com.gm.anepoch.digitalbird.biz.smstemplateinfo.bo.SmsTemplateInfoBo;
import com.gm.anepoch.digitalbird.biz.uploadfile.bo.UploadFileBo;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;


/**
 * @author xy
 * @date 2019/4
 */
public interface UploadFileBiz {
    /**
     * 获取业务类型
     * @param file 文件类
     * @param fileDirectory 文件夹地址
     * @return data list all
     */

    UploadFileBo uploadFile(MultipartFile file, String fileDirectory);
}

