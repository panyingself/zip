package com.gm.anepoch.digitalbird.biz.sms;

import com.gm.anepoch.digitalbird.biz.sms.bo.SmsSendBo;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsValidateCheckBo;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/7 - 21:36
 */
public interface SmsBiz {
    /**
     * 发送短信
     *
     * @param smsSendBo smsSendBo
     * @return success true orElse false
     */
    Boolean send(SmsSendBo smsSendBo);

    /**
     * 校验短信验证码
     *
     * @param smsValidateCheckBo smsSendBo
     * @return success true orElse false
     */
    Boolean checkValidateCode(SmsValidateCheckBo smsValidateCheckBo);
}
