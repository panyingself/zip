
package com.gm.anepoch.digitalbird.biz.emailtemplateinfo;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.bo.*;
import com.gm.anepoch.digitalbird.service.service.emailtemplateinfo.EmailTemplateInfoService;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.converter.EmailTemplateInfoBoConverter;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class EmailTemplateInfoBizImpl implements EmailTemplateInfoBiz {
    @Resource
    private EmailTemplateInfoService emailTemplateInfoService;

    /**
     * 新增 record
     *
     * @param addEmailTemplateInfoBo addEmailTemplateInfoBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean add(EmailTemplateInfoBo addEmailTemplateInfoBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(addEmailTemplateInfoBo), "addEmailTemplateInfoBo is null");
            }

            @Override
            protected Boolean process() {
                //新增角色信息
                EmailTemplateInfo newEmailTemplateInfo = EmailTemplateInfoBoConverter.convertToEmailTemplateInfo(addEmailTemplateInfoBo);
                emailTemplateInfoService.insert(newEmailTemplateInfo);
                return true;
            }
        }.execute();
    }

    /**
     * 修改 record
     *
     * @param editEmailTemplateInfoBo editEmailTemplateInfoBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean editById(EmailTemplateInfoBo editEmailTemplateInfoBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(editEmailTemplateInfoBo), "editEmailTemplateInfoBo is null");
                ConditionUtils.checkArgument(Objects.nonNull(editEmailTemplateInfoBo.getId()), "editEmailTemplateInfoBo id is null");
            }

            @Override
            protected Boolean process() {
                EmailTemplateInfo oldEmailTemplateInfo = emailTemplateInfoService.getDetailById(editEmailTemplateInfoBo.getId());
                ConditionUtils.checkArgument(Objects.nonNull(oldEmailTemplateInfo), "oldEmailTemplateInfo is null");
                //修改记录
                EmailTemplateInfo waitToUpdate = EmailTemplateInfoBoConverter.convertToEmailTemplateInfo(editEmailTemplateInfoBo);
                emailTemplateInfoService.update(waitToUpdate);
                return true;
            }
        }.execute();
    }

    /**
     * 查询record集合
     *
     * @param queryEmailTemplateInfoBo queryEmailTemplateInfoBo
     * @return record list
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<EmailTemplateInfoBo> list(EmailTemplateInfoBo queryEmailTemplateInfoBo) {
        return new BaseBizTemplate<List<EmailTemplateInfoBo>>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(queryEmailTemplateInfoBo), "queryEmailTemplateInfoBo is null");
            }

            @Override
            protected List<EmailTemplateInfoBo> process() {
                EmailTemplateInfo emailTemplateInfoQuery = EmailTemplateInfoBoConverter.convertToEmailTemplateInfo(queryEmailTemplateInfoBo);
                List<EmailTemplateInfo> fromDbList = emailTemplateInfoService.list(emailTemplateInfoQuery);
                if (CollectionUtils.isEmpty(fromDbList)) {
                    return Lists.newArrayList();
                }
                return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList), EmailTemplateInfoBo.class);
            }
        }.execute();
    }

    /**
     * 查询record
     *
     * @param recordId recordId
     * @return record orElse null
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public EmailTemplateInfoBo fetchDetailById(Long recordId) {
        return new BaseBizTemplate<EmailTemplateInfoBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
            }

            @Override
            protected EmailTemplateInfoBo process() {
                EmailTemplateInfo fromDb = emailTemplateInfoService.getDetailById(recordId);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), EmailTemplateInfoBo.class);
            }
        }.execute();
    }

    /**
     * 查询record
     *
     * @param code code
     * @return record orElse null
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public EmailTemplateInfoBo fetchDetailByCode(String code) {
        return new BaseBizTemplate<EmailTemplateInfoBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(StringUtils.isNotBlank(code), "code is blank");
            }

            @Override
            protected EmailTemplateInfoBo process() {
                EmailTemplateInfo fromDb = emailTemplateInfoService.getDetailByCode(code);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), EmailTemplateInfoBo.class);
            }
        }.execute();
    }

}

