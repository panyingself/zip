package com.gm.anepoch.digitalbird.biz.job;

import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.EmailSendRecordBiz;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.digitalbird.commons.enums.EmailSendStatusEnums;
import com.gm.anepoch.digitalbird.commons.utils.EmailUtils;
import com.gm.anepoch.digitalbird.commons.utils.LocalDateUtils;
import com.gm.anepoch.digitalbird.commons.utils.SmsUtils;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.mail.*;
import javax.mail.internet.MimeMessage;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Properties;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/7 - 11:28
 */
@Component
@Slf4j
public class SendEmailJob {
    /**
     * 最大重试数
     */
    private static final int MAX_RETRY_COUNT = 3;
    @Resource
    private EmailSendRecordBiz emailSendRecordBiz;

    @XxlJob("sendEmail")
    public void sendEmail() throws Exception {
        log.info("send email job start.....");
        List<EmailSendRecordBo> listFromDb = emailSendRecordBiz.listForSendEmailJob(null);
        if (CollectionUtils.isEmpty(listFromDb)) {
            log.info("send email job end..... no data");
            return;
        }
        //发送邮件
        listFromDb.forEach(this::sendMessage);
    }

    private void sendMessage(EmailSendRecordBo emailSendRecordBo) {
        log.info("begin send email ,current email data : {}", JsonMoreUtils.toJson(emailSendRecordBo));
        this.buildEmailSendRecordBo(emailSendRecordBo);
        Properties props = EmailUtils.buildEmailProps();
        // 构建授权信息，用于进行SMTP进行身份验证
        Authenticator authenticator = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                // 用户名、密码
                String userName = props.getProperty("mail.user");
                String password = props.getProperty("mail.password");
                return new PasswordAuthentication(userName, password);
            }
        };
        //使用环境属性和授权信息，创建邮件会话
        Session mailSession = Session.getInstance(props, authenticator);
        //创建邮件消息
        MimeMessage message = new MimeMessage(mailSession) {
            @Override
            protected void updateMessageID() throws MessagingException {
                //设置自定义Message-ID值
                setHeader("Message-ID", emailSendRecordBo.getMessageId());//创建Message-ID
            }
        };
        try {
            //构建发件人信息
            message.setFrom(EmailUtils.buildEmailFrom());
            //构建收件人信息
            message.setRecipient(MimeMessage.RecipientType.TO, EmailUtils.buildEmailTo(emailSendRecordBo.getAddressTo()));
            //构建抄送人信息
            //构建密送人信息
            //构建邮件内容
            message.setSubject(emailSendRecordBo.getSubject());
            //html超文本；// "text/plain;charset=UTF-8" //纯文本。
            //发送内容替换
            String newContent = emailSendRecordBo.getContent().replace("${code}", emailSendRecordBo.getValidateCode());
            message.setContent(newContent, "text/html;charset=UTF-8");
            //设置时间
            message.setSentDate(new Date());
            Transport.send(message);
            emailSendRecordBo.setStatus(EmailSendStatusEnums.SUCCESS.code());
        } catch (MessagingException e) {
            log.error("发送邮件失败，message : {} ,失败信息 e : ", JsonMoreUtils.toJson(emailSendRecordBo), e);
            //重试次数加1
            emailSendRecordBo.setRetryCount(emailSendRecordBo.getRetryCount() + 1);
            if (emailSendRecordBo.getRetryCount() >= MAX_RETRY_COUNT) {
                emailSendRecordBo.setStatus(EmailSendStatusEnums.FAILUERE.code());
            } else {
                emailSendRecordBo.setStatus(EmailSendStatusEnums.SENDING.code());
            }
        }
        emailSendRecordBiz.editById(emailSendRecordBo);
    }

    private EmailSendRecordBo buildEmailSendRecordBo(EmailSendRecordBo emailSendRecordBo) {
        //验证码
        emailSendRecordBo.setValidateCode(SmsUtils.genCode());
        //过期时间
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expireTime = now.plusSeconds(emailSendRecordBo.getExpireTimeCount());
        emailSendRecordBo.setExpireTime(LocalDateUtils.localDateTimeToDate(expireTime));
        return emailSendRecordBo;
    }
}
