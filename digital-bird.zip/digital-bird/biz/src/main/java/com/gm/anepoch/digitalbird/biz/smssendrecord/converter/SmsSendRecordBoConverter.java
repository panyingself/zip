package com.gm.anepoch.digitalbird.biz.smssendrecord.converter;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.*;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import java.util.Objects;
import lombok.Data;
/**
 * @author py
 * @date 2019/4
 */
@Data
public class SmsSendRecordBoConverter {
	public static SmsSendRecord convertToSmsSendRecord(SmsSendRecordBo targetBo) {
		if (Objects.isNull(targetBo)) {
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(targetBo),SmsSendRecord.class);
		//或者构建你的实际逻辑
//		return SmsSendRecord.builder()
////				//fit your code
////				.build();
	}
}


