package com.gm.anepoch.digitalbird.biz.oss.bo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author xiongyu
 * @date 2023/1
 */
@ApiModel(description = "UploadPolicyResponse")
@Data
public class UploadPolicyBo {

    @ApiModelProperty(value = "ossKey")
    private String OSSAccessKeyId;

    @ApiModelProperty(value = "签名返回")
    private String policy;

    @ApiModelProperty(value = "签名返回")
    private String signature;


    @ApiModelProperty(value = "地域节点")
    private String endpoint;


    @ApiModelProperty(value = "上传验证存储id")
    private Long fileId;

    @ApiModelProperty(value = "文件类型")
    private String fileType;


    @ApiModelProperty(value = "文件名称")
    private String fileName;


}
