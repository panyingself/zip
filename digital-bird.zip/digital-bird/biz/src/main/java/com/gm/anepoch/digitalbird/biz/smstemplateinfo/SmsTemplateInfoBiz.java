
package com.gm.anepoch.digitalbird.biz.smstemplateinfo;

import com.gm.anepoch.digitalbird.biz.smstemplateinfo.bo.*;

import java.util.List;


/**
 * @author py
 * @date 2019/4
 */
public interface SmsTemplateInfoBiz {
    /**
     * 新增 record
     *
     * @param addSmsTemplateInfoBo addSmsTemplateInfoBo
     * @return success true orElse false
     */
    boolean add(SmsTemplateInfoBo addSmsTemplateInfoBo);

    /**
     * 修改 record
     *
     * @param editSmsTemplateInfoBo editSmsTemplateInfoBo
     * @return success true orElse false
     */
    boolean editById(SmsTemplateInfoBo editSmsTemplateInfoBo);

    /**
     * 查询record集合
     *
     * @param querySmsTemplateInfoBo querySmsTemplateInfoBo
     * @return record list
     */
    List<SmsTemplateInfoBo> list(SmsTemplateInfoBo querySmsTemplateInfoBo);

    /**
     * 查询record detail
     *
     * @param recordId recordId
     * @return record detail
     */
    SmsTemplateInfoBo fetchDetailById(Long recordId);

    /**
     * 查询record detail
     *
     * @param templateCode templateCode
     * @return record detail
     */
    SmsTemplateInfoBo fetchDetailByCode(String templateCode);
}

