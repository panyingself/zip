
package com.gm.anepoch.digitalbird.biz.emailtemplateinfo;

import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.bo.*;
import java.util.List;


/**
 * @author py
 * @date 2019/4
 */
public interface EmailTemplateInfoBiz {
	/**
	 * 新增 record
	 *
	 * @param addEmailTemplateInfoBo addEmailTemplateInfoBo
	 * @return success true orElse false
	 */
	boolean add(EmailTemplateInfoBo addEmailTemplateInfoBo);

	/**
	 * 修改 record
	 *
	 * @param editEmailTemplateInfoBo editEmailTemplateInfoBo
	 * @return success true orElse false
	 */
	boolean editById(EmailTemplateInfoBo editEmailTemplateInfoBo);
	/**
	 * 查询record集合
	 * @param queryEmailTemplateInfoBo queryEmailTemplateInfoBo
	 * @return record list
	 */
	List<EmailTemplateInfoBo> list(EmailTemplateInfoBo queryEmailTemplateInfoBo);

	/**
	 * 查询record detail
	 * @param recordId recordId
	 * @return record detail
	 */
	EmailTemplateInfoBo fetchDetailById(Long recordId);

	/**
	 * 查询record detail
	 * @param code code
	 * @return record detail
	 */
	EmailTemplateInfoBo fetchDetailByCode(String code);
}

