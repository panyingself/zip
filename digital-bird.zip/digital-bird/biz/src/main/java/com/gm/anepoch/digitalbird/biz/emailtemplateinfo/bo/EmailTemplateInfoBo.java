package com.gm.anepoch.digitalbird.biz.emailtemplateinfo.bo;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * @author py
 * @date 2019/4
 */
@Data
public class EmailTemplateInfoBo implements Serializable {
	/** 主键id */
	private Long id;
	/** 模板code */
	private String code;
	/** 邮件主题 */
	private String subject;
	/** 邮件内容 */
	private String content;
	/**
	 * 过期时间计数(秒 - 模板配置)
	 */
	private Long expireTimeCount;
	/** 创建时间 */
	private java.util.Date createTime;
	/** 创建人 */
	private String createUser;
	/** 修改时间 */
	private java.util.Date updateTime;
	/** 修改人 */
	private java.util.Date updateUser;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}

