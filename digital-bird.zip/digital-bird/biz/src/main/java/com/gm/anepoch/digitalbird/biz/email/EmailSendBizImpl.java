package com.gm.anepoch.digitalbird.biz.email;

import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.email.bo.EmailSendBo;
import com.gm.anepoch.digitalbird.biz.email.bo.EmailValidateCheckBo;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.EmailSendRecordBiz;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.EmailTemplateInfoBiz;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.bo.EmailTemplateInfoBo;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.SmsSendRecordBo;
import com.gm.anepoch.digitalbird.commons.constants.EmailConstants;
import com.gm.anepoch.digitalbird.commons.enums.EmailSendStatusEnums;
import com.gm.anepoch.digitalbird.commons.utils.EmailUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.mail.*;
import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 14:58
 */
@Component
public class EmailSendBizImpl implements EmailSendBiz {
    @Resource
    private EmailTemplateInfoBiz emailTemplateInfoBiz;
    @Resource
    private EmailSendRecordBiz emailSendRecordBiz;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean send(EmailSendBo emailSendBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected Boolean process() {
                //查询上下文信息
                //查询邮件模板
                EmailTemplateInfoBo emailTemplateInfoBo = emailTemplateInfoBiz.fetchDetailByCode(emailSendBo.getEmailTemplateCode());
                //记录邮件发送记录
                emailSendRecordBiz.add(buildEmailSendRecordBo(emailSendBo, emailTemplateInfoBo));
                //发送邮件
                return true;
            }
        }.execute();
    }

    /**
     * 校验email验证码
     *
     * @param emailValidateCheckBo smsSendBo
     * @return success true orElse false
     */
    @Override
    public Boolean checkValidateCode(EmailValidateCheckBo emailValidateCheckBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected Boolean process() {
                //查询已发送的短信验证码
                EmailSendRecordBo emailSendRecordBo = emailSendRecordBiz.fetchNewestRecord(emailValidateCheckBo.getAppName(), emailValidateCheckBo.getBiz(), emailValidateCheckBo.getEmailTemplateCode(), emailValidateCheckBo.getUserTo());
                ConditionUtils.checkArgument(Objects.nonNull(emailSendRecordBo), "验证码信息不存在");
                //校验验证码是否相同
                ConditionUtils.checkArgument(Objects.equals(emailSendRecordBo.getValidateCode(), emailValidateCheckBo.getValidateCode()), "验证码错误");
                //校验验证码是否过期
                ConditionUtils.checkArgument(emailSendRecordBo.getExpireTime().after(new Date()), "验证码已过期");
                return Boolean.TRUE;
            }
        }.execute();
    }

    private EmailSendRecordBo buildEmailSendRecordBo(EmailSendBo emailSendBo, EmailTemplateInfoBo emailTemplateInfoBo) {
        EmailSendRecordBo emailSendRecordBo = new EmailSendRecordBo();
        Optional.ofNullable(emailSendBo).ifPresent(data -> {
            emailSendRecordBo.setAppName(data.getAppName());
            emailSendRecordBo.setBiz(data.getBiz());
            emailSendRecordBo.setAddressTo(data.getUserTo());
            emailSendRecordBo.setAddressCc(JsonMoreUtils.toJson(data.getUserCcList()));
            emailSendRecordBo.setAddressBcc(JsonMoreUtils.toJson(data.getUserBccList()));
            emailSendRecordBo.setTemplateCode(data.getEmailTemplateCode());

        });
        Optional.ofNullable(emailTemplateInfoBo).ifPresent(data -> {
            emailSendRecordBo.setSubject(data.getSubject());
            emailSendRecordBo.setContent(data.getContent());
            emailSendRecordBo.setExpireTimeCount(data.getExpireTimeCount());
        });
        emailSendRecordBo.setAddressFrom(EmailConstants.EMAIL_USER_FROM);
        emailSendRecordBo.setStatus(EmailSendStatusEnums.WAITED.code());
        emailSendRecordBo.setMessageId(EmailUtils.genMessageId(EmailConstants.EMAIL_USER_FROM));
        return emailSendRecordBo;
    }
}
