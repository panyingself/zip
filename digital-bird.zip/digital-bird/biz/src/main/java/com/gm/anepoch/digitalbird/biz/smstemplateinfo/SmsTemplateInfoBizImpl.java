
package com.gm.anepoch.digitalbird.biz.smstemplateinfo;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.smstemplateinfo.bo.*;
import com.gm.anepoch.digitalbird.service.service.smstemplateinfo.SmsTemplateInfoService;
import com.gm.anepoch.digitalbird.biz.smstemplateinfo.converter.SmsTemplateInfoBoConverter;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class SmsTemplateInfoBizImpl implements SmsTemplateInfoBiz {
    @Resource
    private SmsTemplateInfoService smsTemplateInfoService;

    /**
     * 新增 record
     *
     * @param addSmsTemplateInfoBo addSmsTemplateInfoBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean add(SmsTemplateInfoBo addSmsTemplateInfoBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(addSmsTemplateInfoBo), "addSmsTemplateInfoBo is null");
            }

            @Override
            protected Boolean process() {
                //新增角色信息
                SmsTemplateInfo newSmsTemplateInfo = SmsTemplateInfoBoConverter.convertToSmsTemplateInfo(addSmsTemplateInfoBo);
                smsTemplateInfoService.insert(newSmsTemplateInfo);
                return true;
            }
        }.execute();
    }

    /**
     * 修改 record
     *
     * @param editSmsTemplateInfoBo editSmsTemplateInfoBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean editById(SmsTemplateInfoBo editSmsTemplateInfoBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(editSmsTemplateInfoBo), "editSmsTemplateInfoBo is null");
                ConditionUtils.checkArgument(Objects.nonNull(editSmsTemplateInfoBo.getId()), "editSmsTemplateInfoBo id is null");
            }

            @Override
            protected Boolean process() {
                SmsTemplateInfo oldSmsTemplateInfo = smsTemplateInfoService.getDetailById(editSmsTemplateInfoBo.getId());
                ConditionUtils.checkArgument(Objects.nonNull(oldSmsTemplateInfo), "oldSmsTemplateInfo is null");
                //修改记录
                SmsTemplateInfo waitToUpdate = SmsTemplateInfoBoConverter.convertToSmsTemplateInfo(editSmsTemplateInfoBo);
                smsTemplateInfoService.update(waitToUpdate);
                return true;
            }
        }.execute();
    }

    /**
     * 查询record集合
     *
     * @param querySmsTemplateInfoBo querySmsTemplateInfoBo
     * @return record list
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<SmsTemplateInfoBo> list(SmsTemplateInfoBo querySmsTemplateInfoBo) {
        return new BaseBizTemplate<List<SmsTemplateInfoBo>>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(querySmsTemplateInfoBo), "querySmsTemplateInfoBo is null");
            }

            @Override
            protected List<SmsTemplateInfoBo> process() {
                SmsTemplateInfo smsTemplateInfoQuery = SmsTemplateInfoBoConverter.convertToSmsTemplateInfo(querySmsTemplateInfoBo);
                List<SmsTemplateInfo> fromDbList = smsTemplateInfoService.list(smsTemplateInfoQuery);
                if (CollectionUtils.isEmpty(fromDbList)) {
                    return Lists.newArrayList();
                }
                return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList), SmsTemplateInfoBo.class);
            }
        }.execute();
    }

    /**
     * 查询record
     *
     * @param recordId recordId
     * @return record orElse null
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public SmsTemplateInfoBo fetchDetailById(Long recordId) {
        return new BaseBizTemplate<SmsTemplateInfoBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
            }

            @Override
            protected SmsTemplateInfoBo process() {
                SmsTemplateInfo fromDb = smsTemplateInfoService.getDetailById(recordId);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), SmsTemplateInfoBo.class);
            }
        }.execute();
    }

	/**
	 * 查询record detail
	 *
	 * @param templateCode templateCode
	 * @return record detail
	 */
	@Override
	public SmsTemplateInfoBo fetchDetailByCode(String templateCode) {
		return new BaseBizTemplate<SmsTemplateInfoBo>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(templateCode), "templateCode is null");
			}

			@Override
			protected SmsTemplateInfoBo process() {
				SmsTemplateInfo fromDb = smsTemplateInfoService.getDetailByCode(templateCode);
				if (Objects.isNull(fromDb)) {
					return null;
				}
				return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), SmsTemplateInfoBo.class);
			}
		}.execute();
	}
}

