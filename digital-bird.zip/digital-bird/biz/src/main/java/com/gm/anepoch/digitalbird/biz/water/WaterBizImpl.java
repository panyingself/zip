package com.gm.anepoch.digitalbird.biz.water;

import com.gm.anepoch.base.commons.lang.Safes;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.biz.water.helper.WaterHelper;
import com.gm.anepoch.digitalbird.biz.waterconfig.WaterIdConfigLoader;
import com.gm.anepoch.digitalbird.biz.waterconfig.bo.WaterConfigBo;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/19 - 17:03
 */
@Component
@Slf4j
public class WaterBizImpl implements WaterBiz {
    @Resource
    private WaterHelper waterHelper;

    /**
     * 获取单个waterId
     *
     * @param bizType waterConfig中维护的biz_type
     * @return waterId
     */
    @Override
    public String getWaterId(String bizType) {
        log.warn("getWaterId biz start, bizType : {}", bizType);
        return new BaseBizTemplate<String>() {
            @Override
            protected String process() {
                WaterConfigBo waterConfig = WaterIdConfigLoader.waterConfigMap.get(bizType);
                ConditionUtils.checkArgument(Objects.nonNull(waterConfig), "业务类型不存在");
                String dataOnlineStr = Strings.padStart(waterHelper.getOnlineDays(waterConfig.getOnlineTime()) + "", 4, '0');
                return waterConfig.getBizNo()
                        + dataOnlineStr
                        + Strings.padStart(waterHelper.getAndInc(waterHelper.getWaterKey(bizType)), 5, '0');
            }
        }.execute();
    }

    /**
     * 获取批量waterId
     *
     * @param bizType waterConfig中维护的biz_type
     * @param number  需要获取的数量,目前限制单次最多获取20个
     * @return waterId list
     */
    @Override
    public List<String> getWaterIdList(String bizType, Long number) {
        log.warn("getWaterIdList biz start, bizType : {} , number : {}", bizType, number);
        return new BaseBizTemplate<List<String>>() {
            @Override
            protected void checkParam() {
                //最大获取50个号码
                ConditionUtils.checkArgument(number <= 50, "number is over than 50");
            }

            @Override
            protected List<String> process() {
                WaterConfigBo waterConfig = WaterIdConfigLoader.waterConfigMap.get(bizType);
                ConditionUtils.checkArgument(Objects.nonNull(waterConfig), "业务类型不存在");
                List<String> idList = waterHelper.getAndSet(waterHelper.getWaterKey(bizType), number);
                //result build
                String dataOnlineStr = Strings.padStart(waterHelper.getOnlineDays(waterConfig.getOnlineTime()) + "", 4, '0');
                //for result
                List<String> resultList = Lists.newArrayList();
                Safes.of(idList).forEach(data -> {
                    resultList.add(waterConfig.getBizNo()
                            + dataOnlineStr
                            + Strings.padStart(data, 5, '0'));
                });
                return resultList;
            }
        }.execute();
    }
}
