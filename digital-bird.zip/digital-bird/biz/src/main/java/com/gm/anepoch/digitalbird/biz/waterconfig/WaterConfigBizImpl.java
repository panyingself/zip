
package com.gm.anepoch.digitalbird.biz.waterconfig;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.waterconfig.bo.*;
import com.gm.anepoch.digitalbird.service.service.waterconfig.WaterConfigService;
import com.gm.anepoch.digitalbird.biz.waterconfig.converter.WaterConfigBoConverter;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class WaterConfigBizImpl implements WaterConfigBiz {
	@Resource
	private WaterConfigService waterConfigService;

	/**
	 * 新增 record
	 *
	 * @param addWaterConfigBo addWaterConfigBo
	 * @return success true orElse false
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean add(WaterConfigBo addWaterConfigBo) {
		return new BaseBizTemplate<Boolean>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(addWaterConfigBo), "addWaterConfigBo is null");
		}
			@Override
			protected Boolean process() {
				//新增角色信息
				WaterConfig newWaterConfig = WaterConfigBoConverter.convertToWaterConfig(addWaterConfigBo);
				waterConfigService.insert(newWaterConfig);
				return true;
			}
		}.execute();
		}

	/**
	 * 修改 record
	 *
	 * @param editWaterConfigBo editWaterConfigBo
	 * @return success true orElse false
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean editById(WaterConfigBo editWaterConfigBo) {
		return new BaseBizTemplate<Boolean>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(editWaterConfigBo), "editWaterConfigBo is null");
				ConditionUtils.checkArgument(Objects.nonNull(editWaterConfigBo.getId()), "editWaterConfigBo id is null");
			}
			@Override
			protected Boolean process() {
				WaterConfig oldWaterConfig = waterConfigService.getDetailById(editWaterConfigBo.getId());
				ConditionUtils.checkArgument(Objects.nonNull(oldWaterConfig), "oldWaterConfig is null");
				//修改记录
				WaterConfig waitToUpdate = WaterConfigBoConverter.convertToWaterConfig(editWaterConfigBo);
				waterConfigService.update(waitToUpdate);
				return true;
			}
		}.execute();
	}

	/**
	 * 查询record集合
	 *
	 * @param queryWaterConfigBo queryWaterConfigBo
	 * @return record list
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<WaterConfigBo> list(WaterConfigBo queryWaterConfigBo) {
		return new BaseBizTemplate<List<WaterConfigBo>>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(queryWaterConfigBo), "queryWaterConfigBo is null");
			}

			@Override
			protected List<WaterConfigBo> process() {
				WaterConfig waterConfigQuery = WaterConfigBoConverter.convertToWaterConfig(queryWaterConfigBo);
				List<WaterConfig> fromDbList = waterConfigService.list(waterConfigQuery);
				if(CollectionUtils.isEmpty(fromDbList)){
					return Lists.newArrayList();
				}
				return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList),WaterConfigBo.class);
			}}.execute();
	}

	/**
	 * 查询record
	 *
	 * @param recordId recordId
	 * @return record orElse null
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public WaterConfigBo fetchDetailById(Long recordId){
		return new BaseBizTemplate<WaterConfigBo>() {
			@Override
			protected void checkParam() {
				ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
			}

			@Override
			protected WaterConfigBo process() {
				WaterConfig fromDb = waterConfigService.getDetailById(recordId);
				if(Objects.isNull(fromDb)){
					return null;
				}
				return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb),WaterConfigBo.class);
			}}.execute();
		}
}

