package com.gm.anepoch.digitalbird.biz.oss;

import com.gm.anepoch.digitalbird.api.co.request.OssDeleteUrlFeignRequest;
import com.gm.anepoch.digitalbird.biz.uploadfile.bo.UploadFileBo;

import java.io.InputStream;
import java.util.List;

/**
 *
 * @author xiongyu
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
public interface AliOssBiz {


    /**
     * 文件上传
     *
     * @param bizType     业务类型@See ossRouteConfig
     * @param fileName    文件名
     * @param inputStream inputStream
     * @param fileSize        fileSize
     * @return UploadFileBo
     */
    UploadFileBo upload(String bizType, String fileName, InputStream inputStream, long fileSize);




    /**
     * 删除OSS文件 根据文件路径
     *
     * @param request     业务类型@See ossRouteConfig
     * @return UploadFileBo
     */
    Boolean deleteOssUrl(OssDeleteUrlFeignRequest request);



}
