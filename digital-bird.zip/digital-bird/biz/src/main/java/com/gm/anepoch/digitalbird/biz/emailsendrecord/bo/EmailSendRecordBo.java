package com.gm.anepoch.digitalbird.biz.emailsendrecord.bo;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * @author py
 * @date 2019/4
 */
@Data
public class EmailSendRecordBo implements Serializable {
	/** 主键id */
	private Long id;
	/** 应用名 */
	private String appName;
	/** 业务 */
	private String biz;
	/** 模板code */
	private String templateCode;
	/**
	 * 验证code
	 */
	private String validateCode;
	/** 消息id */
	private String messageId;
	/** 发件人 */
	private String addressFrom;
	/** 收件人 */
	private String addressTo;
	/** 抄送人 */
	private String addressCc;
	/** 密送人 */
	private String addressBcc;
	/** 主题 */
	private String subject;
	/** 内容 */
	private String content;
	/** 附件信息: oss存储地址 */
	private String attachments;
	/** 状态: 待发送 - waited，发送成功 - success，发送失败 - failure */
	private String status;
	/** 重试次数 */
	private Integer retryCount;
	/**
	 * 过期时间计数(秒 - 模板快照)
	 */
	private Long expireTimeCount;
	/**
	 * 过期时间
	 */
	private Date expireTime;
	/** 创建时间 */
	private java.util.Date createTime;
	/** 修改时间 */
	private java.util.Date updateTime;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}

