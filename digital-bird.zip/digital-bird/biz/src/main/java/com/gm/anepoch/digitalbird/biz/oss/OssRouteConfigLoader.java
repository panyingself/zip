package com.gm.anepoch.digitalbird.biz.oss;

import com.gm.anepoch.digitalbird.commons.model.OssRouteConfig;
import com.gm.anepoch.digitalbird.service.service.ossroutconfig.OssRouteConfigService;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 16:33
 */
@Component
@Slf4j
public class OssRouteConfigLoader {
    @Resource
    private OssRouteConfigService ossRouteConfigService;
    public static Map<String, OssRouteConfig> waterConfigMap = Maps.newConcurrentMap();

    @PostConstruct
    public void reloadOssRouteConfig() {
        doReload();
    }

    public void doReload() {
        log.warn("reloadOssRouteConfig biz start.......");
        List<OssRouteConfig> listFromDb = ossRouteConfigService.getAllList();
        if (CollectionUtils.isEmpty(listFromDb)) {
            log.warn("reloadOssRouteConfig fast end, listFromDb is empty!");
            return;
        }
        //如果有配置,reload data
        listFromDb.forEach(data -> {
            log.info("loading ossRouteConfig , currentData : {}", data);
            waterConfigMap.put(data.getBizType(), data);
        });
    }
}
