package com.gm.anepoch.digitalbird.biz.water;

import java.util.List;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/19 - 17:03
 */
public interface WaterBiz {
    /**
     * 获取单个waterId
     *
     * @param bizType waterConfig中维护的biz_type
     * @return waterId
     */
    String getWaterId(String bizType);

    /**
     * 获取批量waterId
     *
     * @param bizType waterConfig中维护的biz_type
     * @param number  需要获取的数量,目前限制单次最多获取20个
     * @return waterId list
     */
    List<String> getWaterIdList(String bizType, Long number);
}
