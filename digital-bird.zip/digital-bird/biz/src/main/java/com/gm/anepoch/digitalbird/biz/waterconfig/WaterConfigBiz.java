
package com.gm.anepoch.digitalbird.biz.waterconfig;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.waterconfig.bo.*;
import java.util.List;


/**
 * @author py
 * @date 2019/4
 */
public interface WaterConfigBiz {
	/**
	 * 新增 record
	 *
	 * @param addWaterConfigBo addWaterConfigBo
	 * @return success true orElse false
	 */
	boolean add(WaterConfigBo addWaterConfigBo);

	/**
	 * 修改 record
	 *
	 * @param editWaterConfigBo editWaterConfigBo
	 * @return success true orElse false
	 */
	boolean editById(WaterConfigBo editWaterConfigBo);
	/**
	 * 查询record集合
	 * @param queryWaterConfigBo queryWaterConfigBo
	 * @return record list
	 */
	List<WaterConfigBo> list(WaterConfigBo queryWaterConfigBo);

	/**
	 * 查询record detail
	 * @param recordId recordId
	 * @return record detail
	 */
	WaterConfigBo fetchDetailById(Long recordId);
}

