
package com.gm.anepoch.digitalbird.biz.uploadfile;

import com.gm.anepoch.base.commons.exception.BizException;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.api.utils.resourceurl.ResourceUrlSetUpUtils;
import com.gm.anepoch.digitalbird.biz.uploadfile.bo.UploadFileBo;
import com.gm.anepoch.digitalbird.commons.enums.UploadSuffixTypeEnums;
import com.gm.anepoch.digitalbird.commons.properties.FtpConfigProperties;
import com.gm.anepoch.digitalbird.commons.properties.FtpServerProperties;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import sun.net.ftp.FtpProtocolException;

import javax.annotation.Resource;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class UploadFileBizImpl implements UploadFileBiz {

    @Resource
    private FtpConfigProperties ftpConfigProperties;

    @Resource
    private FtpServerProperties ftpServerProperties;

    @Resource ResourceUrlSetUpUtils resourceUrlSetUpUtils;

    @Override
    public UploadFileBo uploadFile(MultipartFile file, String filePath) {

        return new BaseBizTemplate<UploadFileBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(file), "file is null");
            }

            @SneakyThrows
            @Override
            protected UploadFileBo process() {
                Date now = new Date();
                //校验类型大小
                String name = file.getOriginalFilename().replace("?","");
                //验证类型
                checkContentType(name.substring(name.lastIndexOf(".")), file.getSize());
                 //文件在Ftp中存储的路径，此处使用日期 + 当前的毫秒数 + 文件名称 来作为文件名，防止文件重名
                String fileName = new SimpleDateFormat("yyyy-MM-dd").format(now)+
                        "-"+ System.currentTimeMillis() +"-"+name;
                FTPClient ftpClient = new FTPClient();
                connectFtp(ftpClient);
                FileInputStream inputStream = null;
                BufferedInputStream inStream = null;
                try {
                    boolean tmp2 = ftpClient.changeWorkingDirectory(filePath);// 改变工作路径
                    log.info("FTP文件上传判断文件夹是否存在" + tmp2);
                    if (!tmp2) {
                        //创建文件夹
                        createDir(filePath,ftpClient);
                        boolean b = ftpClient.changeWorkingDirectory(filePath);
                        log.info("新建文件夹后，切换目录是否成功：{}",b);
                    }
                    inStream = new BufferedInputStream(file.getInputStream());
                    Boolean success = ftpClient.storeFile(fileName, inStream);
                    if (!success) {
                      throw new BizException("文件上传失败");
                    }
                } finally {
                    try {
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        if (ftpClient.isConnected()) {
                            // 登出并断开连接
                            ftpClient.logout();
                            ftpClient.disconnect();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //原始url
                String originalUrl = "/"+ filePath + "/" + fileName;
                //可访问的url
                String accessUrl = resourceUrlSetUpUtils.encryptResourceUrl(originalUrl);

                UploadFileBo uploadFileBo = new UploadFileBo();
                uploadFileBo.setOriginalUrl(originalUrl);
                uploadFileBo.setAccessUrl(accessUrl);
                return uploadFileBo;
            }
        }.execute();
    }

    /**文件类型转换
     *
     * @param multipartFile
     * @return
     * @throws IOException
     */
    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File file = File.createTempFile("temp", null);
        try (InputStream inputStream = multipartFile.getInputStream()) {
            Files.copy(inputStream, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }
        return file;
    }
    /**
     * 判断类型
     * @param filenameExtension 文件名称后缀
     * @return
     */
    private Boolean checkContentType(String filenameExtension,long size) {

        //图片
        if (filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.JPEG.code()) ||
                filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.JPG.code()) ||
                filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.PNG.code())){
            if(size>ftpConfigProperties.getImgSize()){
                throw new BizException("上传图片大于5M");
            }
            return true;
        }

        //视频
        if(filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.MP4.code()) ||
                filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.AVI.code()) ||
                filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.MOV.code())) {
            if(size>ftpConfigProperties.getVideoSize()){
                throw new BizException("上传视频大于50M");
            }
            return true;
        }
        throw new BizException("上传类型校验错误");
    }

    /**
     * 创建文件夹
     *
     * @param
     * @param
     * @throws Exception
     */

    public static void createDir(String dirname,FTPClient ftpClient) {
        try {
            boolean b = ftpClient.makeDirectory(dirname);
            log.info("是否在目标服务器上成功建立了文件夹: " + dirname + ","+b);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new BizException("查找创建文件目录失败!");
        }
    }


    /**
     * 建立FTP链接
     *
     * @throws FtpProtocolException
     */
    private  void connectFtp(FTPClient ftpClient) throws FtpProtocolException {
        try {
            // 连接到FTP服务器
            ftpClient.connect(ftpServerProperties.getHost(),ftpServerProperties.getPort());
            // 获取响应码用于验证是否连接成功
            int reply = ftpClient.getReplyCode();
            if (FTPReply.isPositiveCompletion(reply)) {
                ftpClient.setControlEncoding("UTF-8");
                // 登录服务器
                ftpClient.login(ftpServerProperties.getUsername(), ftpServerProperties.getPassword());
                ftpClient.enterLocalPassiveMode();//被动模式
                ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                ftpClient.setBufferSize(1024 * 1024 * 10);
                ftpClient.setDataTimeout(30 * 1000);
            }
        } catch (IOException e) {
            log.error("创建ftp连接失败!"+e.getMessage());
        }
    }


}

