package com.gm.anepoch.digitalbird.biz.water.helper;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.biz.waterconfig.WaterIdConfigLoader;
import com.gm.anepoch.digitalbird.biz.waterconfig.bo.WaterConfigBo;
import com.gm.anepoch.digitalbird.api.utils.redis.RedisUtil;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/19 - 17:59
 */
@Component
@Slf4j
public class WaterHelper {
    @Resource
    private RedisUtil redisUtil;
    @Value("${spring.profiles.active}")
    private String active;
    private static final Long EXPIRE_TIME = 86400L;
    private static final Long MAX_NO = 99999L;

    /**
     * 获取redis中的key
     *
     * @param bizType bizType
     * @return redis key
     */
    public String getWaterKey(String bizType) {
        WaterConfigBo waterConfig = WaterIdConfigLoader.waterConfigMap.get(bizType);
        ConditionUtils.checkArgument(Objects.nonNull(waterConfig), "bizType不存在,请check后请求");
        return active + "_" + waterConfig.getBizNo() + "_" + getOnlineStr(bizType);
    }

    /**
     * 获取redis中的key
     *
     * @param key key
     * @return redis key
     */
    public String getWaterKeyValue(String key) {
        Object value = redisUtil.get(key);
        if (Objects.isNull(value)) {
            return "";
        }
        return redisUtil.get(key).toString();
    }

    /**
     * 获取当前index and inc
     *
     * @param key key
     * @return current index
     */
    public String getAndInc(String key) {
        if (StringUtils.isBlank(key)) {
            return StringUtils.EMPTY;
        }
        long inc = redisUtil.incr(key, 1);
        ConditionUtils.checkArgument(inc < MAX_NO, "已超出最大信号发射量, currentNo : " + inc);
        log.info("current key : {} , current index : {}", key, inc);
        return inc + "";
    }

    /**
     * 获取当前index and inc
     *
     * @param key key
     * @return current index
     */
    public List<String> getAndSet(String key, Long number) {
        if (StringUtils.isBlank(key)) {
            return Lists.newArrayListWithCapacity(0);
        }
        List<String> resultList = Lists.newArrayList();
        for (long i = 0; i < number; i++) {
            resultList.add(getAndInc(key));
        }
        return resultList;
    }

    public long getOnlineDays(Date targetDate) {
        Date now = new Date();
        long nowTime = now.getTime();
        long targetDateTime = targetDate.getTime();
        return (nowTime - targetDateTime) / 24 / 60 / 60 / 1000;
    }

    public String getOnlineStr(String bizType) {
        WaterConfigBo waterConfig = WaterIdConfigLoader.waterConfigMap.get(bizType);
        return Strings.padStart(getOnlineDays(waterConfig.getOnlineTime()) + "", 4, '0');

    }

    public String getActive() {
        return active;
    }

    public WaterHelper setActive(String active) {
        this.active = active;
        return this;
    }
}
