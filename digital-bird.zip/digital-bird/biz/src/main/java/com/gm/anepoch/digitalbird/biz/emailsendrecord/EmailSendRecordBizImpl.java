
package com.gm.anepoch.digitalbird.biz.emailsendrecord;

import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.converter.EmailSendRecordBoConverter;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.SmsSendRecordBo;
import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.service.service.emailsendrecord.EmailSendRecordService;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;


/**
 * @author py
 * @date 2019/4
 */
@Service
@Slf4j
public class EmailSendRecordBizImpl implements EmailSendRecordBiz {
    @Resource
    private EmailSendRecordService emailSendRecordService;

    /**
     * 新增 record
     *
     * @param addEmailSendRecordBo addEmailSendRecordBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean add(EmailSendRecordBo addEmailSendRecordBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(addEmailSendRecordBo), "addEmailSendRecordBo is null");
            }

            @Override
            protected Boolean process() {
                //新增角色信息
                EmailSendRecord newEmailSendRecord = EmailSendRecordBoConverter.convertToEmailSendRecord(addEmailSendRecordBo);
                emailSendRecordService.insert(newEmailSendRecord);
                return true;
            }
        }.execute();
    }

    /**
     * 修改 record
     *
     * @param editEmailSendRecordBo editEmailSendRecordBo
     * @return success true orElse false
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean editById(EmailSendRecordBo editEmailSendRecordBo) {
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(editEmailSendRecordBo), "editEmailSendRecordBo is null");
                ConditionUtils.checkArgument(Objects.nonNull(editEmailSendRecordBo.getId()), "editEmailSendRecordBo id is null");
            }

            @Override
            protected Boolean process() {
                EmailSendRecord oldEmailSendRecord = emailSendRecordService.getDetailById(editEmailSendRecordBo.getId());
                ConditionUtils.checkArgument(Objects.nonNull(oldEmailSendRecord), "oldEmailSendRecord is null");
                //修改记录
                EmailSendRecord waitToUpdate = EmailSendRecordBoConverter.convertToEmailSendRecord(editEmailSendRecordBo);
                emailSendRecordService.update(waitToUpdate);
                return true;
            }
        }.execute();
    }

    /**
     * 查询record集合
     *
     * @param queryEmailSendRecordBo queryEmailSendRecordBo
     * @return record list
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<EmailSendRecordBo> list(EmailSendRecordBo queryEmailSendRecordBo) {
        return new BaseBizTemplate<List<EmailSendRecordBo>>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(queryEmailSendRecordBo), "queryEmailSendRecordBo is null");
            }

            @Override
            protected List<EmailSendRecordBo> process() {
                EmailSendRecord emailSendRecordQuery = EmailSendRecordBoConverter.convertToEmailSendRecord(queryEmailSendRecordBo);
                List<EmailSendRecord> fromDbList = emailSendRecordService.list(emailSendRecordQuery);
                if (CollectionUtils.isEmpty(fromDbList)) {
                    return Lists.newArrayList();
                }
                return JsonMoreUtils.ofList(JsonMoreUtils.toJson(fromDbList), EmailSendRecordBo.class);
            }
        }.execute();
    }

    /**
     * 查询record集合(仅为发送邮件job任务提供)
     * 默认查询状态为waited且状态为sending、retryCount小于3的数据
     *
     * @param recordSize recordSize
     * @return record list
     */
    @Override
    public List<EmailSendRecordBo> listForSendEmailJob(Long recordSize) {
        log.info("listForSendEmailJob start,recordSize: {}", recordSize);
        return new BaseBizTemplate<List<EmailSendRecordBo>>() {
            @Override
            protected List<EmailSendRecordBo> process() {
                List<EmailSendRecord> listFromDb = emailSendRecordService.listForSendEmailJob(recordSize);
                if (CollectionUtils.isEmpty(listFromDb)) {
                    return Lists.newArrayListWithCapacity(0);
                }
                return JsonMoreUtils.ofList(JsonMoreUtils.toJson(listFromDb), EmailSendRecordBo.class);
            }
        }.execute();
    }

    /**
     * 查询record
     *
     * @param recordId recordId
     * @return record orElse null
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public EmailSendRecordBo fetchDetailById(Long recordId) {
        return new BaseBizTemplate<EmailSendRecordBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(Objects.nonNull(recordId), "recordId is null");
            }

            @Override
            protected EmailSendRecordBo process() {
                EmailSendRecord fromDb = emailSendRecordService.getDetailById(recordId);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), EmailSendRecordBo.class);
            }
        }.execute();
    }

    /**
     * 查询最新记录(for check validate code)
     *
     * @param appName        appId
     * @param biz          biz
     * @param templateCode templateCode
     * @param email        email
     * @return record
     */
    @Override
    public EmailSendRecordBo fetchNewestRecord(String appName, String biz, String templateCode, String email) {
        log.info("email fetchNewestRecord biz start, appName - {} , biz - {} ,templateCode - {} , email - {}", appName, biz, templateCode, email);
        return new BaseBizTemplate<EmailSendRecordBo>() {
            @Override
            protected void checkParam() {
                ConditionUtils.checkArgument(StringUtils.isNotBlank(appName), "appName is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(biz), "biz is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(templateCode), "templateCode is null");
                ConditionUtils.checkArgument(StringUtils.isNotBlank(email), "email is null");

            }

            @Override
            protected EmailSendRecordBo process() {
                EmailSendRecord fromDb = emailSendRecordService.getNewestRecord(appName, biz, templateCode, email);
                if (Objects.isNull(fromDb)) {
                    return null;
                }
                return JsonMoreUtils.toBean(JsonMoreUtils.toJson(fromDb), EmailSendRecordBo.class);
            }
        }.execute();
    }
}

