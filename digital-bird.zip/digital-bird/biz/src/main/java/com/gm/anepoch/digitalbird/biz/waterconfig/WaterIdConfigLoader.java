package com.gm.anepoch.digitalbird.biz.waterconfig;

import com.gm.anepoch.digitalbird.biz.water.helper.WaterHelper;
import com.gm.anepoch.digitalbird.biz.waterconfig.bo.WaterConfigBo;
import com.gm.anepoch.digitalbird.api.utils.redis.RedisUtil;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Description: waterId 重载配置
 * 分为两部分:
 * step1 : 项目重启reload一次
 * step2 : 每日凌晨reload一次
 *
 * @author -  pany
 * Time - 2023/9/19 - 17:10
 */
@Component
@Slf4j
public class WaterIdConfigLoader {
    @Resource
    private WaterHelper waterHelper;
    @Resource
    private RedisUtil redisUtil;
    public static Map<String, WaterConfigBo> waterConfigMap = Maps.newConcurrentMap();
    @Resource
    private WaterConfigBiz waterConfigBiz;


    @PostConstruct
    public void reloadWaterId() {
        log.warn("reloadWaterId start.......");
        WaterConfigBo queryWaterConfigBo = new WaterConfigBo();
        //查询所有配置
        List<WaterConfigBo> configListFromDb = waterConfigBiz.list(queryWaterConfigBo);
        if (CollectionUtils.isEmpty(configListFromDb)) {
            log.warn("reloadWaterId fast end, configListFromDb is empty!");
            return;
        }
        //如果有配置,reload data
        configListFromDb.forEach(data -> {
            log.info("loading waterConfig , data : {}", data);
            waterConfigMap.put(data.getBizType(), data);
            if (StringUtils.isNotBlank(waterHelper.getWaterKeyValue(waterHelper.getWaterKey(data.getBizType())))) {
                log.info("loading waterConfig redis config,当前记录在redis中已存在,不进行覆盖,data : {}", data);
                return;
            }
            redisUtil.set(waterHelper.getWaterKey(data.getBizType()), data.getRangeIndex().intValue(), 86400);
        });
    }
}
