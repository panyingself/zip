package com.gm.anepoch.digitalbird.biz.uploadfile.bo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author xiongyu
 * @date 2023年09月20日 15:33
 * The most unusual thing is to live an ordinary life well
 */
@Data
public class UploadFileBo implements Serializable {

    private String originalUrl;

    private String accessUrl;
}
