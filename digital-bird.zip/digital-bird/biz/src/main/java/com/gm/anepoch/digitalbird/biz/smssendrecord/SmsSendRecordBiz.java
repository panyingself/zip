
package com.gm.anepoch.digitalbird.biz.smssendrecord;

import com.gm.anepoch.digitalbird.commons.model.*;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.*;
import java.util.List;


/**
 * @author py
 * @date 2019/4
 */
public interface SmsSendRecordBiz {
	/**
	 * 新增 record
	 *
	 * @param addSmsSendRecordBo addSmsSendRecordBo
	 * @return success true orElse false
	 */
	boolean add(SmsSendRecordBo addSmsSendRecordBo);

	/**
	 * 修改 record
	 *
	 * @param editSmsSendRecordBo editSmsSendRecordBo
	 * @return success true orElse false
	 */
	boolean editById(SmsSendRecordBo editSmsSendRecordBo);
	/**
	 * 查询record集合
	 * @param querySmsSendRecordBo querySmsSendRecordBo
	 * @return record list
	 */
	List<SmsSendRecordBo> list(SmsSendRecordBo querySmsSendRecordBo);

	/**
	 * 查询record detail
	 * @param recordId recordId
	 * @return record detail
	 */
	SmsSendRecordBo fetchDetailById(Long recordId);

	/**
	 * 查询最新记录(for check validate code)
	 *
	 * @param appId        appId
	 * @param biz          biz
	 * @param templateCode templateCode
	 * @param phone        phone
	 * @return record
	 */
	SmsSendRecordBo fetchNewestRecord(String appId, String biz, String templateCode, String phone);
}

