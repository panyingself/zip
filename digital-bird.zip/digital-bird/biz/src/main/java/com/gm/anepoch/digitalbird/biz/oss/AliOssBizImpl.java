package com.gm.anepoch.digitalbird.biz.oss;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.OSSException;
import com.aliyun.oss.model.VoidResult;
import com.gm.anepoch.base.commons.exception.BizException;
import com.gm.anepoch.base.commons.monitor.BaseBizTemplate;
import com.gm.anepoch.base.commons.utils.ConditionUtils;
import com.gm.anepoch.digitalbird.api.co.request.OssDeleteUrlFeignRequest;
import com.gm.anepoch.digitalbird.api.enums.CdnMappingEnvironmentEnum;
import com.gm.anepoch.digitalbird.api.properties.CommonPropertiesBird;
import com.gm.anepoch.digitalbird.api.utils.resourceurl.ResourceUrlSetUpUtils;
import com.gm.anepoch.digitalbird.biz.uploadfile.bo.UploadFileBo;
import com.gm.anepoch.digitalbird.commons.config.OssConfig;
import com.gm.anepoch.digitalbird.commons.enums.UploadSuffixTypeEnums;
import com.gm.anepoch.digitalbird.commons.model.OssRouteConfig;
import com.gm.anepoch.digitalbird.service.service.ossroutconfig.OssRouteConfigService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
/**
 *
 * @author xiongyu
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Slf4j
@Component
public class AliOssBizImpl implements AliOssBiz {
    @Resource
    private OssConfig ossConfig;
    private static final String REPLACE_STR_DATE = "${date}";

    private static final String CASE_MANUAL_COLLECTION = "case_manual_collection";

    private static final Integer IMG_SIZE_NORMAL = 5242880;



    @Resource
    private OssRouteConfigService ossRouteConfigService;

    @Resource
    private ResourceUrlSetUpUtils resourceUrlSetUpUtils;

    @Resource
    private CommonPropertiesBird commonPropertiesBird;

    /**
     * @param bizType     业务类型@See ossRouteConfig
     * @param fileName    文件名
     * @param inputStream inputStream
     * @param fileSize    fileSize
     * @return UploadFileBo
     */
    @Override
    public UploadFileBo upload(String bizType, String fileName, InputStream inputStream, long fileSize) {
        log.info("oss upload biz start, bizType : {} , fileName : {} , fileSize : {}", bizType, fileName, fileSize);
        return new BaseBizTemplate<UploadFileBo>() {
            @Override
            protected void checkParam() {
                //校验类型大小
                checkContentType(fileName.substring(fileName.lastIndexOf(".")), fileSize,bizType);
            }

            @Override
            protected UploadFileBo process() {
                OssRouteConfig ossRouteConfig = OssRouteConfigLoader.waterConfigMap.get(bizType);
                ConditionUtils.checkArgument(Objects.nonNull(ossRouteConfig), "不支持的业务类型 : " + bizType);
                // 文件在OSS中存储的路径，此处使用日期 + 当前的毫秒数 + 文件名称 来作为文件名，防止文件重名
                String objectName = getResourcePath(ossRouteConfig, fileName);
                OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
                try {
                    // 创建PutObject请求,开始传输文件
                    ossClient.putObject(ossRouteConfig.getBucketName(), objectName, inputStream);
                } catch (OSSException oe) {
                    log.error("Error Message:" + oe.getErrorMessage());
                } catch (ClientException ce) {
                    log.error("Error Message:" + ce.getMessage());
                } finally {
                    if (ossClient != null) {
                        // 释放连接
                        ossClient.shutdown();
                    }
                }
                StringBuilder stringBuilder = new StringBuilder(CdnMappingEnvironmentEnum.getMessageByCode(commonPropertiesBird.getActive()));
                stringBuilder.append(objectName);
                log.info("文件上传到:{}", stringBuilder.toString());
                //可访问的url
                String accessUrl = resourceUrlSetUpUtils.encryptResourceUrl(objectName);
                UploadFileBo uploadFileBo = new UploadFileBo();
                uploadFileBo.setOriginalUrl(objectName);
                uploadFileBo.setAccessUrl(accessUrl);
                // 返回图片的外网访问url
                return uploadFileBo;
            }
        }.execute();

    }

    @Override
    public Boolean deleteOssUrl(OssDeleteUrlFeignRequest request) {
        log.info("oss deleteOssUrl biz start, request : {}", request);
        return new BaseBizTemplate<Boolean>() {
            @Override
            protected void checkParam() {
                //校验类型大小
                ConditionUtils.checkArgument(CollectionUtils.isNotEmpty(request.getFileNameList()), "文件名称集合不能为空");
                ConditionUtils.checkArgument(StringUtils.isNotEmpty(request.getBizType()), "文件业务类型不能为空");

            }

            @Override
            protected Boolean process() {
                OSS ossClient = new OSSClientBuilder().build(ossConfig.getEndpoint(), ossConfig.getAccessKeyId(), ossConfig.getAccessKeySecret());
                OssRouteConfig infoByBizType = ossRouteConfigService.getInfoByBizType(request.getBizType());
                ConditionUtils.checkArgument(Objects.nonNull(infoByBizType), "业务类型不存在!");
                String resourcePath = infoByBizType.getResourcePath().replace("/${date}/", "");
                try {
                    for(String url:request.getFileNameList()){
                        if(!url.startsWith(resourcePath)){
                            log.error("删除的文件路径不匹配：{}",url);
                            continue;
                        }
                        boolean exist = ossClient.doesObjectExist(ossConfig.getBucketName(),url);
                        if (!exist) {
                            log.error("文件不存在,文件路径：{}",url);
                        } else {
                            // 删除文件。
                            VoidResult voidResult = ossClient.deleteObject(ossConfig.getBucketName(), url);
                            log.info("文件删除返回信息: {}",voidResult.getResponse().isSuccessful());
                            log.info("删除的图片路径：{}",url);
                        }
                    }
                }catch (Exception e){
                    log.error("文件删除失败");
                    throw new BizException("文件删除失败");
                }finally {
                    // 关闭 OSS 客户端
                    if (ossClient != null) {
                        // 释放连接
                        ossClient.shutdown();
                    }
                }

                return true;
            }
        }.execute();


    }

    private String getResourcePath(OssRouteConfig ossRouteConfig, String fileName) {
        // 文件在OSS中存储的路径，此处使用日期 + 当前的毫秒数 + 文件名称 来作为文件名，防止文件重名
        //resource path from db like 【case/auto/${date}/】
        if (ossRouteConfig.getResourcePath().contains(REPLACE_STR_DATE)) {
            return ossRouteConfig.getResourcePath().replace(REPLACE_STR_DATE, new SimpleDateFormat("yyyy/MM/dd").format(new Date()) + "/" + System.currentTimeMillis()) + "-" + fileName;
        }
        return ossRouteConfig.getResourcePath() + System.currentTimeMillis() + "-" + fileName;
    }


    /**
     * 判断类型
     *
     * @param filenameExtension 文件名称后缀
     * @return
     */
    private Boolean checkContentType(String filenameExtension, long size,String bizType) {
        //图片
        if (filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.JPEG.code()) || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.JPG.code())
                || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.PNG.code()) || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.BMP.code()) || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.SVG.code())) {

            //如果业务类型为手动上传,图片限制大小为50M
            if(StringUtils.equalsIgnoreCase(bizType,CASE_MANUAL_COLLECTION)){
                if(size > ossConfig.getImgSize()){
                    throw new BizException("手动上传竞品图片大于50M");
                }
            }else if(size > IMG_SIZE_NORMAL){
                throw new BizException("上传图片大于5M");
            }
            return true;
        }

        //视频
        if (filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.MP4.code()) || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.AVI.code()) || filenameExtension.equalsIgnoreCase(UploadSuffixTypeEnums.MOV.code())) {
            if (size > ossConfig.getVideoSize()) {
                throw new BizException("上传视频大于50M");
            }
            return true;
        }
        throw new BizException("上传类型校验错误");
    }


}
