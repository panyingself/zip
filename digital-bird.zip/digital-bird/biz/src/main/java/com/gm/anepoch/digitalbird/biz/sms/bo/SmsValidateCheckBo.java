package com.gm.anepoch.digitalbird.biz.sms.bo;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * Description: 短信发送请求
 *
 * @author -  pany
 * Time - 2023/9/6 - 17:41
 */
@Data
public class SmsValidateCheckBo extends SmsSendBo {

    /**
     * 邮件模板code - 必填
     */
    @NotEmpty(message = "validateCode不允许为空")
    private String validateCode;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
