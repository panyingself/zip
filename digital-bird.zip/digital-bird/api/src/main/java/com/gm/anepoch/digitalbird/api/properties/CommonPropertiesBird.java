package com.gm.anepoch.digitalbird.api.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author xiongyu
 * @date 2023年09月04日 14:33
 * The most unusual thing is to live an ordinary life well
 */
@Data
@Component
public class CommonPropertiesBird {
    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${spring.profiles.active}")
    private String active;

    private String underLine = "_";
}
