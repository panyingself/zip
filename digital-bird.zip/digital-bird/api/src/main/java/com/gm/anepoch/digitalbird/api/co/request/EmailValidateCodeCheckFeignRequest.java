package com.gm.anepoch.digitalbird.api.co.request;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotEmpty;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/9 - 15:04
 */
@Data
public class EmailValidateCodeCheckFeignRequest extends EmailSendFeignRequest {
    @NotEmpty(message = "validateCode不允许为空")
    private String validateCode;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
