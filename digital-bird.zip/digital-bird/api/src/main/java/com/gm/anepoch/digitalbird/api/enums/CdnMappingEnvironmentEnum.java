/**
 * gm-activity
 *
 * Copyright gm, Inc. All rights reserved.
 *
 * @author mzhoulei
 * @date 2022-10-15 15:49
 */
package com.gm.anepoch.digitalbird.api.enums;

import java.util.Objects;

/**
 * 类型
 * @author mzhoulei
 * @date 2022-10-15 15:49
 */
public enum CdnMappingEnvironmentEnum {

    //cdn域名枚举
    prod("prod","https://digital-resources-oss-prod.guanmeikj.com/"),
    dev("dev","https://digitalresources-testvip.guanmeikj.com/"),
    test("test","https://digitalresources-testvip.guanmeikj.com/");

    private String code;
    private String message;
    CdnMappingEnvironmentEnum(String code, String message){
        this.code = code;
        this.message = message;
    }


    /**
     * 通过code获取枚举描述
     *
     * @param appSystemCode 枚举code值
     * @return message 枚举描述
     */
    public static String getMessageByCode(String appSystemCode) {
        if (Objects.isNull(appSystemCode)) {
            return null;
        }
        for (CdnMappingEnvironmentEnum enumOne : CdnMappingEnvironmentEnum.values()) {
            if (enumOne.code.equals(appSystemCode)) {
                return enumOne.message;
            }
        }
        return null;
    }

    public String code() {
        return code;
    }

    public String message() {
        return message;
    }
}
