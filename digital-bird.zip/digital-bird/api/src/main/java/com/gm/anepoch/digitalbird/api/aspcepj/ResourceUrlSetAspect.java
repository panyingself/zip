package com.gm.anepoch.digitalbird.api.aspcepj;

import com.gm.anepoch.digitalbird.api.annotation.GmResourceUrlEncryption;
import com.gm.anepoch.digitalbird.api.properties.CommonPropertiesBird;
import com.gm.anepoch.digitalbird.api.utils.java.ReflexUtils;
import com.gm.anepoch.digitalbird.api.utils.resourceurl.ResourceUrlSetUpUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;
/**
 *
 * @author xiongyu
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Aspect
@Component
public class ResourceUrlSetAspect {
    @Resource
    private ResourceUrlSetUpUtils resourceUrlSetUpUtils;

    @Resource
    private CommonPropertiesBird commonPropertiesBird;
    @AfterReturning(
            pointcut = "execution(* com.gm.anepoch..controller..*(..))",
            returning = "response"
    )
    public void beforeResourceUrlSetOperation(Object response) throws NoSuchFieldException, IllegalAccessException {

        if(Objects.isNull(response)){
            //如果返回类为空直接不操作快速返回
            return;
        }
        // 检查 response 是否为列表
        if (response instanceof List<?>) {
            List<?> listResponse = (List<?>) response;
            for (Object obj : listResponse) {
                checkResourceUrlField(obj);
            }
            return;
        }
        //不为列表的情况
        checkResourceUrlField(response);
    }

    private void checkResourceUrlField(Object response) throws IllegalAccessException, NoSuchFieldException {
        // 使用反射获取类和父类的所有字段
        List<Field> fatherAllField = ReflexUtils.getFatherAllField(response);
        for (Field field : fatherAllField) {
            // 设置字段可访问，以便访问私有字段
            field.setAccessible(true);
            Object res = field.get(response);
            // 如果字段是一个复杂对象或者集合，则递归处理
            if (res instanceof List<?> || (!field.getType().isPrimitive() && !field.getType().getName().startsWith("java."))) {
                beforeResourceUrlSetOperation(res);
            }
            // 检查字段是否带有 @ModifyField 注解 并且必须为String类型
            if (field.isAnnotationPresent(GmResourceUrlEncryption.class) && Objects.equals(field.getType().getName(),"java.lang.String")) {
                // 对带有注解的字段执行操作逻辑
                // 获取字段的当前值
                String fieldValue = (String) field.get(response);
                if(StringUtils.isEmpty(fieldValue)){
                    continue;
                }

                String accessUrl = resourceUrlSetUpUtils.encryptResourceUrl(fieldValue);
                // 将修改后的值设置回字段
                field.set(response, accessUrl);
            }
        }
    }

}
