package com.gm.anepoch.digitalbird.api.utils.redis;

import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.config.SingleServerConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * @author xiongyu
 * @date 2023/1
 * @description Redisson 配置类
 */
@Configuration
public class MyRedissonConfig {

    @Value(value = "${spring.redis.host:}")
    private String host;
    @Value(value = "${spring.redis.port:}")
    private Integer port;
    @Value(value = "${spring.redis.database:}")
    private Integer database ;
    @Value(value = "${spring.redis.password:}")
    private String password;

    /**
     * 单Redis节点模式配置方法
     * 其他配置參數，看:
     * <a href = "https://github.com/redisson/redisson/wiki/2.-%E9%85%8D%E7%BD%AE%E6%96%B9%E6%B3%95#26-%E5%8D%95redis%E8%8A%82%E7%82%B9%E6%A8%A1%E5%BC%8F">
     * 单Redis节点模式配置方法
     * </a>
     *
     * @return {@link }
     */
    @Bean(destroyMethod = "shutdown")
    RedissonClient redisson() {
        if(StringUtils.isBlank(host)){
            return null;
        }
        Config config = new Config();
        SingleServerConfig singleServerConfig = config.useSingleServer();
        //可以用"rediss://"来启用SSL连接
        String address = "redis://" + host + ":" + port;
        singleServerConfig.setAddress(address);
        //设置 数据库编号
        singleServerConfig.setDatabase(database);
        singleServerConfig.setPassword(password);
        //连接池大小:默认值：64
        return Redisson.create(config);

    }

}


