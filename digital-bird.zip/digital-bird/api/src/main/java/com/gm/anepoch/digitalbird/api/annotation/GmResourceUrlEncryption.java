package com.gm.anepoch.digitalbird.api.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
/**
 *
 * @author xiongyu
 * @description 返回对象资源url字段预处理
 * @date 2023/10/12 16:50
 * @return null
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface GmResourceUrlEncryption {
}
