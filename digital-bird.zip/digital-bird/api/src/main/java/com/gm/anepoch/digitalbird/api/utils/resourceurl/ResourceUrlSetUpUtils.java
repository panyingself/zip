package com.gm.anepoch.digitalbird.api.utils.resourceurl;

import com.gm.anepoch.base.commons.exception.BizException;
import com.gm.anepoch.digitalbird.api.enums.CdnMappingEnvironmentEnum;
import com.gm.anepoch.digitalbird.api.properties.CommonPropertiesBird;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author xiongyu
 * @date 2023年09月20日 14:00
 * 资源url加密解密工具
 */
@Slf4j
@Component
public class ResourceUrlSetUpUtils {
    /** 加密key */
    private  String secretKey = "aliyuncdnexp1234";

    private String authKey = "?auth_key=";

    @Resource
    private CommonPropertiesBird commonPropertiesBird;


    /**
     *
     * @author xiongyu
     * @description 加密url
     * @date 2023/9/20 11:55
     * @param originalUrl 原始url
     * @return java.lang.String
     */
    public  String encryptResourceUrl(String originalUrl) {
        //CND域名选择
        String url = CdnMappingEnvironmentEnum.getMessageByCode(commonPropertiesBird.getActive());
        if(StringUtils.isEmpty(url)){
            log.error("环境匹配不到CDN域名: 环境变量{},服务名称{}",commonPropertiesBird.getActive(),commonPropertiesBird.getApplicationName());
            throw new BizException("环境匹配不到CDN域名,请联系开发工程师");
        }
        String encodeUrl = null;
        try {
            encodeUrl = URLEncoder.encode(originalUrl, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            log.error("图片encode失败,图片uri:{}",encodeUrl);
        }
        String uri = url + encodeUrl ;
        // 生成时间戳（以毫秒为单位）
        long timestamp = System.currentTimeMillis() / 1000;
        String resultUrl = aAuth(uri, secretKey, timestamp);
        return resultUrl;
    }

    /**
     *
     * @author xiongyu
     * @description 转义汉字
     * @date 2023/10/10 22:45
     * @param accessUrl
     * @return java.lang.String
     */
    public  String reductionOriginalUrl(String accessUrl) {
        // 去除前缀
        String trimmedUrl = removePrefix(accessUrl);
        //如果去掉前缀无变化则保留原始路径
        if(StringUtils.equalsIgnoreCase(trimmedUrl,accessUrl)){
            return accessUrl;
        }
        // 去除后缀
        int endIndex = trimmedUrl.indexOf(authKey);
        if (endIndex >= 0) {
            trimmedUrl = trimmedUrl.substring(0, endIndex);
        }
        String decode = trimmedUrl;
        try{
             decode = URLDecoder.decode(trimmedUrl, "UTF-8");
        }catch (Exception e){
            log.error("图片解码失败，图片url:{}",decode);
        }
        log.info("图片地址",decode);
        return decode;
    }

    public String removePrefix(String originalUrl) {
        //CND域名选择
        String url = CdnMappingEnvironmentEnum.getMessageByCode(commonPropertiesBird.getActive());
        if(StringUtils.isEmpty(url)){
            log.error("环境匹配不到CDN域名: 环境变量{},服务名称{}",commonPropertiesBird.getActive(),commonPropertiesBird.getApplicationName());
            throw new BizException("环境匹配不到CDN域名,请联系开发工程师");
        }
        if (originalUrl.startsWith(url)) {
            return originalUrl.substring(url.length());
        } else {
            return originalUrl;
        }
    }
    private String md5Sum(String src) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        md5.update(StandardCharsets.UTF_8.encode(src));
        return String.format("%032x", new BigInteger(1, md5.digest()));
    }
    private String aAuth(String uri, String key, long exp) {
        String pattern = "^(http://|https://)?([^/?]+)(/[^?]*)?(\\?.*)?$";
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(uri);
        String scheme = "", host = "", path = "", args = "";
        if (m.find()) {
            scheme = m.group(1) == null ? "http://" : m.group(1);
            host = m.group(2) == null ? "" : m.group(2);
            path = m.group(3) == null ? "/" : m.group(3);
            args = m.group(4) == null ? "" : m.group(4);
        } else {
            System.out.println("NO MATCH");
        }
        String rand = "0";
        String uid = "0";
        String sString = String.format("%s-%s-%s-%s-%s", path, exp, rand, uid, key);
        String hashValue = md5Sum(sString);
        String authKey = String.format("%s-%s-%s-%s", exp, rand, uid, hashValue);
        if (args.isEmpty()) {
            return String.format("%s%s%s%s?auth_key=%s", scheme, host, path, args, authKey);
        } else {
            return String.format("%s%s%s%s&auth_key=%s", scheme, host, path, args, authKey);
        }
    }

}

