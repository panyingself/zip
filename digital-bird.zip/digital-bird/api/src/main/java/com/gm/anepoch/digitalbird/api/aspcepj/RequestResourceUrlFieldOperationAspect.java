package com.gm.anepoch.digitalbird.api.aspcepj;

import com.gm.anepoch.digitalbird.api.annotation.GmResourceUrlDecrypt;
import com.gm.anepoch.digitalbird.api.utils.java.ReflexUtils;
import com.gm.anepoch.digitalbird.api.utils.resourceurl.ResourceUrlSetUpUtils;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.util.List;
/**
 *
 * @author xiongyu
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Aspect
@Component
public class RequestResourceUrlFieldOperationAspect {

    @Resource
    private ResourceUrlSetUpUtils resourceUrlSetUpUtils;

    @Before("execution(* com.gm.anepoch..controller..*(..)) && args(request)")
    public Object modifyRequestResourceUrlObject(Object request)  {
        if (request != null) {
            if (request instanceof List<?>) {
                List<?> listRequest = (List<?>) request;
                for (Object obj : listRequest) {
                    checkRequestResourceUrlField(obj);
                }
                return request;
            }
            checkRequestResourceUrlField(request);
        }
        return request;
    }


    /**
     *
     * @author xiongyu
     * @description 校验入参字段是否带有图片url注解
     * @date 2023/10/12 16:12
     * @param request
     */
    private void checkRequestResourceUrlField(Object request) {
        List<Field> fatherAllField = ReflexUtils.getFatherAllField(request);
        for (Field field : fatherAllField) {
            try {
                // 设置字段可访问，以便访问私有字段
                field.setAccessible(true);
                Object res = field.get(request);
                if (res instanceof List<?> || (!field.getType().isPrimitive() && !field.getType().getName().startsWith("java."))) {
                    modifyRequestResourceUrlObject(res);
                }
                if (field.isAnnotationPresent(GmResourceUrlDecrypt.class) && field.getType() == String.class) {
                    // 如果字段是一个复杂对象或者集合，则递归处理
                    String fieldValue = (String) field.get(request);
                    if (StringUtils.isEmpty(fieldValue)) {
                        continue;
                    }
                    String original = resourceUrlSetUpUtils.reductionOriginalUrl(fieldValue);
                    // 将字段值设置为新值
                    field.set(request, original);

                }
            } catch (IllegalAccessException e) {
                continue;
            }
        }
    }

}
