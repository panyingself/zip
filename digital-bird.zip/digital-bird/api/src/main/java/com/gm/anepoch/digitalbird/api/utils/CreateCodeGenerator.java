package com.gm.anepoch.digitalbird.api.utils;

import com.gm.anepoch.digitalbird.api.utils.redis.RedisUtil;
import com.google.common.base.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * @author zhangdh
 */
@Component
public class CreateCodeGenerator {

    @Value("${spring.application.name}")
    private String applicationName;
    @Value("${spring.profiles.active}")
    private String active;
    @Resource
    private RedisUtil redisUtil;

    public static String createCode(String codeType) {
        UUID uuid = UUID.randomUUID();
        String uuidString = uuid.toString();
        
        // 取UUID的前半部分
        String uuidPrefix = uuidString.substring(0, 16);
        
        // 组合UUID的前半部分和自定义规则
        String customUuId = codeType+"-"+uuidPrefix;
        
        return customUuId;
    }

    /**
     * 生成业务编码
     * @param bizType 业务类型
     * @return String
     */
    public String createBizCode(String bizType) {
        String key = active+"_"+applicationName+"_BizCode_"+bizType;
        String format = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        long inc = redisUtil.incr(key, 1);
        if(inc==1){
            //设置过期时间
            Duration duration = Duration.between(LocalDateTime.now(), LocalDate.now().plusDays(1).atStartOfDay());
            redisUtil.expire(key,duration.getSeconds());
        }
        return bizType+format+ Strings.padStart(String.valueOf(inc), 4, '0');
    }
}
