package com.gm.anepoch.digitalbird.api.co.request;

import lombok.Data;

import java.io.Serializable;
import java.util.List;
/**
 *
 * @author xiongyu
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Data
public class OssDeleteUrlFeignRequest implements Serializable {

    /**
     * 示例
     * case/caseinfo/auto/2023-11-02/天猫-Lancome兰蔻官方旗舰店-2023-11-02-店铺首页-女性-首图.jpg
     */
    private List<String> fileNameList;

    /**业务类型**/
    private String bizType;
}
