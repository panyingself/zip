package com.gm.anepoch.digitalbird.api.co.request;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotEmpty;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/8 - 14:05
 */
@Data
public class SmsValidateCodeCheckFeignRequest extends SmsSendFeignRequest {
    @NotEmpty(message = "validateCode不允许为空")
    private String validateCode;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
