package com.gm.anepoch.digitalbird.api.utils.java;

import com.google.common.collect.Lists;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author xiongyu
 * @date 2023年10月12日 16:55
 * The most unusual thing is to live an ordinary life well
 */
public class ReflexUtils {

    /**
     *获取子类和父类所有的字段
     * @author xiongyu
     * @description
     * @date 2023/10/12 16:10
     * @param request
     * @return java.util.List<java.lang.reflect.Field>
     */
    public static List<Field> getFatherAllField(Object request){
        List<Field> allFields = Lists.newArrayList();
        if(Objects.isNull(request)){
            //如果对象为空直接略过
            return allFields;
        }
        Class<?> requestClass = request.getClass();

        // 获取子类的字段
        Field[] childFields = requestClass.getDeclaredFields();
        for (Field field : childFields) {
            allFields.add(field);
        }

        // 获取父类的字段
        Class<?> parentClass = requestClass.getSuperclass();
        while (parentClass != null) {
            Field[] parentFields = parentClass.getDeclaredFields();
            for (Field field : parentFields) {
                allFields.add(field);
            }
            parentClass = parentClass.getSuperclass();
        }

        return allFields;
    }
}
