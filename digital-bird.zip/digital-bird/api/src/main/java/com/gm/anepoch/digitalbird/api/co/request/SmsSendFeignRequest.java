package com.gm.anepoch.digitalbird.api.co.request;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * Description: 短信发送请求
 *
 * @author -  pany
 * Time - 2023/9/6 - 17:41
 */
@Data
public class SmsSendFeignRequest implements Serializable {
    /**
     * 应用名 - 必填
     */
    @NotEmpty(message = "appName不允许为空")
    private String appName;
    /**
     * 业务 - 必填
     */
    @NotEmpty(message = "biz不允许为空")
    private String biz;
    /**
     * 短信接收人 - 必填
     */
    @NotEmpty(message = "receivePhone不允许为空")
    private String receivePhone;
    /**
     * 邮件模板code - 必填
     */
    @NotEmpty(message = "templateCode不允许为空")
    private String templateCode;

    /**
     * 收件人 - 必填
     */
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
