package com.gm.anepoch.digitalbird.commons.model;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * @author py
 * @date 2019/4
 */
@Data
public class WaterConfig implements Serializable {
    /**
     * 主键id
     */
    private Long id;
    /**
     * 业务类型
     */
    private String bizType;
    /**
     * 业务编号
     */
    private String bizNo;
    /**
     * 当前使用号段区间left
     */
    private Long rangeLeft;
    /**
     * 当前号段区间right
     */
    private Long rangeRight;
    /** 当前号段区间index */
    private Long rangeIndex;
    /**
     * 上线时间
     */
    private Date onlineTime;
    /**
     * 创建时间
     */
    private java.util.Date createTime;
    /**
     * 修改时间
     */
    private java.util.Date updateTime;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}

