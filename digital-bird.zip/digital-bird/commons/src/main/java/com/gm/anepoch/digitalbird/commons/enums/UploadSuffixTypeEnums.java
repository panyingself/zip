package com.gm.anepoch.digitalbird.commons.enums;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 21:28
 */
public enum UploadSuffixTypeEnums {
    /**
     * 图片视频格式后缀
     */
    JPEG(".jpeg", "jpeg格式"),
    JPG(".jpg", "jpg格式"),
    PNG(".png", "png格式"),
    BMP(".bmp", "bmp格式"),
    SVG(".svg", "svg格式"),
    MP4(".mp4", "mp4格式"),
    AVI(".avi", "avi格式"),
    MOV(".mov", "mov格式"),

    ;

    private final String code;
    private final String message;

    UploadSuffixTypeEnums(String code, String message) {
        this.code = code;
        this.message = message;
    }


    public String code() {
        return code;
    }

    public String message() {
        return message;
    }
}
