package com.gm.anepoch.digitalbird.commons.utils;

import com.gm.anepoch.digitalbird.commons.constants.EmailConstants;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

import javax.mail.Address;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.UUID;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 14:52
 */
@Slf4j
public final class EmailUtils {
    private EmailUtils() {

    }

    /**
     * 生成消息id
     *
     * @param mailFrom
     * @return
     */
    public static String genMessageId(String mailFrom) {
        // message-id 必须符合 first-part@last-part
        String[] mailInfo = mailFrom.split("@");
        String domain = mailFrom;
        int index = mailInfo.length - 1;
        if (index >= 0) {
            domain = mailInfo[index];
        }
        UUID uuid = UUID.randomUUID();
        return '<' + uuid.toString() + '@' + domain + '>';
    }

    /**
     * 构建邮件发件人信息
     *
     * @return InternetAddress
     */
    public static InternetAddress buildEmailFrom() {
        // 设置发件人邮件地址和名称。填写控制台配置的发信地址。和上面的mail.user保持一致。名称用户可以自定义填写。
        //from 参数,可实现代发，注意：代发容易被收信方拒信或进入垃圾箱。
        try {
            return new InternetAddress("notify@digitalm-dev.guanmeikj.com", "冠美科技");
        } catch (UnsupportedEncodingException e) {
            log.error("构建邮箱发件人信息异常......");
            throw new RuntimeException(e);
        }
    }

    /**
     * 构建邮件回信人信息
     *
     * @return InternetAddress
     */
    public static Address[] buildEmailReplyTo() {
        // 设置发件人邮件地址和名称。填写控制台配置的发信地址。和上面的mail.user保持一致。名称用户可以自定义填写。
        //from 参数,可实现代发，注意：代发容易被收信方拒信或进入垃圾箱。
        Address[] a = new Address[1];
        try {
            a[0] = new InternetAddress("收信地址");
            return a;
        } catch (AddressException e) {
            log.error("构建邮箱发件人信息异常......");
            throw new RuntimeException(e);
        }
    }

    /**
     * 构建邮件发件人信息
     *
     * @return InternetAddress
     */
    public static InternetAddress buildEmailTo(String emailTo) {
        // 设置发件人邮件地址和名称。填写控制台配置的发信地址。和上面的mail.user保持一致。名称用户可以自定义填写。
        //from 参数,可实现代发，注意：代发容易被收信方拒信或进入垃圾箱。
        try {
            return new InternetAddress((emailTo));
        } catch (AddressException e) {
            log.error("构建邮箱收件人信息异常......");
            throw new RuntimeException(e);
        }
    }

    /**
     * 构建email props信息
     *
     * @return Properties
     */
    public static Properties buildEmailProps() {
        // 配置发送邮件的环境属性
        Properties props = new Properties();
        // 表示SMTP发送邮件，需要进行身份验证
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtpdm.aliyun.com");
        //设置端口：或"25", 如果使用ssl，则去掉使用80或25端口的配置，进行如下配置：
        props.put("mail.smtp.port", "80");
        //加密方式：
        props.put("mail.smtp.from", EmailConstants.EMAIL_USER_FROM);
        // 发件人的账号（在控制台创建的发信地址）
        props.put("mail.user", EmailConstants.EMAIL_USER_FROM);
        // 发信地址的smtp密码（在控制台选择发信地址进行设置）
        props.put("mail.password", EmailConstants.EMAIL_SMTP_PWD);
        //用于解决附件名过长导致的显示异常
        System.setProperty("mail.mime.splitlongparameters", "false");
        return props;
    }

    public static String getUserContext() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
