package com.gm.anepoch.digitalbird.commons.constants;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/8 - 9:54
 */
public interface SmsConstants {
    public static final String ACCESS_KEY_ID = "LTAI5t8G2cRLF7Nmcu5cBTHP";
    public static final String ACCESS_KEY_SECRET = "Ej6RRHnD6lcF7NjzzFZNPo1bOa59u5";
    public static final String END_POINT = "dysmsapi.aliyuncs.com";
}
