package com.gm.anepoch.digitalbird.commons.constants;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 14:54
 */
public interface EmailConstants {
    /**
     * 邮箱smtp密码
     */
    public static String EMAIL_SMTP_PWD = "ABCabc123456";
    /**
     * 发件人
     */
    public static String EMAIL_USER_FROM = "notify@digitalm-dev.guanmeikj.com";
}
