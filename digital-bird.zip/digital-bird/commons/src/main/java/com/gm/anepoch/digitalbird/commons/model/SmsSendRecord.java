package com.gm.anepoch.digitalbird.commons.model;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * @author py
 * @date 2019/4
 */
@Data
public class SmsSendRecord implements Serializable {
    /**
     * 主键id
     */
    private Long id;
    /**
     * 应用名
     */
    private String appName;
    /**
     * 业务
     */
    private String biz;
    /**
     * 收信人手机号
     */
    private String receivePhone;
    /**
     * 签名
     */
    private String signName;
    /**
     * 模板code
     */
    private String templateCode;
    /**
     * 模板参数
     */
    private String templateParams;
    /**
     * 验证码
     */
    private String validateCode;
    /**
     * 过期时间
     */
    private java.util.Date expireTime;
    /**
     * 发送状态：待发送，已发送，发送成功，发送失败
     */
    private String status;
    /**
     * 创建时间
     */
    private java.util.Date createTime;
    /**
     * 修改时间
     */
    private java.util.Date updateTime;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}

