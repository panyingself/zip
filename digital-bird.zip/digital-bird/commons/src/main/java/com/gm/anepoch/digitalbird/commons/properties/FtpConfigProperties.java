package com.gm.anepoch.digitalbird.commons.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author mzhoulei
 * @date 2022-10-29 17:10
 */
@Data
@Component
@ConfigurationProperties(prefix = "ftp.config")
public class FtpConfigProperties {


    /**
     *图片最大尺寸
     */
    private long imgSize;

    /**
     * 视频最大尺寸
     */
    private long videoSize;





}
