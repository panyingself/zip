package com.gm.anepoch.digitalbird.commons.enums;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 21:28
 */
public enum EmailSendStatusEnums {
    /**
     * 待发送
     */
    WAITED("waited", "待发送"),
    /**
     * 发送中
     */
    SENDING("sending", "发送中"),
    /**
     * 发送成功
     */
    SUCCESS("success", "发送成功"),
    /**
     * 发送失败
     */
    FAILUERE("failure", "发送失败"),
    ;

    private final String code;
    private final String message;

    EmailSendStatusEnums(String code, String message) {
        this.code = code;
        this.message = message;
    }


    public String code() {
        return code;
    }

    public String message() {
        return message;
    }
}
