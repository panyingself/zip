package com.gm.anepoch.digitalbird.commons.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 16:28
 */
@Data
@Slf4j
@Component
@ConfigurationProperties(prefix = "alioss")
public class OssConfig {
    /**
     * 区域
     */
    private String endpoint;
    /**
     * key
     */
    private String accessKeyId;
    /**
     * secret
     */
    private String accessKeySecret;
    /**
     * bucket名称
     */
    private String bucketName;
    /**
     * 文件分组名称
     */
    private String fileGroup;

    private long imgSize;

    private long videoSize;
}
