package com.gm.anepoch.digitalbird.commons.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author mzhoulei
 * @date 2022-10-29 17:10
 */
@Data
@Component
@ConfigurationProperties(prefix = "ftp.server")
public class FtpServerProperties {


    /**
     *host
     */
    private String host;
    /**
     *端口号
     */
    private Integer port;

    /**
     * 用户名
     */
    private String username;

    /**
     * 密码
     */
    private String password;

    /**
     * 文件根目录
     */
    private String directory;

    /**
     * 解析域名
     */
    private String accessingDomainNames;





}
