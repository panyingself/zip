package com.gm.anepoch.digitalbird.commons.utils;

import com.gm.anepoch.digitalbird.commons.constants.SmsConstants;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/8 - 9:56
 */
public final class SmsUtils {
    private SmsUtils() {

    }

    public static com.aliyun.dysmsapi20170525.Client createClient() throws Exception {
        com.aliyun.teaopenapi.models.Config config = new com.aliyun.teaopenapi.models.Config()
                // 必填，您的 AccessKey ID
                .setAccessKeyId(SmsConstants.ACCESS_KEY_ID)
                // 必填，您的 AccessKey Secret
                .setAccessKeySecret(SmsConstants.ACCESS_KEY_SECRET);
        // Endpoint 请参考 https://api.aliyun.com/product/Dysmsapi
        config.endpoint = SmsConstants.END_POINT;
        return new com.aliyun.dysmsapi20170525.Client(config);
    }

    /**
     * 六位随机数
     *
     * @return code
     */
    public static String genCode() {
        return String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
    }
}
