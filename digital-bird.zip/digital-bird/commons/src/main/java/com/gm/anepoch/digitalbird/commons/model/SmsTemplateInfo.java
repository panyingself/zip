package com.gm.anepoch.digitalbird.commons.model;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * @author py
 * @date 2019/4
 */
@Data
public class SmsTemplateInfo implements Serializable {
	/** 主键id */
	private Long id;
	/** 模板code */
	private String code;
	/** 阿里云短信签名 */
	private String aliyunSignName;
	/** 阿里云模板code */
	private String aliyunTemplateCode;
	/** 短信有效时间(s) */
	private Integer expireTimeCount;
	/** 创建时间 */
	private java.util.Date createTime;
	/** 修改时间 */
	private java.util.Date updateTime;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
	}
}

