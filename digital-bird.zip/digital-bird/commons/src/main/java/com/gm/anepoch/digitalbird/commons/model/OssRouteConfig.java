package com.gm.anepoch.digitalbird.commons.model;

import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.Date;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 16:13
 */
@Data
public class OssRouteConfig implements Serializable {
    private Long id;
    private String bizType;
    private String bucketName;
    private String resourcePath;
    private String limitRule;
    private String remark;
    private Date createTime;
    private String createUser;
    private Date updateTime;
    private String updateUser;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
