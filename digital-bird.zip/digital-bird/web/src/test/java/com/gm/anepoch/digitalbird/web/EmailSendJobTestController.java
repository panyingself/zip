package com.gm.anepoch.digitalbird.web;

import com.gm.anepoch.digitalbird.biz.job.SendEmailJob;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.*;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.annotation.security.RunAs;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/9 - 16:00
 */
@SpringBootTest
@RunWith(SpringRunner.class)
//@Transactional
//@Rollback
public class EmailSendJobTestController {
    @Resource
    private SendEmailJob sendEmailJob;

    @Test
    public void testSendEmailJob(){
        try {
            sendEmailJob.sendEmail();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
