package com.gm.anepoch.digitalbird.web;

import com.gm.anepoch.digitalbird.biz.oss.AliOssBiz;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsSendBo;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
public class UploadTestController {

    @Resource
    private AliOssBiz aliOssBiz;
    @Test
    public void deleteOssUrl(){
//        aliOssBiz.deleteOssUrl("caseAutomaticCollectionFile/2023-10-16/天猫-欧莱雅天猫官方旗舰店-2023-10-16-店铺首页-男性");
    }
}
