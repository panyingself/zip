package com.gm.anepoch.digitalbird.web;

import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.water.WaterBiz;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/19 - 19:00
 */
@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
public class WaterTestController {
    @Resource
    private WaterBiz waterBiz;

    @Test
    public void testGetWater() {
        String collection_record = waterBiz.getWaterId("collection_record");
        log.info("result : {}", collection_record);
    }

    @Test
    public void testGetWaterIds() {
        List<String> collection_record = waterBiz.getWaterIdList("collection_record", 20L);
        log.info("result : {}", JsonMoreUtils.toJson(collection_record));
    }
}
