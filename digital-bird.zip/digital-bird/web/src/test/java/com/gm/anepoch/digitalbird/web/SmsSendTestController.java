package com.gm.anepoch.digitalbird.web;

import com.gm.anepoch.digitalbird.biz.job.SendEmailJob;
import com.gm.anepoch.digitalbird.biz.sms.SmsBiz;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsSendBo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/9 - 16:00
 */
@SpringBootTest
@RunWith(SpringRunner.class)
//@Transactional
//@Rollback
public class SmsSendTestController {
    @Resource
    private SmsBiz smsBiz;

    @Test
    public void testSendSms(){
        try {
            SmsSendBo smsSendBo = new SmsSendBo();
            smsSendBo.setAppName("数字营销平台");
            smsSendBo.setBiz("用户注册");
            smsSendBo.setReceivePhone("13520257702");
            smsSendBo.setTemplateCode("digital-001");
            smsBiz.send(smsSendBo);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
