
package com.gm.anepoch.digitalbird.web.controller.smstemplateinfo;

import com.gm.anepoch.digitalbird.biz.smstemplateinfo.SmsTemplateInfoBiz;
import com.gm.anepoch.digitalbird.biz.smstemplateinfo.bo.SmsTemplateInfoBo;
import com.gm.anepoch.digitalbird.web.controller.smstemplateinfo.request.*;
import com.gm.anepoch.digitalbird.web.controller.smstemplateinfo.response.*;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
/**
 *
 * @author py
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Api(tags = "smstemplateinfo权限控制器")
@RestController
@RequestMapping("api/smstemplateinfo")
public class SmsTemplateInfoController{
	@Resource
	private SmsTemplateInfoBiz smsTemplateInfoBiz;
	

	@ApiOperation(value = "新增记录", notes = "新增记录")
	@PostMapping("add")
	public boolean add(@RequestBody SmsTemplateInfoAddRequest addSmsTemplateInfoRequest) {
		SmsTemplateInfoBo addSmsTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(addSmsTemplateInfoRequest), SmsTemplateInfoBo.class);
		return smsTemplateInfoBiz.add(addSmsTemplateInfoBo);
	}

	@ApiOperation(value = "编辑记录", notes = "编辑记录")
	@PostMapping("editById")
	public boolean edit(@RequestBody SmsTemplateInfoEditRequest editSmsTemplateInfoRequest) {
		SmsTemplateInfoBo editSmsTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(editSmsTemplateInfoRequest), SmsTemplateInfoBo.class);
		return smsTemplateInfoBiz.editById(editSmsTemplateInfoBo);
	}

	@ApiOperation(value = "查询记录数据集", notes = "查询记录数据集")
	@PostMapping("list")
	public List<SmsTemplateInfoListResponse> list(@RequestBody SmsTemplateInfoQueryRequest querySmsTemplateInfoRequest) {
		SmsTemplateInfoBo querySmsTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(querySmsTemplateInfoRequest), SmsTemplateInfoBo.class);
		List<SmsTemplateInfoBo> resultList = smsTemplateInfoBiz.list(querySmsTemplateInfoBo);
		if(CollectionUtils.isEmpty(resultList)){
			return Lists.newArrayListWithCapacity(0);
		}
		return JsonMoreUtils.ofList(JsonMoreUtils.toJson(resultList),SmsTemplateInfoListResponse.class);
	}

	@ApiOperation(value = "查询记录详情byId", notes = "查询记录详情byId")
	@GetMapping("fetchDetailById")
	public SmsTemplateInfoDetailResponse fetchDetailById(Long recordId) {
		SmsTemplateInfoBo result = smsTemplateInfoBiz.fetchDetailById(recordId);
		if(Objects.isNull(result)){
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(result),SmsTemplateInfoDetailResponse.class);
	}
}

