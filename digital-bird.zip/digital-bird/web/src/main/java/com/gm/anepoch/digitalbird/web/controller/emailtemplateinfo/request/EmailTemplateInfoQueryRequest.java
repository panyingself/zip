package com.gm.anepoch.digitalbird.web.controller.emailtemplateinfo.request;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "EmailTemplateInfoQueryRequest")
@Data
public class EmailTemplateInfoQueryRequest {
        @ApiModelProperty(value = "id", name = "id")
        private Long id;

        @ApiModelProperty(value = "code", name = "code")
        private String code;

        @ApiModelProperty(value = "subject", name = "subject")
        private String subject;

        @ApiModelProperty(value = "content", name = "content")
        private String content;

        @ApiModelProperty(value = "createTime", name = "createTime")
        private java.util.Date createTime;

        @ApiModelProperty(value = "createUser", name = "createUser")
        private String createUser;

        @ApiModelProperty(value = "updateTime", name = "updateTime")
        private java.util.Date updateTime;

        @ApiModelProperty(value = "updateUser", name = "updateUser")
        private java.util.Date updateUser;


        @Override
        public String toString () {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}
