package com.gm.anepoch.digitalbird.web.controller.sms;

import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.sms.SmsBiz;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsSendBo;
import com.gm.anepoch.digitalbird.biz.sms.bo.SmsValidateCheckBo;
import com.gm.anepoch.digitalbird.web.controller.sms.request.SmsSendRequest;
import com.gm.anepoch.digitalbird.web.controller.sms.request.SmsValidateCodeCheckRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 15:35
 */
@RestController
@RequestMapping("api/sms")
public class SmsController {
    @Resource
    private SmsBiz smsBiz;

    @PostMapping("/send")
    public Boolean send(@RequestBody SmsSendRequest smsSendRequest) {
        return smsBiz.send(JsonMoreUtils.toBean(JsonMoreUtils.toJson(smsSendRequest), SmsSendBo.class));
    }

    /**
     * check短信验证码
     *
     * @param smsValidateCodeCheckRequest smsValidateCodeCheckRequest
     * @return success true orElse false
     */
    @RequestMapping("/checkValidateCode")
    public Boolean send(@RequestBody SmsValidateCodeCheckRequest smsValidateCodeCheckRequest) {
        return smsBiz.checkValidateCode(JsonMoreUtils.toBean(JsonMoreUtils.toJson(smsValidateCodeCheckRequest), SmsValidateCheckBo.class));
    }
}
