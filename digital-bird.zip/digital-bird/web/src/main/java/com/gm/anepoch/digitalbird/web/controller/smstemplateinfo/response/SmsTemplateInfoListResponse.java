package com.gm.anepoch.digitalbird.web.controller.smstemplateinfo.response;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "SmsTemplateInfoListResponse")
@Data
public class SmsTemplateInfoListResponse {
        @ApiModelProperty(value = "id", name = "id")
        private Long id;

        @ApiModelProperty(value = "code", name = "code")
        private String code;

        @ApiModelProperty(value = "aliyunSignName", name = "aliyunSignName")
        private String aliyunSignName;

        @ApiModelProperty(value = "aliyunTemplateCode", name = "aliyunTemplateCode")
        private String aliyunTemplateCode;

        @ApiModelProperty(value = "createTime", name = "createTime")
        private java.util.Date createTime;

        @ApiModelProperty(value = "updateTime", name = "updateTime")
        private java.util.Date updateTime;


    @Override
    public String toString () {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
