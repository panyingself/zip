package com.gm.anepoch.digitalbird.web.controller.uploadfile.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author xiongyu
 * @date 2023年09月20日 15:33
 * The most unusual thing is to live an ordinary life well
 */
@Data
public class UploadFileResponse implements Serializable {

    private String originalUrl;

    private String accessUrl;
}
