
package com.gm.anepoch.digitalbird.web.controller.smssendrecord;

import com.gm.anepoch.digitalbird.biz.smssendrecord.SmsSendRecordBiz;
import com.gm.anepoch.digitalbird.biz.smssendrecord.bo.SmsSendRecordBo;
import com.gm.anepoch.digitalbird.web.controller.smssendrecord.request.*;
import com.gm.anepoch.digitalbird.web.controller.smssendrecord.response.*;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
/**
 *
 * @author py
 * @description
 * @date 2023/11/20 17:30
 * @return null
 */
@Api(tags = "smssendrecord权限控制器")
@RestController
@RequestMapping("api/sms/sendRecord")
public class SmsSendRecordController {
    @Resource
    private SmsSendRecordBiz smsSendRecordBiz;


    @ApiOperation(value = "新增记录", notes = "新增记录")
    @PostMapping("add")
    public boolean add(@RequestBody SmsSendRecordAddRequest addSmsSendRecordRequest) {
        SmsSendRecordBo addSmsSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(addSmsSendRecordRequest), SmsSendRecordBo.class);
        return smsSendRecordBiz.add(addSmsSendRecordBo);
    }

    @ApiOperation(value = "编辑记录", notes = "编辑记录")
    @PostMapping("editById")
    public boolean edit(@RequestBody SmsSendRecordEditRequest editSmsSendRecordRequest) {
        SmsSendRecordBo editSmsSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(editSmsSendRecordRequest), SmsSendRecordBo.class);
        return smsSendRecordBiz.editById(editSmsSendRecordBo);
    }

    @ApiOperation(value = "查询记录数据集", notes = "查询记录数据集")
    @PostMapping("list")
    public List<SmsSendRecordListResponse> list(@RequestBody SmsSendRecordQueryRequest querySmsSendRecordRequest) {
        SmsSendRecordBo querySmsSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(querySmsSendRecordRequest), SmsSendRecordBo.class);
        List<SmsSendRecordBo> resultList = smsSendRecordBiz.list(querySmsSendRecordBo);
        if (CollectionUtils.isEmpty(resultList)) {
            return Lists.newArrayListWithCapacity(0);
        }
        return JsonMoreUtils.ofList(JsonMoreUtils.toJson(resultList), SmsSendRecordListResponse.class);
    }

    @ApiOperation(value = "查询记录详情byId", notes = "查询记录详情byId")
    @GetMapping("fetchDetailById")
    public SmsSendRecordDetailResponse fetchDetailById(Long recordId) {
        SmsSendRecordBo result = smsSendRecordBiz.fetchDetailById(recordId);
        if (Objects.isNull(result)) {
            return null;
        }
        return JsonMoreUtils.toBean(JsonMoreUtils.toJson(result), SmsSendRecordDetailResponse.class);
    }
}

