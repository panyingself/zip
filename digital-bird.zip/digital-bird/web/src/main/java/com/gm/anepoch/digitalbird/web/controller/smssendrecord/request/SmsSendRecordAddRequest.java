        package com.gm.anepoch.digitalbird.web.controller.smssendrecord.request;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "SmsSendRecordAddRequest")
@Data
public class SmsSendRecordAddRequest {
        @ApiModelProperty(value = "id", name = "id")
        private Long id;

        @ApiModelProperty(value = "appName", name = "appName")
        private String appName;

        @ApiModelProperty(value = "biz", name = "biz")
        private String biz;

        @ApiModelProperty(value = "receivePhone", name = "receivePhone")
        private String receivePhone;

        @ApiModelProperty(value = "signName", name = "signName")
        private String signName;

        @ApiModelProperty(value = "templateCode", name = "templateCode")
        private String templateCode;

        @ApiModelProperty(value = "templateParams", name = "templateParams")
        private String templateParams;

        @ApiModelProperty(value = "validateCode", name = "validateCode")
        private String validateCode;

        @ApiModelProperty(value = "expireTime", name = "expireTime")
        private java.util.Date expireTime;

        @ApiModelProperty(value = "status", name = "status")
        private String status;

        @ApiModelProperty(value = "createTime", name = "createTime")
        private java.util.Date createTime;

        @ApiModelProperty(value = "updateTime", name = "updateTime")
        private java.util.Date updateTime;


        @Override
        public String toString () {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}
