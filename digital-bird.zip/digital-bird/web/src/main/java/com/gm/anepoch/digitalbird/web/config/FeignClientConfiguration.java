package com.gm.anepoch.digitalbird.web.config;

import cn.hutool.http.Method;
import com.gm.anepoch.base.commons.filter.TraceIdHelper;
import com.gm.anepoch.base.commons.filter.constants.TraceConstants;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Objects;

/**
 * Description:
 *
 * @Author: zhangdh
 * @Time - 2023/9/11 - 21:08
 */
@Configuration
@Slf4j
public class FeignClientConfiguration {
    private static final Logger LOGGER = LoggerFactory.getLogger("feignConsumerLog");
    @Bean
    public RequestInterceptor customRequestInterceptor() {
        return new RequestInterceptor() {
            @Override
            public void apply(RequestTemplate requestTemplate) {
                //在请求头中添加自定义属性
                requestTemplate.header("X-Feign-Specific-Header", "Feign-Specific-Value");
                String traceId = TraceIdHelper.getCurrentTraceId();
                requestTemplate.header(TraceConstants.TRACE_ID, traceId);
                if (Objects.equals(Method.GET.name(), requestTemplate.method())
                        || Objects.equals(Method.DELETE.name(), requestTemplate.method())) {
                    LOGGER.info("method - {} , url - {} , params - {}", requestTemplate.method(),
                            requestTemplate.url(), requestTemplate.headers());
                }
                if (Objects.equals(Method.POST.name(), requestTemplate.method())
                        || Objects.equals(Method.PUT.name(), requestTemplate.method())) {
                    String bodyText = requestTemplate.requestCharset() != null
                            ? new String(requestTemplate.requestBody().asBytes(),
                            requestTemplate.requestCharset())
                            : null;
                    LOGGER.info("method - {} , url - {} , params - {}", requestTemplate.method(),
                            requestTemplate.url(), bodyText);
                }
            }
        };
    }

}
