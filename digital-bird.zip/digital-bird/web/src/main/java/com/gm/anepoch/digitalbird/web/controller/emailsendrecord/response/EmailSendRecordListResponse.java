package com.gm.anepoch.digitalbird.web.controller.emailsendrecord.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "EmailSendRecordListResponse")
@Data
public class EmailSendRecordListResponse {
    @ApiModelProperty(value = "id", name = "id")
    private Long id;

    @ApiModelProperty(value = "appName", name = "appName")
    private String appName;

    @ApiModelProperty(value = "biz", name = "biz")
    private String biz;

    @ApiModelProperty(value = "messageId", name = "messageId")
    private String messageId;

    @ApiModelProperty(value = "addressFrom", name = "addressFrom")
    private String addressFrom;

    @ApiModelProperty(value = "addressTo", name = "addressTo")
    private String addressTo;

    @ApiModelProperty(value = "addressCc", name = "addressCc")
    private String addressCc;

    @ApiModelProperty(value = "addressBcc", name = "addressBcc")
    private String addressBcc;

    @ApiModelProperty(value = "subject", name = "subject")
    private String subject;

    @ApiModelProperty(value = "content", name = "content")
    private String content;

    @ApiModelProperty(value = "attachments", name = "attachments")
    private String attachments;

    @ApiModelProperty(value = "status", name = "status")
    private String status;

    @ApiModelProperty(value = "retryCount", name = "retryCount")
    private Integer retryCount;

    @ApiModelProperty(value = "createTime", name = "createTime")
    private java.util.Date createTime;

    @ApiModelProperty(value = "updateTime", name = "updateTime")
    private java.util.Date updateTime;


    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
