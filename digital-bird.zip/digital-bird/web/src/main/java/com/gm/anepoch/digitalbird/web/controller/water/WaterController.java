package com.gm.anepoch.digitalbird.web.controller.water;

import com.gm.anepoch.digitalbird.biz.water.WaterBiz;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * Description: 水滴控制器(id生成服务)
 *
 * @author -  pany
 * Time - 2023/9/19 - 16:47
 */
@RestController
@RequestMapping("api/water")
public class WaterController {
    @Resource
    private WaterBiz waterBiz;

    @GetMapping("/getWaterId")
    public String getWaterId(String bizType) {
        return waterBiz.getWaterId(bizType);
    }

    @GetMapping("/getWaterIdList")
    public List<String> getWaterIdList(String bizType, Long number) {
        return waterBiz.getWaterIdList(bizType, number);
    }
}
