
package com.gm.anepoch.digitalbird.web.controller.emailtemplateinfo;

import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.EmailTemplateInfoBiz;
import com.gm.anepoch.digitalbird.biz.emailtemplateinfo.bo.EmailTemplateInfoBo;
import com.gm.anepoch.digitalbird.web.controller.emailtemplateinfo.request.*;
import com.gm.anepoch.digitalbird.web.controller.emailtemplateinfo.response.*;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author pany
 */
@Api(tags = "emailtemplateinfo权限控制器")
@RestController
@RequestMapping("api/email/templateInfo")
public class EmailTemplateInfoController{
	@Resource
	private EmailTemplateInfoBiz emailTemplateInfoBiz;
	

	@ApiOperation(value = "新增记录", notes = "新增记录")
	@PostMapping("add")
	public boolean add(@RequestBody EmailTemplateInfoAddRequest addEmailTemplateInfoRequest) {
		EmailTemplateInfoBo addEmailTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(addEmailTemplateInfoRequest), EmailTemplateInfoBo.class);
		return emailTemplateInfoBiz.add(addEmailTemplateInfoBo);
	}

	@ApiOperation(value = "编辑记录", notes = "编辑记录")
	@PostMapping("editById")
	public boolean edit(@RequestBody EmailTemplateInfoEditRequest editEmailTemplateInfoRequest) {
		EmailTemplateInfoBo editEmailTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(editEmailTemplateInfoRequest), EmailTemplateInfoBo.class);
		return emailTemplateInfoBiz.editById(editEmailTemplateInfoBo);
	}

	@ApiOperation(value = "查询记录数据集", notes = "查询记录数据集")
	@PostMapping("list")
	public List<EmailTemplateInfoListResponse> list(@RequestBody EmailTemplateInfoQueryRequest queryEmailTemplateInfoRequest) {
		EmailTemplateInfoBo queryEmailTemplateInfoBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(queryEmailTemplateInfoRequest), EmailTemplateInfoBo.class);
		List<EmailTemplateInfoBo> resultList = emailTemplateInfoBiz.list(queryEmailTemplateInfoBo);
		if(CollectionUtils.isEmpty(resultList)){
			return Lists.newArrayListWithCapacity(0);
		}
		return JsonMoreUtils.ofList(JsonMoreUtils.toJson(resultList),EmailTemplateInfoListResponse.class);
	}

	@ApiOperation(value = "查询记录详情byId", notes = "查询记录详情byId")
	@GetMapping("fetchDetailById")
	public EmailTemplateInfoDetailResponse fetchDetailById(Long recordId) {
		EmailTemplateInfoBo result = emailTemplateInfoBiz.fetchDetailById(recordId);
		if(Objects.isNull(result)){
			return null;
		}
		return JsonMoreUtils.toBean(JsonMoreUtils.toJson(result),EmailTemplateInfoDetailResponse.class);
	}
}

