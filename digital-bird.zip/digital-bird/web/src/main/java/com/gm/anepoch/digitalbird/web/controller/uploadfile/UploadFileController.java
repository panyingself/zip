package com.gm.anepoch.digitalbird.web.controller.uploadfile;

import com.gm.anepoch.base.commons.base.result.HttpResult;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.api.co.request.OssDeleteUrlFeignRequest;
import com.gm.anepoch.digitalbird.biz.oss.AliOssBiz;
import com.gm.anepoch.digitalbird.biz.uploadfile.UploadFileBiz;
import com.gm.anepoch.digitalbird.web.controller.uploadfile.response.UploadFileResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author xiongyu
 * @date 2023年09月19日 12:45
 * The most unusual thing is to live an ordinary life well
 */

@Api(tags = "文件资源控制器")
@RestController
@RequestMapping("api/uploadFile")
@Slf4j
public class UploadFileController {

    @Resource
    private UploadFileBiz uploadFileBiz;

    @Resource
    private AliOssBiz aliOssBiz;


    @ApiOperation(value = "竞品系统上传图片", notes = "竞品系统上传图片")
    @PostMapping("uploadFileByCompetitors")
    public HttpResult<UploadFileResponse> uploadFileByCompetitors(@RequestParam(value = "file", required = false) MultipartFile file, @RequestParam(value = "bizType", required = true) String bizType) throws IOException {
        return HttpResult.success(JsonMoreUtils.toBean(JsonMoreUtils.toJson(aliOssBiz.upload(bizType, file.getOriginalFilename(), file.getInputStream(), file.getSize())), UploadFileResponse.class));
    }


    @ApiOperation(value = "图片删除接口", notes = "图片删除接口")
    @PostMapping("deleteOssByUrl")
    public HttpResult<Boolean> deleteOssByUrl(@RequestBody OssDeleteUrlFeignRequest request) throws IOException {
        return HttpResult.success(aliOssBiz.deleteOssUrl(request));
    }

}
