package com.gm.anepoch.digitalbird.web.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author pany
 */
@Configuration
@EnableSwagger2
public class Swagger2Config {

    @Bean
    public Docket docket() {
        ParameterBuilder builder = new ParameterBuilder();

        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("gm_interface")
                .apiInfo(apiInfo())
                .select().paths(PathSelectors.any()).build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("xxxx系统")
                .description("xxxx接口文档")
                .contact(new Contact("gm", "", "10086@gm.com"))
                .version("1.0")
                .build();
    }

}