
package com.gm.anepoch.digitalbird.web.controller.emailsendrecord;

import com.gm.anepoch.digitalbird.biz.emailsendrecord.EmailSendRecordBiz;
import com.gm.anepoch.digitalbird.biz.emailsendrecord.bo.EmailSendRecordBo;
import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.web.controller.emailsendrecord.request.EmailSendRecordAddRequest;
import com.gm.anepoch.digitalbird.web.controller.emailsendrecord.request.EmailSendRecordEditRequest;
import com.gm.anepoch.digitalbird.web.controller.emailsendrecord.request.EmailSendRecordQueryRequest;
import com.gm.anepoch.digitalbird.web.controller.emailsendrecord.response.EmailSendRecordDetailResponse;
import com.gm.anepoch.digitalbird.web.controller.emailsendrecord.response.EmailSendRecordListResponse;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author pany
 */
@Api(tags = "emailsendrecord权限控制器")
@RestController
@RequestMapping("api/email/sendRecord")
public class EmailSendRecordController {
    @Resource
    private EmailSendRecordBiz emailSendRecordBiz;


    @ApiOperation(value = "新增记录", notes = "新增记录")
    @PostMapping("add")
    public boolean add(@RequestBody EmailSendRecordAddRequest addEmailSendRecordRequest) {
        EmailSendRecordBo addEmailSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(addEmailSendRecordRequest), EmailSendRecordBo.class);
        return emailSendRecordBiz.add(addEmailSendRecordBo);
    }

    @ApiOperation(value = "编辑记录", notes = "编辑记录")
    @PostMapping("editById")
    public boolean edit(@RequestBody EmailSendRecordEditRequest editEmailSendRecordRequest) {
        EmailSendRecordBo editEmailSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(editEmailSendRecordRequest), EmailSendRecordBo.class);
        return emailSendRecordBiz.editById(editEmailSendRecordBo);
    }

    @ApiOperation(value = "查询记录数据集", notes = "查询记录数据集")
    @PostMapping("list")
    public List<EmailSendRecordListResponse> list(@RequestBody EmailSendRecordQueryRequest queryEmailSendRecordRequest) {
        EmailSendRecordBo queryEmailSendRecordBo = JsonMoreUtils.toBean(JsonMoreUtils.toJson(queryEmailSendRecordRequest), EmailSendRecordBo.class);
        List<EmailSendRecordBo> resultList = emailSendRecordBiz.list(queryEmailSendRecordBo);
        if (CollectionUtils.isEmpty(resultList)) {
            return Lists.newArrayListWithCapacity(0);
        }
        return JsonMoreUtils.ofList(JsonMoreUtils.toJson(resultList), EmailSendRecordListResponse.class);
    }

    @ApiOperation(value = "查询记录详情byId", notes = "查询记录详情byId")
    @GetMapping("fetchDetailById")
    public EmailSendRecordDetailResponse fetchDetailById(Long recordId) {
        EmailSendRecordBo result = emailSendRecordBiz.fetchDetailById(recordId);
        if (Objects.isNull(result)) {
            return null;
        }
        return JsonMoreUtils.toBean(JsonMoreUtils.toJson(result), EmailSendRecordDetailResponse.class);
    }
}

