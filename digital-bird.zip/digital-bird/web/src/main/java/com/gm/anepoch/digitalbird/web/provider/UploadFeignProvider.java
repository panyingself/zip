
package com.gm.anepoch.digitalbird.web.provider;

import com.gm.anepoch.digitalbird.api.co.request.OssDeleteUrlFeignRequest;
import com.gm.anepoch.digitalbird.biz.oss.AliOssBiz;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author zhangdh
 */
@Api(tags = "小鸟服务-远程调用工程")
@RestController
@RequestMapping("/api/bird/upload/provider")
public class UploadFeignProvider {
	@Resource
	private AliOssBiz aliOssBiz;



	/**
	 * 统一验证用户权限和token
	 * @param request 请求路径集合
	 * @return LoginUser
	 */
	@ApiOperation(value = "服务内部通过url删除图片")
	@PostMapping("deleteOssUrl")
	public Boolean deleteOssUrl(@RequestBody OssDeleteUrlFeignRequest request) throws IllegalAccessException {
		return aliOssBiz.deleteOssUrl(request);
	}




}

