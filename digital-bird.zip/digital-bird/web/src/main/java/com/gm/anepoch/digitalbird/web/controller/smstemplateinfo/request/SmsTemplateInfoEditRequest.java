package com.gm.anepoch.digitalbird.web.controller.smstemplateinfo.request;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import lombok.Data;

/**
 * @author py
 * @date 2019/4
 */
@ApiModel(description = "SmsTemplateInfoEditRequest")
@Data
public class SmsTemplateInfoEditRequest extends SmsTemplateInfoAddRequest{
        @ApiModelProperty(value = "id", name = "id")
        private Long id;

        @Override
        public String toString() {
                return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
        }
}



