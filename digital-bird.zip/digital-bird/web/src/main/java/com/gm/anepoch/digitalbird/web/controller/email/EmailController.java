package com.gm.anepoch.digitalbird.web.controller.email;

import com.gm.anepoch.base.commons.utils.JsonMoreUtils;
import com.gm.anepoch.digitalbird.biz.email.EmailSendBiz;
import com.gm.anepoch.digitalbird.biz.email.bo.EmailSendBo;
import com.gm.anepoch.digitalbird.biz.email.bo.EmailValidateCheckBo;
import com.gm.anepoch.digitalbird.web.controller.email.request.EmailSendRequest;
import com.gm.anepoch.digitalbird.web.controller.email.request.EmailValidateCodeCheckRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/9/6 - 15:35
 */
@RestController
@RequestMapping("api/email")
public class EmailController {
    @Resource
    private EmailSendBiz emailSendBiz;

    @PostMapping("/send")
    public Boolean send(@RequestBody @Valid EmailSendRequest emailSendRequest) {
        return emailSendBiz.send(JsonMoreUtils.toBean(JsonMoreUtils.toJson(emailSendRequest), EmailSendBo.class));
    }

    /**
     * check短信验证码
     *
     * @param emailValidateCodeCheckRequest smsValidateCodeCheckRequest
     * @return success true orElse false
     */
    @RequestMapping("/checkValidateCode")
    public Boolean send(@RequestBody @Valid EmailValidateCodeCheckRequest emailValidateCodeCheckRequest) {
        return emailSendBiz.checkValidateCode(JsonMoreUtils.toBean(JsonMoreUtils.toJson(emailValidateCodeCheckRequest), EmailValidateCheckBo.class));
    }
}
