package com.gm.anepoch.digitalbird.web.controller.oss;

import com.gm.anepoch.digitalbird.biz.oss.OssRouteConfigLoader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * Description:
 *
 * @author -  pany
 * Time - 2023/10/14 - 17:25
 */
@RestController
@RequestMapping("api/oss/routeConfig")
public class OssRouteConfigController {
    @Resource
    private OssRouteConfigLoader ossRouteConfigLoader;

    @GetMapping("/reload")
    public String reload() {
        ossRouteConfigLoader.doReload();
        return "success";
    }
}
